"""
V2 Step 3: V1 → V2 Reimbursement Data Migration
=================================================
Migrates V1 tables into V2 schema with corrected column mappings.
Adaptations from original V2_REIMB_02_migration.sql:
  - tbl_contract_rates_all: no lesser_of_language col → derive from rate_text/formula
  - tbl_contract_financial_protections: no applies_to_services → use sub_type
  - tbl_serving_capitation_card: flat schema (age_gender_band, pmpm_rate) not multi-year

Run AFTER: 01_execute_ddl.py
Run BEFORE: 02_state_engine.py
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"

def log_step(name, status, details=""):
    ts = datetime.now().strftime("%H:%M:%S")
    icon = "✓" if status == "SUCCESS" else "✗" if status == "FAILED" else "○"
    print(f"[{ts}] {icon} {name}: {status}")
    if details:
        print(f"    {details}")

def run_sql(stmt, desc=""):
    """Execute SQL, return row count affected or -1 on error."""
    try:
        result = spark.sql(stmt)
        return result
    except Exception as e:
        print(f"  ERROR ({desc}): {str(e)[:200]}")
        return None

print("=" * 60)
print("V2 REIMBURSEMENT MIGRATION — V1 → V2")
print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 60)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

# ============================================================
# MIGRATION 1: tbl_contract_rates_all → tbl_reimb_rate_rules
# ============================================================
log_step("Migration 1: Rates → rate_rules", "RUNNING")

MIGRATION_1 = f"""
INSERT INTO {FQ}.tbl_reimb_rate_rules (
    rule_id, contract_id, provider_id, provider_name,
    rate_domain, service_line, service_category_raw,
    formula_type, formula_json,
    rate_numeric, rate_text, rate_unit,
    program, network, revenue_codes, procedure_codes, drg_codes,
    source_filename, exhibit_reference, effective_date,
    has_stop_loss, has_carve_outs, has_escalator, has_conditions,
    extracted_at, confidence_score
)
SELECT
    uuid() AS rule_id,
    sha2(concat_ws('|', r.provider_id, r.source_filename), 256) AS contract_id,
    r.provider_id,
    r.provider_name,
    CASE
        WHEN r.rate_category ILIKE '%inpatient%' OR r.rate_category ILIKE '%per_diem%' THEN 'INPATIENT'
        WHEN r.rate_category ILIKE '%outpatient%' OR r.rate_category ILIKE '%ambulatory%' THEN 'OUTPATIENT'
        WHEN r.rate_category ILIKE '%capitation%' OR r.rate_category ILIKE '%pmpm%' THEN 'CAPITATION'
        WHEN r.rate_category ILIKE '%professional%' OR r.rate_category ILIKE '%physician%' THEN 'PROFESSIONAL'
        ELSE 'INPATIENT'
    END AS rate_domain,
    COALESCE(r.service_category, 'Unclassified') AS service_line,
    r.service_category AS service_category_raw,
    CASE
        WHEN r.formula ILIKE '%DRG%' OR r.formula ILIKE '%drg%weight%' THEN 'DRG_WEIGHTED'
        WHEN r.formula ILIKE '%CF%' OR r.formula ILIKE '%conversion%factor%' THEN 'CONVERSION_FACTOR'
        WHEN r.rate_category ILIKE '%per_diem%' OR r.rate_category ILIKE '%per diem%' THEN 'PER_DIEM'
        WHEN r.formula ILIKE '%percent%' OR r.formula ILIKE '%pct%' OR r.rate_category ILIKE '%pct%' THEN 'PERCENTAGE'
        WHEN r.rate_text ILIKE '%lesser%of%' OR r.formula ILIKE '%lesser%' THEN 'LESSER_OF'
        WHEN r.rate_category ILIKE '%case_rate%' OR r.rate_category ILIKE '%case rate%' THEN 'FIXED'
        WHEN r.rate_category ILIKE '%capitation%' THEN 'FIXED'
        ELSE 'FIXED'
    END AS formula_type,
    CASE
        WHEN r.formula ILIKE '%DRG%' THEN
            concat('{{"formula_type":"DRG_WEIGHTED","base_rate":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"weight_source":"CMS_DRG_WEIGHTS"}}')
        WHEN r.formula ILIKE '%CF%' THEN
            concat('{{"formula_type":"CONVERSION_FACTOR","conversion_factor":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"multiplied_by":"RVU"}}')
        WHEN r.rate_category ILIKE '%per_diem%' OR r.rate_category ILIKE '%per diem%' THEN
            concat('{{"formula_type":"PER_DIEM","base_rate":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"unit":"day"}}')
        WHEN r.formula ILIKE '%percent%' OR r.formula ILIKE '%pct%' THEN
            concat('{{"formula_type":"PERCENTAGE","percentage":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"of":"BILLED_CHARGES"}}')
        WHEN r.rate_text ILIKE '%lesser%of%' OR r.formula ILIKE '%lesser%' THEN
            concat('{{"formula_type":"LESSER_OF","operands":[{{"formula_type":"FIXED","amount":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), '}},{{"formula_type":"REFERENCE","reference":"BILLED_CHARGES"}}]}}')
        ELSE
            concat('{{"formula_type":"FIXED","amount":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), '}}')
    END AS formula_json,
    r.rate_numeric,
    r.rate_text,
    CASE
        WHEN r.rate_category ILIKE '%per_diem%' THEN 'day'
        WHEN r.rate_category ILIKE '%capitation%' THEN 'member_month'
        WHEN r.rate_category ILIKE '%case_rate%' THEN 'case'
        ELSE 'case'
    END AS rate_unit,
    r.program_normalized AS program,
    r.network,
    r.revenue_codes,
    NULL AS procedure_codes,
    NULL AS drg_codes,
    r.source_filename,
    NULL AS exhibit_reference,
    r.effective_date_parsed AS effective_date,
    FALSE AS has_stop_loss,
    FALSE AS has_carve_outs,
    FALSE AS has_escalator,
    FALSE AS has_conditions,
    current_timestamp() AS extracted_at,
    0.7 AS confidence_score
FROM {FQ}.tbl_contract_rates_all r
WHERE r.status = 'current'
"""

run_sql(MIGRATION_1, "rates migration")
count_1 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_rate_rules").collect()[0]["n"]
log_step("Migration 1: Rates", "SUCCESS", f"{count_1} rules created")

# ============================================================
# MIGRATION 2: Financial protections → tbl_reimb_stop_loss
# ============================================================
log_step("Migration 2: Stop-loss", "RUNNING")

MIGRATION_2 = f"""
INSERT INTO {FQ}.tbl_reimb_stop_loss (
    stop_loss_id, rule_id, contract_id, provider_id,
    stop_loss_type, attachment_level, attachment_unit,
    reimburse_formula_type, reimburse_rate, reimburse_percentage,
    aggregate_cap, corridor_amount,
    applies_to_services, revenue_codes,
    source_filename, exhibit_reference, effective_date
)
SELECT
    uuid() AS stop_loss_id,
    COALESCE(
        (SELECT rr.rule_id FROM {FQ}.tbl_reimb_rate_rules rr
         WHERE rr.provider_id = fp.provider_id AND rr.rate_domain = 'INPATIENT'
         LIMIT 1),
        'UNLINKED'
    ) AS rule_id,
    sha2(concat_ws('|', fp.provider_id, fp.source_filename), 256) AS contract_id,
    fp.provider_id,
    CASE
        WHEN fp.protection_type ILIKE '%per diem%' OR fp.protection_type ILIKE '%per_diem%' THEN 'PER_DIEM'
        WHEN fp.protection_type ILIKE '%aggregate%' OR fp.protection_type ILIKE '%annual%' THEN 'AGGREGATE'
        WHEN fp.protection_type ILIKE '%corridor%' THEN 'CORRIDOR'
        ELSE 'CASE_RATE'
    END AS stop_loss_type,
    fp.threshold_numeric AS attachment_level,
    'TOTAL_CHARGES' AS attachment_unit,
    CASE
        WHEN fp.reimbursement_pct_numeric IS NOT NULL THEN 'PERCENTAGE'
        ELSE 'FIXED_PER_DIEM'
    END AS reimburse_formula_type,
    NULL AS reimburse_rate,
    fp.reimbursement_pct_numeric AS reimburse_percentage,
    fp.aggregate_cap,
    fp.corridor AS corridor_amount,
    fp.sub_type AS applies_to_services,
    fp.revenue_codes,
    fp.source_filename,
    fp.exhibit_reference,
    fp.effective_date_parsed AS effective_date
FROM {FQ}.tbl_contract_financial_protections fp
WHERE fp.protection_type ILIKE '%stop%loss%'
   OR fp.protection_type ILIKE '%outlier%'
   OR fp.protection_type ILIKE '%threshold%'
"""

run_sql(MIGRATION_2, "stop-loss migration")
count_2 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_stop_loss").collect()[0]["n"]
log_step("Migration 2: Stop-loss", "SUCCESS", f"{count_2} provisions created")

# ============================================================
# MIGRATION 3: Financial protections → tbl_reimb_carve_outs
# ============================================================
log_step("Migration 3: Carve-outs", "RUNNING")

MIGRATION_3 = f"""
INSERT INTO {FQ}.tbl_reimb_carve_outs (
    carve_out_id, contract_id, provider_id,
    carve_out_type, description,
    threshold_amount, threshold_type,
    reimburse_formula_type, reimburse_percentage, reimburse_fixed, reimburse_of,
    base_rule_id, relationship,
    revenue_codes, procedure_codes, ndc_codes,
    source_filename, effective_date
)
SELECT
    uuid() AS carve_out_id,
    sha2(concat_ws('|', fp.provider_id, fp.source_filename), 256) AS contract_id,
    fp.provider_id,
    CASE
        WHEN fp.protection_type ILIKE '%implant%' THEN 'IMPLANT'
        WHEN fp.protection_type ILIKE '%drug%' OR fp.protection_type ILIKE '%pharm%' THEN 'DRUG'
        WHEN fp.protection_type ILIKE '%device%' THEN 'DEVICE'
        WHEN fp.protection_type ILIKE '%procedure%' THEN 'PROCEDURE'
        ELSE 'SUPPLY'
    END AS carve_out_type,
    fp.threshold_text AS description,
    fp.threshold_numeric AS threshold_amount,
    'PER_ITEM' AS threshold_type,
    CASE
        WHEN fp.threshold_text ILIKE '%cost%plus%' OR fp.threshold_text ILIKE '%cost +%' THEN 'COST_PLUS'
        WHEN fp.reimbursement_pct_numeric IS NOT NULL THEN 'PERCENTAGE'
        ELSE 'COST_PLUS'
    END AS reimburse_formula_type,
    fp.reimbursement_pct_numeric AS reimburse_percentage,
    NULL AS reimburse_fixed,
    'INVOICE_COST' AS reimburse_of,
    NULL AS base_rule_id,
    'ADDITIONAL_TO' AS relationship,
    fp.revenue_codes,
    NULL AS procedure_codes,
    NULL AS ndc_codes,
    fp.source_filename,
    fp.effective_date_parsed AS effective_date
FROM {FQ}.tbl_contract_financial_protections fp
WHERE fp.protection_type ILIKE '%carve%'
   OR fp.protection_type ILIKE '%implant%'
   OR fp.protection_type ILIKE '%drug%'
   OR fp.protection_type ILIKE '%device%'
"""

run_sql(MIGRATION_3, "carve-out migration")
count_3 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_carve_outs").collect()[0]["n"]
log_step("Migration 3: Carve-outs", "SUCCESS", f"{count_3} provisions created")

# ============================================================
# MIGRATION 4: Capitation card → rate_rules + escalators
# Adapted: tbl_serving_capitation_card has (age_gender_band, pmpm_rate)
# ============================================================
log_step("Migration 4: Capitation", "RUNNING")

MIGRATION_4A = f"""
INSERT INTO {FQ}.tbl_reimb_rate_rules (
    rule_id, contract_id, provider_id, provider_name,
    rate_domain, service_line, service_category_raw,
    formula_type, formula_json,
    rate_numeric, rate_text, rate_unit,
    program, network, revenue_codes, procedure_codes, drg_codes,
    source_filename, exhibit_reference, effective_date,
    has_stop_loss, has_carve_outs, has_escalator, has_conditions,
    extracted_at, confidence_score
)
SELECT
    uuid() AS rule_id,
    sha2(concat_ws('|', 'CAPITATION', c.provider_name, c.source_filename), 256) AS contract_id,
    c.provider_id,
    c.provider_name,
    'CAPITATION' AS rate_domain,
    c.age_gender_band AS service_line,
    c.age_gender_band AS service_category_raw,
    'FIXED' AS formula_type,
    concat('{{"formula_type":"FIXED","amount":', CAST(c.pmpm_rate AS STRING), ',"unit":"member_month"}}') AS formula_json,
    c.pmpm_rate AS rate_numeric,
    concat('$', CAST(c.pmpm_rate AS STRING), ' PMPM') AS rate_text,
    'member_month' AS rate_unit,
    c.program,
    c.network,
    NULL, NULL, NULL,
    c.source_filename,
    NULL AS exhibit_reference,
    c.effective_date_parsed AS effective_date,
    FALSE, FALSE, FALSE, FALSE,
    current_timestamp(),
    0.9 AS confidence_score
FROM {FQ}.tbl_serving_capitation_card c
"""

run_sql(MIGRATION_4A, "capitation rates")
count_4 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_rate_rules WHERE rate_domain = 'CAPITATION'").collect()[0]["n"]
log_step("Migration 4: Capitation", "SUCCESS", f"{count_4} capitation rules")

# ============================================================
# MIGRATION 5: Lesser-of provisions → tbl_reimb_lesser_of
# ============================================================
log_step("Migration 5: Lesser-of", "RUNNING")

MIGRATION_5 = f"""
INSERT INTO {FQ}.tbl_reimb_lesser_of (
    lesser_of_id, rule_id, contract_id,
    comparator_1_type, comparator_1_value,
    comparator_2_type, comparator_2_value,
    comparator_3_type, comparator_3_value,
    medicare_version, applies_to_services,
    source_filename, effective_date
)
SELECT
    uuid() AS lesser_of_id,
    COALESCE(
        (SELECT rr.rule_id FROM {FQ}.tbl_reimb_rate_rules rr
         WHERE rr.provider_name = g.provider_name
           AND rr.service_category_raw = g.service_category
           AND rr.rate_numeric = g.rate_numeric
         LIMIT 1),
        'UNLINKED'
    ) AS rule_id,
    sha2(concat_ws('|', g.provider_id, g.source_filename), 256) AS contract_id,
    'CONTRACTED_RATE' AS comparator_1_type,
    g.rate_numeric AS comparator_1_value,
    'BILLED_CHARGES' AS comparator_2_type,
    NULL AS comparator_2_value,
    'MEDICARE_RATE' AS comparator_3_type,
    NULL AS comparator_3_value,
    NULL AS medicare_version,
    g.service_category AS applies_to_services,
    g.source_filename,
    g.effective_date_parsed AS effective_date
FROM {FQ}.tbl_genie_rates_current g
WHERE g.rate_text ILIKE '%lesser%of%'
   OR g.formula ILIKE '%lesser%'
   OR g.rate_text ILIKE '%lower%of%'
"""

run_sql(MIGRATION_5, "lesser-of migration")
count_5 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_lesser_of").collect()[0]["n"]
log_step("Migration 5: Lesser-of", "SUCCESS", f"{count_5} provisions created")

# ============================================================
# POST-MIGRATION: Update modifier flags
# ============================================================
log_step("Post-migration: Modifier flags", "RUNNING")

run_sql(f"""
MERGE INTO {FQ}.tbl_reimb_rate_rules AS rr
USING (
    SELECT DISTINCT rule_id FROM {FQ}.tbl_reimb_stop_loss WHERE rule_id != 'UNLINKED'
) AS sl ON rr.rule_id = sl.rule_id
WHEN MATCHED THEN UPDATE SET rr.has_stop_loss = TRUE
""", "stop-loss flags")

run_sql(f"""
MERGE INTO {FQ}.tbl_reimb_rate_rules AS rr
USING (
    SELECT DISTINCT rule_id FROM {FQ}.tbl_reimb_escalators WHERE rule_id != 'UNLINKED'
) AS esc ON rr.rule_id = esc.rule_id
WHEN MATCHED THEN UPDATE SET rr.has_escalator = TRUE
""", "escalator flags")

log_step("Post-migration: Modifier flags", "SUCCESS")

# ============================================================
# SUMMARY
# ============================================================
print("\n" + "=" * 60)
print("MIGRATION SUMMARY")
print("=" * 60)
tables = [
    ("tbl_reimb_rate_rules", "Rate rules (FFS + capitation)"),
    ("tbl_reimb_stop_loss", "Stop-loss provisions"),
    ("tbl_reimb_carve_outs", "Carve-out provisions"),
    ("tbl_reimb_escalators", "Escalators"),
    ("tbl_reimb_lesser_of", "Lesser-of provisions"),
]
for tbl, desc in tables:
    c = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.{tbl}").collect()[0]["n"]
    print(f"  {tbl:<35} {c:>6} rows  ({desc})")
print("=" * 60)
