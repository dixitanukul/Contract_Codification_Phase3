"""
V2 Step 7: Reranking Service
==============================
3-stage reranking pipeline:
  Stage 1: Cross-encoder scoring (LLM fallback if RERANKER_DEPLOYED=False)
  Stage 2: Legal signal scoring (6 signals)
  Stage 3: Weighted fusion + diversity enforcement

Input: top-30 candidates from retrieval engine
Output: top-5 final results

Run AFTER: 05_retrieval_engine.py
"""

from dataclasses import dataclass
from typing import List, Dict
from datetime import datetime, date
import json

# Import ScoredChunk from retrieval engine (or define compatible)
try:
    from v2_implementation.p05_retrieval_engine import ScoredChunk, ParsedQuery
except ImportError:
    from dataclasses import dataclass, field

    @dataclass
    class ScoredChunk:
        unit_id: str
        unit_text: str
        unit_type: str
        provider_name: str
        source_filename: str
        score: float
        channel: str
        is_current: bool = True
        section_type: str = ""
        rate_domain: str = ""
        effective_date: str = ""

# ============================================================
# CONFIGURATION
# ============================================================
RERANKER_DEPLOYED = False  # Toggle when bge-reranker-v2-m3 is deployed
LLM_JUDGE = "databricks-claude-sonnet-4-5"

# Intent-specific weight profiles for legal signals
SIGNAL_WEIGHTS = {
    "RATE_LOOKUP": {
        "state": 0.25, "recency": 0.15, "specificity": 0.25,
        "scope_match": 0.20, "authority": 0.10, "completeness": 0.05
    },
    "CLAUSE_SEARCH": {
        "state": 0.20, "recency": 0.10, "specificity": 0.15,
        "scope_match": 0.15, "authority": 0.25, "completeness": 0.15
    },
    "COMPARISON": {
        "state": 0.15, "recency": 0.20, "specificity": 0.20,
        "scope_match": 0.25, "authority": 0.10, "completeness": 0.10
    },
    "TIMELINE": {
        "state": 0.10, "recency": 0.30, "specificity": 0.10,
        "scope_match": 0.15, "authority": 0.15, "completeness": 0.20
    },
    "GENERAL": {
        "state": 0.20, "recency": 0.15, "specificity": 0.15,
        "scope_match": 0.20, "authority": 0.15, "completeness": 0.15
    },
}


# ============================================================
# STAGE 1: CROSS-ENCODER / LLM RELEVANCE SCORING
# ============================================================

def score_relevance_llm(query: str, chunks: List[ScoredChunk], top_k: int = 15) -> List[ScoredChunk]:
    """Score query-chunk relevance using LLM as judge (fallback for no cross-encoder)."""
    # For efficiency, batch score top candidates
    # In production, this would call the serving endpoint
    # For now, use retrieval score as proxy (cross-encoder not yet deployed)
    if RERANKER_DEPLOYED:
        # TODO: Call bge-reranker-v2-m3 model serving endpoint
        pass

    # Fallback: use initial retrieval scores (already ranked by RRF)
    # Boost chunks whose unit_type matches expected intent
    for chunk in chunks:
        relevance_boost = 0.0
        if chunk.unit_type == "RATE_TABLE" and "rate" in query.lower():
            relevance_boost = 0.1
        elif chunk.unit_type == "CLAUSE" and "clause" in query.lower():
            relevance_boost = 0.1
        chunk.score += relevance_boost

    # Re-sort by score
    chunks.sort(key=lambda c: c.score, reverse=True)
    return chunks[:top_k]


# ============================================================
# STAGE 2: LEGAL SIGNAL SCORING
# ============================================================

def compute_state_score(chunk: ScoredChunk) -> float:
    """State signal: current=1.0, superseded=0.1."""
    return 1.0 if chunk.is_current else 0.1


def compute_recency_score(chunk: ScoredChunk) -> float:
    """Recency signal: exponential decay with 2-year half-life."""
    if not chunk.effective_date:
        return 0.5  # Unknown date gets neutral score

    try:
        eff_date = datetime.strptime(chunk.effective_date[:10], "%Y-%m-%d").date()
        days_old = (date.today() - eff_date).days
        # Exponential decay: half-life = 730 days (2 years)
        import math
        score = math.exp(-0.693 * days_old / 730)
        return max(min(score, 1.0), 0.05)
    except (ValueError, TypeError):
        return 0.5


def compute_specificity_score(chunk: ScoredChunk) -> float:
    """Specificity signal: RATE_TABLE=1.0 > CLAUSE=0.9 > SECTION=0.7 > DEFINITION=0.6."""
    scores = {
        "RATE_TABLE": 1.0,
        "CLAUSE": 0.9,
        "CONDITION": 0.85,
        "SECTION": 0.7,
        "DEFINITION": 0.6,
        "PARTY": 0.4,
        "MEDICAL_CODE": 0.5,
        "AMENDMENT_DELTA": 0.8,
    }
    return scores.get(chunk.unit_type, 0.5)


def compute_scope_match(chunk: ScoredChunk, query: str) -> float:
    """Scope match: does chunk match query's provider/program/network scope?"""
    score = 0.5  # neutral baseline
    q_lower = query.lower()

    # Provider name match
    if chunk.provider_name and chunk.provider_name.lower() in q_lower:
        score += 0.3

    # Domain match
    domain_keywords = {
        "INPATIENT": ["inpatient", "per diem", "icu", "nicu", "med surg"],
        "OUTPATIENT": ["outpatient", "ambulatory", "surgery tier", "emergency"],
        "CAPITATION": ["capitation", "pmpm", "capitated"],
        "PROFESSIONAL": ["professional", "physician"],
    }
    for domain, keywords in domain_keywords.items():
        if chunk.rate_domain == domain and any(kw in q_lower for kw in keywords):
            score += 0.2
            break

    return min(score, 1.0)


def compute_authority_score(chunk: ScoredChunk) -> float:
    """Authority signal: base_agreement=1.0 > amendment=0.95 > memo=0.5."""
    fn = chunk.source_filename.lower() if chunk.source_filename else ""
    if "base" in fn or "agreement" in fn:
        return 1.0
    elif "amend" in fn:
        return 0.95
    elif "memo" in fn or "cover" in fn:
        return 0.5
    return 0.7


def compute_completeness_score(chunk: ScoredChunk, query: str) -> float:
    """Completeness: what fraction of query entities are covered in the chunk?"""
    q_tokens = set(query.lower().split())
    # Remove stop words
    q_tokens -= {"the", "a", "an", "is", "are", "what", "how", "for", "in", "of", "to"}

    if not q_tokens:
        return 0.5

    chunk_lower = chunk.unit_text.lower()
    covered = sum(1 for t in q_tokens if t in chunk_lower)
    return covered / len(q_tokens)


def score_legal_signals(chunks: List[ScoredChunk], query: str, intent: str) -> List[ScoredChunk]:
    """Apply all 6 legal signals with intent-specific weights."""
    weights = SIGNAL_WEIGHTS.get(intent, SIGNAL_WEIGHTS["GENERAL"])

    for chunk in chunks:
        signals = {
            "state": compute_state_score(chunk),
            "recency": compute_recency_score(chunk),
            "specificity": compute_specificity_score(chunk),
            "scope_match": compute_scope_match(chunk, query),
            "authority": compute_authority_score(chunk),
            "completeness": compute_completeness_score(chunk, query),
        }

        # Weighted sum
        legal_score = sum(signals[k] * weights[k] for k in signals)

        # Blend: 60% retrieval score + 40% legal signals
        chunk.score = 0.6 * chunk.score + 0.4 * legal_score

    chunks.sort(key=lambda c: c.score, reverse=True)
    return chunks


# ============================================================
# STAGE 3: DIVERSITY ENFORCEMENT
# ============================================================

def enforce_diversity(chunks: List[ScoredChunk], max_same_source: int = 2, top_k: int = 5) -> List[ScoredChunk]:
    """Prevent top-5 from being dominated by a single source document."""
    selected = []
    source_counts: Dict[str, int] = {}

    for chunk in chunks:
        src = chunk.source_filename
        if source_counts.get(src, 0) >= max_same_source:
            continue
        selected.append(chunk)
        source_counts[src] = source_counts.get(src, 0) + 1
        if len(selected) >= top_k:
            break

    return selected


# ============================================================
# MAIN RERANKING FUNCTION
# ============================================================

class Reranker:
    """3-stage reranking pipeline."""

    def rerank(self, query: str, candidates: List[ScoredChunk],
               intent: str = "GENERAL", top_k: int = 5) -> List[ScoredChunk]:
        """Full reranking pipeline: relevance → legal signals → diversity."""
        if not candidates:
            return []

        # Stage 1: Cross-encoder / LLM relevance scoring
        stage1 = score_relevance_llm(query, candidates, top_k=15)

        # Stage 2: Legal signal scoring
        stage2 = score_legal_signals(stage1, query, intent)

        # Stage 3: Diversity enforcement
        final = enforce_diversity(stage2, max_same_source=2, top_k=top_k)

        return final


# ============================================================
# MODULE TEST
# ============================================================
if __name__ == "__main__":
    reranker = Reranker()
    # Test with mock data
    mock = [ScoredChunk(
        unit_id=f"test_{i}", unit_text=f"Test chunk {i}",
        unit_type="RATE_TABLE", provider_name="Test Provider",
        source_filename="test.pdf", score=0.9 - i * 0.1,
        channel="semantic", is_current=True,
        effective_date="2024-01-01"
    ) for i in range(10)]

    results = reranker.rerank("inpatient per diem rate", mock, intent="RATE_LOOKUP")
    print(f"Reranked to {len(results)} results")
    for r in results:
        print(f"  {r.unit_id} | score={r.score:.4f}")
