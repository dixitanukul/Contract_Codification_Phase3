"""
V2 Step 6: Hybrid Retrieval Engine
====================================
4-channel retrieval with query understanding and Reciprocal Rank Fusion.

Channels:
  1. Semantic: Vector Search against idx_legal_units_v2
  2. Lexical: ILIKE/RLIKE SQL search on tbl_retrieval_legal_units
  3. Metadata: Direct SQL against V2 rate_rules/stop_loss/escalator tables
  4. Structural: Section-aware expansion of anchor results

Run AFTER: 04_legal_chunking_pipeline.py (VS index must be syncing)
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict
from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"
VS_ENDPOINT = "contract_intelligence_vs_endpoint"
VS_INDEX = f"{CATALOG}.{SCHEMA}.idx_legal_units_v2"
LLM_MODEL = "databricks-claude-sonnet-4-5"

# ============================================================
# DATA CLASSES
# ============================================================

@dataclass
class ParsedQuery:
    """Output of query understanding."""
    original: str
    intent: str  # RATE_LOOKUP | CLAUSE_SEARCH | COMPARISON | TIMELINE | GENERAL
    entities: Dict[str, List[str]] = field(default_factory=dict)
    temporal_scope: str = "CURRENT_ONLY"  # CURRENT_ONLY | HISTORICAL | AS_OF_DATE
    provider_filter: Optional[str] = None
    service_filter: Optional[str] = None
    keywords: List[str] = field(default_factory=list)


@dataclass
class ScoredChunk:
    """A retrieved legal unit with score metadata."""
    unit_id: str
    unit_text: str
    unit_type: str
    provider_name: str
    source_filename: str
    score: float
    channel: str  # semantic | lexical | metadata | structural
    is_current: bool = True
    section_type: str = ""
    rate_domain: str = ""
    effective_date: str = ""


# ============================================================
# QUERY UNDERSTANDING
# ============================================================

def understand_query(query: str) -> ParsedQuery:
    """Classify intent and extract entities from user query."""
    q_lower = query.lower()

    # Intent classification (rule-based fast path)
    if any(kw in q_lower for kw in ["rate", "per diem", "pmpm", "case rate", "reimburse", "pay"]):
        intent = "RATE_LOOKUP"
    elif any(kw in q_lower for kw in ["clause", "provision", "section", "article", "term"]):
        intent = "CLAUSE_SEARCH"
    elif any(kw in q_lower for kw in ["compare", "difference", "versus", "vs", "higher", "lower"]):
        intent = "COMPARISON"
    elif any(kw in q_lower for kw in ["timeline", "history", "amendment", "change", "when"]):
        intent = "TIMELINE"
    else:
        intent = "GENERAL"

    # Temporal scope
    if any(kw in q_lower for kw in ["current", "latest", "active", "now"]):
        temporal = "CURRENT_ONLY"
    elif any(kw in q_lower for kw in ["history", "historical", "all versions", "over time"]):
        temporal = "HISTORICAL"
    else:
        temporal = "CURRENT_ONLY"

    # Extract keywords (simple tokenization excluding stop words)
    stop_words = {"the", "a", "an", "is", "are", "was", "what", "how", "for", "in", "of", "to", "and", "or"}
    keywords = [w for w in q_lower.split() if w not in stop_words and len(w) > 2]

    return ParsedQuery(
        original=query,
        intent=intent,
        temporal_scope=temporal,
        keywords=keywords
    )


# ============================================================
# CHANNEL 1: SEMANTIC RETRIEVAL (Vector Search)
# ============================================================

def retrieve_semantic(parsed: ParsedQuery, top_k: int = 15) -> List[ScoredChunk]:
    """Semantic similarity search via Vector Search index."""
    from databricks.vector_search.client import VectorSearchClient
    vsc = VectorSearchClient(disable_notice=True)

    try:
        index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=VS_INDEX)
    except Exception as e:
        print(f"  [semantic] VS index not available: {str(e)[:80]}")
        return []

    # Build filters
    filters = {}
    if parsed.temporal_scope == "CURRENT_ONLY":
        filters["is_current"] = "true"
    if parsed.provider_filter:
        filters["provider_name"] = parsed.provider_filter

    try:
        results = index.similarity_search(
            query_text=parsed.original,
            columns=["unit_id", "unit_text", "unit_type", "provider_name",
                     "source_filename", "is_current", "section_type", "rate_domain",
                     "effective_date"],
            num_results=top_k,
            filters=filters if filters else None
        )
    except Exception as e:
        print(f"  [semantic] Search failed: {str(e)[:100]}")
        return []

    chunks = []
    if results and "result" in results and "data_array" in results["result"]:
        for row in results["result"]["data_array"]:
            chunks.append(ScoredChunk(
                unit_id=row[0],
                unit_text=row[1],
                unit_type=row[2],
                provider_name=row[3] or "",
                source_filename=row[4] or "",
                score=row[-1] if len(row) > 9 else 0.5,  # similarity score
                channel="semantic",
                is_current=bool(row[5]),
                section_type=row[6] or "",
                rate_domain=row[7] or "",
                effective_date=str(row[8]) if row[8] else ""
            ))
    return chunks


# ============================================================
# CHANNEL 2: LEXICAL RETRIEVAL (SQL ILIKE/RLIKE)
# ============================================================

def retrieve_lexical(parsed: ParsedQuery, top_k: int = 10) -> List[ScoredChunk]:
    """BM25-style lexical search using ILIKE on legal units."""
    # Build ILIKE conditions from keywords
    if not parsed.keywords:
        return []

    conditions = " AND ".join([
        f"unit_text ILIKE '%{kw}%'" for kw in parsed.keywords[:5]
    ])

    current_filter = "AND is_current = TRUE" if parsed.temporal_scope == "CURRENT_ONLY" else ""

    query = f"""
        SELECT unit_id, unit_text, unit_type, provider_name, source_filename,
               is_current, section_type, rate_domain, effective_date
        FROM {FQ}.tbl_retrieval_legal_units
        WHERE ({conditions})
        {current_filter}
        LIMIT {top_k}
    """

    try:
        rows = spark.sql(query).collect()
    except Exception as e:
        print(f"  [lexical] Query failed: {str(e)[:100]}")
        return []

    chunks = []
    for i, row in enumerate(rows):
        # Score decreases with position (simple ranking proxy)
        score = 0.8 - (i * 0.05)
        chunks.append(ScoredChunk(
            unit_id=row["unit_id"],
            unit_text=row["unit_text"],
            unit_type=row["unit_type"],
            provider_name=row["provider_name"] or "",
            source_filename=row["source_filename"] or "",
            score=max(score, 0.3),
            channel="lexical",
            is_current=bool(row["is_current"]),
            section_type=row["section_type"] or "",
            rate_domain=row["rate_domain"] or "",
            effective_date=str(row["effective_date"]) if row["effective_date"] else ""
        ))
    return chunks


# ============================================================
# CHANNEL 3: METADATA RETRIEVAL (Structured SQL on V2 tables)
# ============================================================

def retrieve_metadata(parsed: ParsedQuery, top_k: int = 10) -> List[ScoredChunk]:
    """Direct SQL against V2 structured tables for rate lookups."""
    if parsed.intent != "RATE_LOOKUP":
        return []

    # Build provider/service filters
    where_clauses = ["1=1"]
    if parsed.provider_filter:
        where_clauses.append(f"rr.provider_name ILIKE '%{parsed.provider_filter}%'")
    if parsed.service_filter:
        where_clauses.append(f"rr.service_category_raw ILIKE '%{parsed.service_filter}%'")
    # Keyword matching on service line
    for kw in parsed.keywords[:3]:
        if kw not in ("rate", "rates", "current", "provider"):
            where_clauses.append(
                f"(rr.service_category_raw ILIKE '%{kw}%' OR rr.provider_name ILIKE '%{kw}%')"
            )

    where = " AND ".join(where_clauses)

    query = f"""
        SELECT rr.rule_id, rr.provider_name, rr.service_category_raw,
               rr.rate_domain, rr.rate_text, rr.rate_numeric, rr.formula_type,
               rr.program, rr.network, rr.source_filename, rr.effective_date
        FROM {FQ}.tbl_reimb_rate_rules rr
        WHERE {where}
        LIMIT {top_k}
    """

    try:
        rows = spark.sql(query).collect()
    except Exception as e:
        print(f"  [metadata] Query failed: {str(e)[:100]}")
        return []

    chunks = []
    for i, row in enumerate(rows):
        text = (f"Provider: {row['provider_name']}\n"
                f"Service: {row['service_category_raw']}\n"
                f"Rate: {row['rate_text'] or row['rate_numeric']}\n"
                f"Domain: {row['rate_domain']}, Formula: {row['formula_type']}\n"
                f"Program: {row['program']}, Network: {row['network']}")
        chunks.append(ScoredChunk(
            unit_id=row["rule_id"],
            unit_text=text,
            unit_type="RATE_TABLE",
            provider_name=row["provider_name"] or "",
            source_filename=row["source_filename"] or "",
            score=0.9 - (i * 0.03),
            channel="metadata",
            is_current=True,
            rate_domain=row["rate_domain"] or "",
            effective_date=str(row["effective_date"]) if row["effective_date"] else ""
        ))
    return chunks


# ============================================================
# CHANNEL 4: STRUCTURAL EXPANSION
# ============================================================

def retrieve_structural(parsed: ParsedQuery, anchors: List[ScoredChunk], top_k: int = 5) -> List[ScoredChunk]:
    """Expand anchor results to include sibling sections from same document."""
    if not anchors:
        return []

    # Get source filenames and section types from top anchors
    anchor_files = list(set(c.source_filename for c in anchors[:5]))
    if not anchor_files:
        return []

    file_list = ",".join([f"'{f}'" for f in anchor_files[:3]])
    existing_ids = set(c.unit_id for c in anchors)

    query = f"""
        SELECT unit_id, unit_text, unit_type, provider_name, source_filename,
               is_current, section_type, rate_domain, effective_date
        FROM {FQ}.tbl_retrieval_legal_units
        WHERE source_filename IN ({file_list})
          AND unit_id NOT IN ({','.join([f"'{uid}'" for uid in list(existing_ids)[:20]])})
        LIMIT {top_k}
    """

    try:
        rows = spark.sql(query).collect()
    except Exception as e:
        print(f"  [structural] Query failed: {str(e)[:100]}")
        return []

    return [ScoredChunk(
        unit_id=row["unit_id"],
        unit_text=row["unit_text"],
        unit_type=row["unit_type"],
        provider_name=row["provider_name"] or "",
        source_filename=row["source_filename"] or "",
        score=0.5,
        channel="structural",
        is_current=bool(row["is_current"]),
        section_type=row["section_type"] or "",
        rate_domain=row["rate_domain"] or "",
        effective_date=str(row["effective_date"]) if row["effective_date"] else ""
    ) for row in rows]


# ============================================================
# RECIPROCAL RANK FUSION
# ============================================================

def fuse_results(channels: List[List[ScoredChunk]], parsed: ParsedQuery, k: int = 60) -> List[ScoredChunk]:
    """Reciprocal Rank Fusion with intent-weighted channel blending."""
    # Intent-specific channel weights
    WEIGHTS = {
        "RATE_LOOKUP": {"semantic": 0.2, "lexical": 0.1, "metadata": 0.6, "structural": 0.1},
        "CLAUSE_SEARCH": {"semantic": 0.5, "lexical": 0.25, "metadata": 0.05, "structural": 0.2},
        "COMPARISON": {"semantic": 0.3, "lexical": 0.2, "metadata": 0.4, "structural": 0.1},
        "TIMELINE": {"semantic": 0.3, "lexical": 0.2, "metadata": 0.2, "structural": 0.3},
        "GENERAL": {"semantic": 0.4, "lexical": 0.3, "metadata": 0.1, "structural": 0.2},
    }
    weights = WEIGHTS.get(parsed.intent, WEIGHTS["GENERAL"])

    # RRF scoring
    rrf_scores: Dict[str, float] = {}
    chunk_map: Dict[str, ScoredChunk] = {}

    for channel_results in channels:
        channel_name = channel_results[0].channel if channel_results else "unknown"
        weight = weights.get(channel_name, 0.1)

        for rank, chunk in enumerate(channel_results, 1):
            rrf = weight * (1.0 / (k + rank))
            rrf_scores[chunk.unit_id] = rrf_scores.get(chunk.unit_id, 0) + rrf
            if chunk.unit_id not in chunk_map:
                chunk_map[chunk.unit_id] = chunk

    # Sort by fused score
    sorted_ids = sorted(rrf_scores.keys(), key=lambda uid: rrf_scores[uid], reverse=True)

    results = []
    for uid in sorted_ids:
        chunk = chunk_map[uid]
        chunk.score = rrf_scores[uid]
        results.append(chunk)

    return results


# ============================================================
# MAIN RETRIEVAL FUNCTION
# ============================================================

class HybridRetriever:
    """Main retrieval orchestrator."""

    def retrieve(self, query: str, provider_id: str = None, top_k: int = 30) -> List[ScoredChunk]:
        """Full hybrid retrieval pipeline."""
        # 1. Query understanding
        parsed = understand_query(query)
        if provider_id:
            parsed.provider_filter = provider_id

        # 2. Multi-channel retrieval
        semantic = retrieve_semantic(parsed, top_k=15)
        lexical = retrieve_lexical(parsed, top_k=10)
        metadata = retrieve_metadata(parsed, top_k=10)
        structural = retrieve_structural(parsed, semantic[:5], top_k=5)

        # 3. Fusion
        all_channels = [ch for ch in [semantic, lexical, metadata, structural] if ch]
        if not all_channels:
            return []

        fused = fuse_results(all_channels, parsed)

        # 4. Return top-K
        return fused[:top_k]


# ============================================================
# MODULE TEST
# ============================================================
if __name__ == "__main__":
    retriever = HybridRetriever()
    results = retriever.retrieve("What is the inpatient per diem rate for Providence?")
    print(f"Retrieved {len(results)} results")
    for r in results[:5]:
        print(f"  [{r.channel}] {r.unit_type} | {r.provider_name[:20]} | score={r.score:.4f}")
