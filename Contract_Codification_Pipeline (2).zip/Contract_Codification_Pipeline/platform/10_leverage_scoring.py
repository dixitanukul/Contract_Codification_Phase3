"""
V2 Step 11: Leverage Scoring
==============================
Dual-perspective leverage scoring:
  - Plan leverage (5 components): revenue share, volume redirectability, market alternatives, quality, info asymmetry
  - Provider leverage (7 components): sole community, member lock, AMC, system size, payer diversity, brand, regulatory
  - Net score: plan_leverage - provider_leverage (-1 to +1)
  - Strategy recommendation based on leverage × spend quadrant

Run AFTER: 08_intelligence_pipeline.py
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"

print("=" * 60)
print("V2 LEVERAGE SCORING")
print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 60)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

# ============================================================
# CREATE TABLE
# ============================================================
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {FQ}.tbl_intel_leverage_scores (
    provider_id          STRING NOT NULL  COMMENT 'Provider ID',
    provider_name        STRING NOT NULL  COMMENT 'Provider name',
    
    -- Plan leverage components (0-1 each)
    plan_revenue_share   FLOAT            COMMENT 'Revenue share: provider spend / total network spend',
    plan_volume_redirect FLOAT            COMMENT 'Volume redirectability: alternatives available?',
    plan_market_share    FLOAT            COMMENT 'Plan market share in provider service area',
    plan_quality_lever   FLOAT            COMMENT 'Quality data advantage (tiering, P4P)',
    plan_info_asymmetry  FLOAT            COMMENT 'Information advantage (claims, benchmarks)',
    plan_leverage_total  FLOAT            COMMENT 'Weighted plan leverage score (0-1)',
    
    -- Provider leverage components (0-1 each)
    prov_sole_community  FLOAT            COMMENT 'Sole community provider? (0=no, 1=sole)',
    prov_member_lock     FLOAT            COMMENT 'Member attachment/lock-in strength',
    prov_amc_status      FLOAT            COMMENT 'Academic medical center status',
    prov_system_size     FLOAT            COMMENT 'Health system size/breadth',
    prov_payer_diversity  FLOAT           COMMENT 'Payer diversification (less BSC-dependent)',
    prov_brand_strength  FLOAT            COMMENT 'Consumer brand recognition',
    prov_regulatory      FLOAT            COMMENT 'Regulatory protection (essential community)',
    prov_leverage_total  FLOAT            COMMENT 'Weighted provider leverage score (0-1)',
    
    -- Net position
    net_leverage         FLOAT            COMMENT 'plan_leverage - provider_leverage (-1 to +1)',
    leverage_category    STRING           COMMENT 'STRONG_PLAN|MODERATE_PLAN|BALANCED|MODERATE_PROVIDER|STRONG_PROVIDER',
    
    -- Strategy
    recommended_posture  STRING           COMMENT 'AGGRESSIVE|FIRM|COLLABORATIVE|ACCOMMODATIVE|DEFENSIVE',
    negotiation_target_pct FLOAT          COMMENT 'Suggested rate reduction target (%)',
    
    -- Context
    estimated_spend      FLOAT            COMMENT 'From provider_spend_summary',
    rate_percentile      FLOAT            COMMENT 'Average rate percentile position',
    
    computed_at          TIMESTAMP        COMMENT 'Computation timestamp'
) USING DELTA
COMMENT 'Bilateral leverage scores for strategic negotiation positioning.'
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
""")

# ============================================================
# COMPUTE LEVERAGE SCORES
# Uses heuristics from available data (no claims feed yet)
# ============================================================
spark.sql(f"""
INSERT OVERWRITE {FQ}.tbl_intel_leverage_scores
WITH provider_stats AS (
    SELECT 
        s.provider_id, s.provider_name,
        s.total_rate_rules, s.estimated_annual_spend, s.avg_percentile,
        s.pct_above_median, s.has_stop_loss, s.has_escalator,
        -- Revenue share proxy: spend rank relative to max
        s.estimated_annual_spend / NULLIF(MAX(s.estimated_annual_spend) OVER (), 0) AS revenue_share_raw,
        -- Alternatives proxy: number of providers in same domain
        (SELECT COUNT(DISTINCT r2.provider_id) FROM {FQ}.tbl_reimb_rate_rules r2 
         WHERE r2.rate_domain = (SELECT rd.rate_domain FROM {FQ}.tbl_reimb_rate_rules rd WHERE rd.provider_id = s.provider_id LIMIT 1)) AS domain_competitors,
        -- System size proxy: total rate rules (more rules = bigger system)
        s.total_rate_rules / NULLIF(MAX(s.total_rate_rules) OVER (), 0) AS system_size_raw
    FROM {FQ}.tbl_intel_provider_spend_summary s
)
SELECT
    ps.provider_id, ps.provider_name,
    
    -- Plan leverage components
    -- Revenue share (low spend = plan has more leverage to walk away)
    ROUND(1.0 - LEAST(1.0, ps.revenue_share_raw * 2), 3) AS plan_revenue_share,
    -- Volume redirect (more competitors = easier to redirect)
    ROUND(LEAST(1.0, ps.domain_competitors / 100.0), 3) AS plan_volume_redirect,
    -- Market share (assume 25% for BSC in CA — fixed)
    0.25 AS plan_market_share,
    -- Quality lever (have data = 0.6 baseline)
    0.6 AS plan_quality_lever,
    -- Info asymmetry (we have benchmarks = 0.7)
    0.7 AS plan_info_asymmetry,
    -- Plan total (weighted: revenue 30%, redirect 25%, market 15%, quality 15%, info 15%)
    ROUND(
        (1.0 - LEAST(1.0, ps.revenue_share_raw * 2)) * 0.30
        + LEAST(1.0, ps.domain_competitors / 100.0) * 0.25
        + 0.25 * 0.15
        + 0.6 * 0.15
        + 0.7 * 0.15
    , 3) AS plan_leverage_total,
    
    -- Provider leverage components
    -- Sole community (heuristic: if very few competitors)
    ROUND(CASE WHEN ps.domain_competitors < 5 THEN 0.8 WHEN ps.domain_competitors < 15 THEN 0.4 ELSE 0.1 END, 3) AS prov_sole_community,
    -- Member lock (proxy: high rate = can charge because members want them)
    ROUND(LEAST(1.0, ps.pct_above_median / 100.0), 3) AS prov_member_lock,
    -- AMC status (proxy: many rate rules across domains = complex system = likely AMC)
    ROUND(CASE WHEN ps.total_rate_rules > 200 THEN 0.8 WHEN ps.total_rate_rules > 100 THEN 0.5 ELSE 0.2 END, 3) AS prov_amc_status,
    -- System size
    ROUND(LEAST(1.0, ps.system_size_raw * 1.5), 3) AS prov_system_size,
    -- Payer diversity (assume moderate — no data)
    0.5 AS prov_payer_diversity,
    -- Brand (proxy: above-median rates indicate brand power)
    ROUND(LEAST(1.0, GREATEST(0.0, (ps.pct_above_median - 40) / 60.0)), 3) AS prov_brand_strength,
    -- Regulatory (default low)
    0.2 AS prov_regulatory,
    -- Provider total (weighted: sole 25%, lock 15%, AMC 10%, size 20%, diversity 10%, brand 10%, regulatory 10%)
    ROUND(
        CASE WHEN ps.domain_competitors < 5 THEN 0.8 WHEN ps.domain_competitors < 15 THEN 0.4 ELSE 0.1 END * 0.25
        + LEAST(1.0, ps.pct_above_median / 100.0) * 0.15
        + CASE WHEN ps.total_rate_rules > 200 THEN 0.8 WHEN ps.total_rate_rules > 100 THEN 0.5 ELSE 0.2 END * 0.10
        + LEAST(1.0, ps.system_size_raw * 1.5) * 0.20
        + 0.5 * 0.10
        + LEAST(1.0, GREATEST(0.0, (ps.pct_above_median - 40) / 60.0)) * 0.10
        + 0.2 * 0.10
    , 3) AS prov_leverage_total,
    
    -- Net leverage
    ROUND(
        (  (1.0 - LEAST(1.0, ps.revenue_share_raw * 2)) * 0.30
            + LEAST(1.0, ps.domain_competitors / 100.0) * 0.25
            + 0.25 * 0.15 + 0.6 * 0.15 + 0.7 * 0.15)
        - (CASE WHEN ps.domain_competitors < 5 THEN 0.8 WHEN ps.domain_competitors < 15 THEN 0.4 ELSE 0.1 END * 0.25
            + LEAST(1.0, ps.pct_above_median / 100.0) * 0.15
            + CASE WHEN ps.total_rate_rules > 200 THEN 0.8 WHEN ps.total_rate_rules > 100 THEN 0.5 ELSE 0.2 END * 0.10
            + LEAST(1.0, ps.system_size_raw * 1.5) * 0.20
            + 0.5 * 0.10 + LEAST(1.0, GREATEST(0.0, (ps.pct_above_median - 40) / 60.0)) * 0.10 + 0.2 * 0.10)
    , 3) AS net_leverage,
    
    -- Category
    CASE
        WHEN (  (1.0 - LEAST(1.0, ps.revenue_share_raw * 2)) * 0.30 + LEAST(1.0, ps.domain_competitors / 100.0) * 0.25 + 0.25*0.15 + 0.6*0.15 + 0.7*0.15)
            - (CASE WHEN ps.domain_competitors < 5 THEN 0.8 WHEN ps.domain_competitors < 15 THEN 0.4 ELSE 0.1 END * 0.25 + LEAST(1.0, ps.pct_above_median / 100.0) * 0.15 + CASE WHEN ps.total_rate_rules > 200 THEN 0.8 WHEN ps.total_rate_rules > 100 THEN 0.5 ELSE 0.2 END * 0.10 + LEAST(1.0, ps.system_size_raw * 1.5) * 0.20 + 0.5*0.10 + LEAST(1.0, GREATEST(0.0, (ps.pct_above_median - 40) / 60.0)) * 0.10 + 0.2*0.10)
            > 0.2 THEN 'STRONG_PLAN'
        WHEN (  (1.0 - LEAST(1.0, ps.revenue_share_raw * 2)) * 0.30 + LEAST(1.0, ps.domain_competitors / 100.0) * 0.25 + 0.25*0.15 + 0.6*0.15 + 0.7*0.15)
            - (CASE WHEN ps.domain_competitors < 5 THEN 0.8 WHEN ps.domain_competitors < 15 THEN 0.4 ELSE 0.1 END * 0.25 + LEAST(1.0, ps.pct_above_median / 100.0) * 0.15 + CASE WHEN ps.total_rate_rules > 200 THEN 0.8 WHEN ps.total_rate_rules > 100 THEN 0.5 ELSE 0.2 END * 0.10 + LEAST(1.0, ps.system_size_raw * 1.5) * 0.20 + 0.5*0.10 + LEAST(1.0, GREATEST(0.0, (ps.pct_above_median - 40) / 60.0)) * 0.10 + 0.2*0.10)
            > 0.05 THEN 'MODERATE_PLAN'
        WHEN (  (1.0 - LEAST(1.0, ps.revenue_share_raw * 2)) * 0.30 + LEAST(1.0, ps.domain_competitors / 100.0) * 0.25 + 0.25*0.15 + 0.6*0.15 + 0.7*0.15)
            - (CASE WHEN ps.domain_competitors < 5 THEN 0.8 WHEN ps.domain_competitors < 15 THEN 0.4 ELSE 0.1 END * 0.25 + LEAST(1.0, ps.pct_above_median / 100.0) * 0.15 + CASE WHEN ps.total_rate_rules > 200 THEN 0.8 WHEN ps.total_rate_rules > 100 THEN 0.5 ELSE 0.2 END * 0.10 + LEAST(1.0, ps.system_size_raw * 1.5) * 0.20 + 0.5*0.10 + LEAST(1.0, GREATEST(0.0, (ps.pct_above_median - 40) / 60.0)) * 0.10 + 0.2*0.10)
            > -0.05 THEN 'BALANCED'
        WHEN (  (1.0 - LEAST(1.0, ps.revenue_share_raw * 2)) * 0.30 + LEAST(1.0, ps.domain_competitors / 100.0) * 0.25 + 0.25*0.15 + 0.6*0.15 + 0.7*0.15)
            - (CASE WHEN ps.domain_competitors < 5 THEN 0.8 WHEN ps.domain_competitors < 15 THEN 0.4 ELSE 0.1 END * 0.25 + LEAST(1.0, ps.pct_above_median / 100.0) * 0.15 + CASE WHEN ps.total_rate_rules > 200 THEN 0.8 WHEN ps.total_rate_rules > 100 THEN 0.5 ELSE 0.2 END * 0.10 + LEAST(1.0, ps.system_size_raw * 1.5) * 0.20 + 0.5*0.10 + LEAST(1.0, GREATEST(0.0, (ps.pct_above_median - 40) / 60.0)) * 0.10 + 0.2*0.10)
            > -0.2 THEN 'MODERATE_PROVIDER'
        ELSE 'STRONG_PROVIDER'
    END AS leverage_category,
    
    -- Strategy
    CASE
        WHEN ps.pct_above_median > 70 AND ps.revenue_share_raw < 0.1 THEN 'AGGRESSIVE'
        WHEN ps.pct_above_median > 60 THEN 'FIRM'
        WHEN ps.pct_above_median BETWEEN 40 AND 60 THEN 'COLLABORATIVE'
        WHEN ps.system_size_raw > 0.7 THEN 'ACCOMMODATIVE'
        ELSE 'COLLABORATIVE'
    END AS recommended_posture,
    
    -- Target reduction
    ROUND(GREATEST(0, LEAST(15, (ps.pct_above_median - 50) * 0.3)), 1) AS negotiation_target_pct,
    
    ps.estimated_annual_spend,
    ps.avg_percentile AS rate_percentile,
    current_timestamp()
FROM provider_stats ps
""")

lev_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_intel_leverage_scores").collect()[0]["n"]
print(f"\n✓ {lev_count} providers scored")
