"""
V2 Step 8: Citation Verification Framework
=============================================
Implements inline citation protocol + 6-check verification engine.

Checks:
  1. Uncited claim detection
  2. Numerical accuracy (numbers in answer match source)
  3. Entity scope correctness (right provider?)
  4. State correctness (not citing superseded as current?)
  5. NLI entailment (LLM judge: does source support claim?)
  6. Conditional completeness (conditions/exceptions preserved?)

Output: Calibrated confidence score + remediated answer.
Logs to tbl_retrieval_telemetry.

Run AFTER: 06_reranking_service.py
"""

from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from datetime import datetime
from pyspark.sql import SparkSession
import re
import json

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"
LLM_JUDGE = "databricks-claude-sonnet-4-5"

# ============================================================
# DATA CLASSES
# ============================================================

@dataclass
class Citation:
    """A single inline citation in the generated answer."""
    marker: str  # e.g., "[1]"
    unit_id: str  # source unit_id
    unit_text: str  # source content
    claim_text: str  # the claim this citation supports


@dataclass
class VerificationResult:
    """Output of the 6-check verification engine."""
    check_name: str
    passed: bool
    score: float  # 0-1 confidence
    details: str = ""


@dataclass
class VerifiedAnswer:
    """Final answer with verification metadata."""
    answer_text: str
    citations: List[Citation]
    confidence: float  # Calibrated 0-1
    verification_results: List[VerificationResult]
    disclaimers: List[str] = field(default_factory=list)
    needs_review: bool = False


# ============================================================
# TELEMETRY TABLE
# ============================================================

def ensure_telemetry_table():
    """Create telemetry table if not exists."""
    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {FQ}.tbl_retrieval_telemetry (
        query_id        STRING NOT NULL  COMMENT 'Unique query identifier',
        query_text      STRING           COMMENT 'User query',
        intent          STRING           COMMENT 'Classified intent',
        timestamp       TIMESTAMP        COMMENT 'When query was processed',
        
        -- Retrieval metrics
        candidates_count INT             COMMENT 'Total candidates from retrieval',
        reranked_count   INT             COMMENT 'Results after reranking',
        
        -- Verification
        confidence_score FLOAT           COMMENT 'Calibrated confidence 0-1',
        checks_passed    INT             COMMENT 'Number of checks passed (out of 6)',
        checks_total     INT             COMMENT 'Total checks run',
        verification_json STRING         COMMENT 'Full verification detail as JSON',
        
        -- Quality flags
        has_uncited_claims BOOLEAN       COMMENT 'TRUE if uncited claims detected',
        has_numerical_error BOOLEAN      COMMENT 'TRUE if numerical mismatch found',
        has_state_error   BOOLEAN        COMMENT 'TRUE if superseded cited as current',
        needs_review      BOOLEAN        COMMENT 'TRUE if flagged for human review',
        
        -- Answer
        answer_length    INT             COMMENT 'Character length of final answer',
        citations_count  INT             COMMENT 'Number of inline citations',
        disclaimers_count INT            COMMENT 'Number of disclaimers added',
        
        -- Performance
        latency_ms       FLOAT           COMMENT 'Total pipeline latency in ms'
    ) USING DELTA
    COMMENT 'Retrieval pipeline telemetry for monitoring and evaluation.'
    TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
    """)


# ============================================================
# CHECK 1: UNCITED CLAIM DETECTION
# ============================================================

def check_uncited_claims(answer: str, citations: List[Citation]) -> VerificationResult:
    """Detect claims in the answer that lack citation markers."""
    # Split answer into sentences
    sentences = re.split(r'[.!?]+', answer)
    cited_markers = set(re.findall(r'\[\d+\]', answer))

    # Sentences with factual claims (numbers, rates, dates) that need citation
    uncited = []
    for sent in sentences:
        sent = sent.strip()
        if not sent:
            continue
        # Check if sentence contains factual content
        has_facts = bool(re.search(r'\$[\d,]+|\d+%|\d{4}', sent))
        has_citation = bool(re.search(r'\[\d+\]', sent))
        if has_facts and not has_citation:
            uncited.append(sent[:80])

    passed = len(uncited) == 0
    score = 1.0 - min(len(uncited) / max(len(sentences), 1), 1.0)
    details = f"{len(uncited)} uncited factual claims" if uncited else "All claims cited"

    return VerificationResult(
        check_name="uncited_claims",
        passed=passed,
        score=score,
        details=details
    )


# ============================================================
# CHECK 2: NUMERICAL ACCURACY
# ============================================================

def check_numerical_accuracy(answer: str, citations: List[Citation]) -> VerificationResult:
    """Verify numbers in the answer match their cited sources."""
    # Extract numbers from answer
    answer_numbers = set(re.findall(r'\$[\d,]+\.?\d*|\d+\.?\d*%|\d{1,3}(?:,\d{3})+', answer))
    if not answer_numbers:
        return VerificationResult("numerical_accuracy", True, 1.0, "No numbers to verify")

    # Extract numbers from all cited sources
    source_numbers = set()
    for cit in citations:
        source_numbers.update(re.findall(r'\$[\d,]+\.?\d*|\d+\.?\d*%|\d{1,3}(?:,\d{3})+', cit.unit_text))

    # Check overlap
    verified = answer_numbers & source_numbers
    unverified = answer_numbers - source_numbers

    score = len(verified) / max(len(answer_numbers), 1)
    passed = len(unverified) == 0

    return VerificationResult(
        check_name="numerical_accuracy",
        passed=passed,
        score=score,
        details=f"{len(verified)}/{len(answer_numbers)} numbers verified"
    )


# ============================================================
# CHECK 3: ENTITY SCOPE CORRECTNESS
# ============================================================

def check_entity_scope(answer: str, citations: List[Citation], query: str) -> VerificationResult:
    """Verify cited sources are for the correct provider/entity."""
    # Extract provider names mentioned in query
    # Simple heuristic: look for capitalized multi-word names
    query_entities = set(re.findall(r'[A-Z][a-z]+(?: [A-Z][a-z]+)+', query))

    if not query_entities or not citations:
        return VerificationResult("entity_scope", True, 0.8, "No entity scope to verify")

    # Check if citations are from the queried provider
    mismatches = 0
    for cit in citations:
        # If the citation mentions a different provider than the query asks about
        for entity in query_entities:
            if entity.lower() not in cit.unit_text.lower() and entity.lower() in answer.lower():
                mismatches += 1

    score = 1.0 - min(mismatches / max(len(citations), 1), 1.0)
    passed = mismatches == 0

    return VerificationResult(
        check_name="entity_scope",
        passed=passed,
        score=score,
        details=f"{mismatches} potential scope mismatches"
    )


# ============================================================
# CHECK 4: STATE CORRECTNESS
# ============================================================

def check_state_correctness(citations: List[Citation], chunks_metadata: List[dict]) -> VerificationResult:
    """Verify no superseded content is cited as current."""
    superseded_cited = 0
    for cit in citations:
        # Look up the chunk's is_current flag
        for meta in chunks_metadata:
            if meta.get("unit_id") == cit.unit_id:
                if not meta.get("is_current", True):
                    superseded_cited += 1
                break

    passed = superseded_cited == 0
    score = 1.0 if passed else max(0.1, 1.0 - superseded_cited * 0.3)

    return VerificationResult(
        check_name="state_correctness",
        passed=passed,
        score=score,
        details=f"{superseded_cited} superseded sources cited" if not passed else "All cited sources are current"
    )


# ============================================================
# CHECK 5: NLI ENTAILMENT (simplified — full version uses LLM)
# ============================================================

def check_entailment(answer: str, citations: List[Citation]) -> VerificationResult:
    """Check if cited sources actually support the claims made."""
    # Simplified: check keyword overlap between claim and source
    # Full version would call LLM judge for NLI
    if not citations:
        return VerificationResult("entailment", True, 0.5, "No citations to verify")

    supported = 0
    for cit in citations:
        # Simple overlap heuristic
        claim_words = set(cit.claim_text.lower().split())
        source_words = set(cit.unit_text.lower().split())
        overlap = len(claim_words & source_words) / max(len(claim_words), 1)
        if overlap > 0.3:
            supported += 1

    score = supported / max(len(citations), 1)
    passed = score >= 0.7

    return VerificationResult(
        check_name="entailment",
        passed=passed,
        score=score,
        details=f"{supported}/{len(citations)} citations entailed"
    )


# ============================================================
# CHECK 6: CONDITIONAL COMPLETENESS
# ============================================================

def check_conditional_completeness(answer: str, citations: List[Citation]) -> VerificationResult:
    """Check that conditions/exceptions from sources are preserved in answer."""
    # Look for conditional language in sources not reflected in answer
    conditional_patterns = [
        r'(?:subject to|except|unless|provided that|notwithstanding)',
        r'(?:not to exceed|minimum of|maximum of|cap of)',
        r'(?:effective \w+ \d+|expires|terminat)',
    ]

    missing_conditions = 0
    total_conditions = 0

    for cit in citations:
        for pattern in conditional_patterns:
            matches = re.findall(pattern, cit.unit_text, re.IGNORECASE)
            total_conditions += len(matches)
            for match in matches:
                if match.lower() not in answer.lower():
                    missing_conditions += 1

    if total_conditions == 0:
        return VerificationResult("conditional_completeness", True, 1.0, "No conditions to check")

    score = 1.0 - min(missing_conditions / max(total_conditions, 1), 1.0)
    passed = score >= 0.7

    return VerificationResult(
        check_name="conditional_completeness",
        passed=passed,
        score=score,
        details=f"{total_conditions - missing_conditions}/{total_conditions} conditions preserved"
    )


# ============================================================
# CONFIDENCE CALIBRATION
# ============================================================

def calibrate_confidence(results: List[VerificationResult]) -> float:
    """Compute calibrated confidence from verification results."""
    if not results:
        return 0.5

    # Weighted average of check scores
    weights = {
        "uncited_claims": 0.20,
        "numerical_accuracy": 0.25,
        "entity_scope": 0.15,
        "state_correctness": 0.20,
        "entailment": 0.15,
        "conditional_completeness": 0.05,
    }

    weighted_sum = sum(
        r.score * weights.get(r.check_name, 0.1)
        for r in results
    )
    total_weight = sum(weights.get(r.check_name, 0.1) for r in results)

    return round(weighted_sum / max(total_weight, 0.01), 3)


# ============================================================
# MAIN VERIFICATION ENGINE
# ============================================================

class CitationVerifier:
    """Full citation verification pipeline."""

    def __init__(self):
        ensure_telemetry_table()

    def verify(self, answer: str, citations: List[Citation],
               query: str, chunks_metadata: List[dict] = None) -> VerifiedAnswer:
        """Run all 6 verification checks and produce verified answer."""
        if chunks_metadata is None:
            chunks_metadata = []

        results = [
            check_uncited_claims(answer, citations),
            check_numerical_accuracy(answer, citations),
            check_entity_scope(answer, citations, query),
            check_state_correctness(citations, chunks_metadata),
            check_entailment(answer, citations),
            check_conditional_completeness(answer, citations),
        ]

        confidence = calibrate_confidence(results)
        checks_passed = sum(1 for r in results if r.passed)

        # Determine if answer needs review
        needs_review = confidence < 0.6 or any(
            not r.passed for r in results
            if r.check_name in ("state_correctness", "numerical_accuracy")
        )

        # Add disclaimers for low-confidence areas
        disclaimers = []
        if not results[3].passed:  # state_correctness
            disclaimers.append("⚠️ Some cited provisions may have been superseded. Verify currency.")
        if not results[1].passed:  # numerical_accuracy
            disclaimers.append("⚠️ Some numerical values could not be verified against source documents.")
        if confidence < 0.5:
            disclaimers.append("⚠️ Low confidence answer. Please verify against original contract documents.")

        return VerifiedAnswer(
            answer_text=answer,
            citations=citations,
            confidence=confidence,
            verification_results=results,
            disclaimers=disclaimers,
            needs_review=needs_review
        )

    def log_telemetry(self, query_id: str, query: str, intent: str,
                      verified: VerifiedAnswer, latency_ms: float,
                      candidates_count: int = 0, reranked_count: int = 0):
        """Log verification results to telemetry table."""
        checks_passed = sum(1 for r in verified.verification_results if r.passed)
        verification_json = json.dumps([
            {"check": r.check_name, "passed": r.passed, "score": r.score, "details": r.details}
            for r in verified.verification_results
        ])

        spark.sql(f"""
            INSERT INTO {FQ}.tbl_retrieval_telemetry VALUES (
                '{query_id}', '{query.replace("'", "''")}', '{intent}',
                current_timestamp(),
                {candidates_count}, {reranked_count},
                {verified.confidence}, {checks_passed}, 6,
                '{verification_json.replace("'", "''")}',
                {str(not verified.verification_results[0].passed).lower()},
                {str(not verified.verification_results[1].passed).lower()},
                {str(not verified.verification_results[3].passed).lower()},
                {str(verified.needs_review).lower()},
                {len(verified.answer_text)}, {len(verified.citations)},
                {len(verified.disclaimers)},
                {latency_ms}
            )
        """)


# ============================================================
# MODULE TEST
# ============================================================
if __name__ == "__main__":
    verifier = CitationVerifier()

    # Mock test
    test_citations = [
        Citation(marker="[1]", unit_id="test_1",
                 unit_text="The inpatient per diem rate is $2,500 per day, effective January 1, 2024.",
                 claim_text="The rate is $2,500 per day")
    ]
    result = verifier.verify(
        answer="The inpatient per diem rate is $2,500 per day [1].",
        citations=test_citations,
        query="What is the inpatient per diem rate?"
    )
    print(f"Confidence: {result.confidence}")
    print(f"Checks passed: {sum(1 for r in result.verification_results if r.passed)}/6")
    print(f"Needs review: {result.needs_review}")
    for r in result.verification_results:
        print(f"  {'✓' if r.passed else '✗'} {r.check_name}: {r.score:.2f} — {r.details}")
