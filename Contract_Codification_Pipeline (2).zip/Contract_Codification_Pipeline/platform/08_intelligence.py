"""
V2 Step 9: Spend-Weighted Intelligence Pipeline
=================================================
Computes negotiation intelligence from V2 rate rules + taxonomy:
  1. Benchmark results (percentile rates per service line)
  2. Provider spend summary (total spend, rank, savings opportunity)
  3. Service-line spend detail (per-line breakdown)
  4. Savings opportunities (Pareto-ranked by annual $ impact)
  5. Renewal priority scoring

Since CLAIMS_AVAILABLE=False, uses estimated volumes from rate distribution.
All metrics marked source='estimated' until claims feed connected.

Run AFTER: 03_reimbursement_migration.py
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"
CLAIMS_AVAILABLE = False

print("=" * 60)
print("V2 INTELLIGENCE PIPELINE")
print(f"  Claims: {'AVAILABLE' if CLAIMS_AVAILABLE else 'ESTIMATED (heuristic volumes)'}")
print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 60)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

# ============================================================
# TABLE 1: tbl_intel_benchmark_results
# Percentile rates per service line across all providers
# ============================================================
print("\n[1] Creating benchmark results...")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {FQ}.tbl_intel_benchmark_results (
    benchmark_id    STRING NOT NULL  COMMENT 'Unique benchmark row ID',
    rate_domain     STRING NOT NULL  COMMENT 'INPATIENT|OUTPATIENT|CAPITATION|PROFESSIONAL',
    service_line    STRING NOT NULL  COMMENT 'Service line (from rate_rules or taxonomy)',
    formula_type    STRING           COMMENT 'Formula type for this benchmark group',
    
    -- Percentile distribution
    p10             FLOAT            COMMENT '10th percentile rate',
    p25             FLOAT            COMMENT '25th percentile rate',
    p50_median      FLOAT            COMMENT 'Median rate (50th percentile)',
    p75             FLOAT            COMMENT '75th percentile rate',
    p90             FLOAT            COMMENT '90th percentile rate',
    
    -- Stats
    mean_rate       FLOAT            COMMENT 'Mean rate across providers',
    provider_count  INT              COMMENT 'Number of providers with this service line',
    rate_count      INT              COMMENT 'Total rate entries in this group',
    std_dev         FLOAT            COMMENT 'Standard deviation of rates',
    
    -- Metadata
    computed_at     TIMESTAMP        COMMENT 'When this benchmark was computed',
    source          STRING           COMMENT 'estimated|claims_weighted'
) USING DELTA
COMMENT 'Percentile rate benchmarks by service line. Foundation for savings analysis.'
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
""")

# Populate benchmarks from rate_rules
spark.sql(f"""
INSERT OVERWRITE {FQ}.tbl_intel_benchmark_results
SELECT
    sha2(concat_ws('|', rate_domain, service_line, formula_type), 256) AS benchmark_id,
    rate_domain,
    service_line,
    formula_type,
    percentile_approx(rate_numeric, 0.10) AS p10,
    percentile_approx(rate_numeric, 0.25) AS p25,
    percentile_approx(rate_numeric, 0.50) AS p50_median,
    percentile_approx(rate_numeric, 0.75) AS p75,
    percentile_approx(rate_numeric, 0.90) AS p90,
    AVG(rate_numeric) AS mean_rate,
    COUNT(DISTINCT provider_id) AS provider_count,
    COUNT(*) AS rate_count,
    STDDEV(rate_numeric) AS std_dev,
    current_timestamp() AS computed_at,
    'estimated' AS source
FROM {FQ}.tbl_reimb_rate_rules
WHERE rate_numeric IS NOT NULL AND rate_numeric > 0
GROUP BY rate_domain, service_line, formula_type
HAVING COUNT(*) >= 3
""")

bench_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_intel_benchmark_results").collect()[0]["n"]
print(f"  ✓ {bench_count} benchmark groups computed")

# ============================================================
# TABLE 2: tbl_intel_provider_spend_summary
# Provider-level aggregated intelligence
# ============================================================
print("\n[2] Creating provider spend summary...")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {FQ}.tbl_intel_provider_spend_summary (
    provider_id         STRING NOT NULL  COMMENT 'Provider ID',
    provider_name       STRING NOT NULL  COMMENT 'Provider name',
    
    -- Rate profile
    total_rate_rules    INT              COMMENT 'Total rate rules for this provider',
    avg_rate            FLOAT            COMMENT 'Average rate across all service lines',
    rate_domains        STRING           COMMENT 'Comma-separated domains (INPATIENT,OUTPATIENT,...)',
    
    -- Estimated spend (before claims)
    estimated_annual_spend FLOAT         COMMENT 'Estimated annual spend ($)',
    spend_rank          INT              COMMENT 'Rank by estimated spend (1=highest)',
    
    -- Benchmark position
    pct_above_median    FLOAT            COMMENT 'Percent of rates above median benchmark',
    avg_percentile      FLOAT            COMMENT 'Average percentile position (0-100)',
    
    -- Savings opportunity
    total_savings_opportunity FLOAT      COMMENT 'Estimated annual savings if moved to median ($)',
    savings_rank        INT              COMMENT 'Rank by savings opportunity (1=most savings)',
    
    -- Contract context
    contract_count      INT              COMMENT 'Number of active contracts',
    has_stop_loss       BOOLEAN          COMMENT 'At least one stop-loss provision',
    has_escalator       BOOLEAN          COMMENT 'At least one escalator provision',
    latest_effective    DATE             COMMENT 'Most recent rate effective date',
    
    -- Metadata
    computed_at         TIMESTAMP        COMMENT 'When this was computed',
    source              STRING           COMMENT 'estimated|claims_weighted'
) USING DELTA
COMMENT 'Provider-level spend summary with savings opportunity quantification.'
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
""")

spark.sql(f"""
INSERT OVERWRITE {FQ}.tbl_intel_provider_spend_summary
WITH provider_rates AS (
    SELECT 
        rr.provider_id, rr.provider_name,
        COUNT(*) AS total_rate_rules,
        AVG(rr.rate_numeric) AS avg_rate,
        collect_set(rr.rate_domain) AS domains,
        MAX(rr.effective_date) AS latest_effective,
        MAX(CASE WHEN rr.has_stop_loss THEN 1 ELSE 0 END) AS has_sl,
        MAX(CASE WHEN rr.has_escalator THEN 1 ELSE 0 END) AS has_esc
    FROM {FQ}.tbl_reimb_rate_rules rr
    WHERE rr.rate_numeric IS NOT NULL AND rr.rate_numeric > 0
    GROUP BY rr.provider_id, rr.provider_name
),
rate_vs_benchmark AS (
    SELECT
        rr.provider_id,
        AVG(CASE WHEN rr.rate_numeric > b.p50_median THEN 1.0 ELSE 0.0 END) * 100 AS pct_above_median,
        AVG(
            CASE 
                WHEN rr.rate_numeric <= b.p10 THEN 10
                WHEN rr.rate_numeric <= b.p25 THEN 25
                WHEN rr.rate_numeric <= b.p50_median THEN 50
                WHEN rr.rate_numeric <= b.p75 THEN 75
                WHEN rr.rate_numeric <= b.p90 THEN 90
                ELSE 95
            END
        ) AS avg_percentile,
        SUM(GREATEST(rr.rate_numeric - b.p50_median, 0)) AS total_savings_raw
    FROM {FQ}.tbl_reimb_rate_rules rr
    JOIN {FQ}.tbl_intel_benchmark_results b
        ON rr.rate_domain = b.rate_domain 
        AND rr.service_line = b.service_line
        AND rr.formula_type = b.formula_type
    WHERE rr.rate_numeric IS NOT NULL AND rr.rate_numeric > 0
    GROUP BY rr.provider_id
)
SELECT
    pr.provider_id,
    pr.provider_name,
    pr.total_rate_rules,
    ROUND(pr.avg_rate, 2) AS avg_rate,
    array_join(pr.domains, ',') AS rate_domains,
    -- Estimated spend: avg_rate * estimated volume * 12 months
    ROUND(pr.avg_rate * pr.total_rate_rules * 50, 0) AS estimated_annual_spend,
    CAST(ROW_NUMBER() OVER (ORDER BY pr.avg_rate * pr.total_rate_rules DESC) AS INT) AS spend_rank,
    ROUND(COALESCE(rb.pct_above_median, 50), 1) AS pct_above_median,
    ROUND(COALESCE(rb.avg_percentile, 50), 1) AS avg_percentile,
    ROUND(COALESCE(rb.total_savings_raw * 12, 0), 0) AS total_savings_opportunity,
    CAST(ROW_NUMBER() OVER (ORDER BY COALESCE(rb.total_savings_raw, 0) DESC) AS INT) AS savings_rank,
    (SELECT COUNT(*) FROM {FQ}.tbl_v2_contract_registry c 
     WHERE c.provider_id = pr.provider_id AND c.status = 'ACTIVE') AS contract_count,
    CASE WHEN pr.has_sl > 0 THEN TRUE ELSE FALSE END AS has_stop_loss,
    CASE WHEN pr.has_esc > 0 THEN TRUE ELSE FALSE END AS has_escalator,
    pr.latest_effective,
    current_timestamp() AS computed_at,
    'estimated' AS source
FROM provider_rates pr
LEFT JOIN rate_vs_benchmark rb ON pr.provider_id = rb.provider_id
""")

spend_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_intel_provider_spend_summary").collect()[0]["n"]
print(f"  ✓ {spend_count} provider summaries computed")

# ============================================================
# TABLE 3: tbl_intel_savings_opportunity
# Pareto-ranked savings by provider × service line
# ============================================================
print("\n[3] Creating savings opportunities (Pareto-ranked)...")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {FQ}.tbl_intel_savings_opportunity (
    opportunity_id      STRING NOT NULL  COMMENT 'Unique opportunity ID',
    provider_id         STRING NOT NULL  COMMENT 'Provider ID',
    provider_name       STRING NOT NULL  COMMENT 'Provider name',
    rate_domain         STRING NOT NULL  COMMENT 'Rate domain',
    service_line        STRING NOT NULL  COMMENT 'Service line',
    
    -- Current vs target
    current_rate        FLOAT            COMMENT 'Current contracted rate',
    benchmark_median    FLOAT            COMMENT 'Median benchmark rate',
    benchmark_p25       FLOAT            COMMENT '25th percentile (aggressive target)',
    rate_gap            FLOAT            COMMENT 'Current - median (excess)',
    rate_gap_pct        FLOAT            COMMENT 'Gap as % of current rate',
    
    -- Impact
    estimated_annual_savings FLOAT       COMMENT 'Estimated annual savings if moved to median',
    cumulative_pct      FLOAT            COMMENT 'Cumulative % of total savings (Pareto)',
    pareto_rank         INT              COMMENT 'Rank (1=highest impact)',
    
    -- Context
    formula_type        STRING           COMMENT 'Rate formula type',
    effective_date      DATE             COMMENT 'Rate effective date',
    source_filename     STRING           COMMENT 'Contract source document',
    
    computed_at         TIMESTAMP        COMMENT 'Computation timestamp',
    source              STRING           COMMENT 'estimated|claims_weighted'
) USING DELTA
COMMENT 'Savings opportunities Pareto-ranked by estimated annual dollar impact.'
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
""")

spark.sql(f"""
INSERT OVERWRITE {FQ}.tbl_intel_savings_opportunity
WITH gaps AS (
    SELECT
        rr.provider_id, rr.provider_name, rr.rate_domain, rr.service_line,
        rr.rate_numeric AS current_rate,
        b.p50_median AS benchmark_median,
        b.p25 AS benchmark_p25,
        rr.rate_numeric - b.p50_median AS rate_gap,
        ROUND((rr.rate_numeric - b.p50_median) / NULLIF(rr.rate_numeric, 0) * 100, 1) AS rate_gap_pct,
        (rr.rate_numeric - b.p50_median) * 50 * 12 AS estimated_annual_savings,
        rr.formula_type, rr.effective_date, rr.source_filename
    FROM {FQ}.tbl_reimb_rate_rules rr
    JOIN {FQ}.tbl_intel_benchmark_results b
        ON rr.rate_domain = b.rate_domain AND rr.service_line = b.service_line
        AND rr.formula_type = b.formula_type
    WHERE rr.rate_numeric > b.p50_median
      AND rr.rate_numeric IS NOT NULL
),
ranked AS (
    SELECT *,
        ROW_NUMBER() OVER (ORDER BY estimated_annual_savings DESC) AS pareto_rank,
        SUM(estimated_annual_savings) OVER (ORDER BY estimated_annual_savings DESC) AS running_total,
        SUM(estimated_annual_savings) OVER () AS grand_total
    FROM gaps
)
SELECT
    sha2(concat_ws('|', provider_id, rate_domain, service_line), 256) AS opportunity_id,
    provider_id, provider_name, rate_domain, service_line,
    current_rate, benchmark_median, benchmark_p25, rate_gap, rate_gap_pct,
    ROUND(estimated_annual_savings, 0) AS estimated_annual_savings,
    ROUND(running_total / NULLIF(grand_total, 0) * 100, 1) AS cumulative_pct,
    CAST(pareto_rank AS INT),
    formula_type, effective_date, source_filename,
    current_timestamp(), 'estimated'
FROM ranked
WHERE pareto_rank <= 500
""")

savings_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_intel_savings_opportunity").collect()[0]["n"]
print(f"  ✓ {savings_count} savings opportunities ranked")

# ============================================================
# TABLE 4: tbl_intel_renewal_priority
# ============================================================
print("\n[4] Creating renewal priority scores...")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {FQ}.tbl_intel_renewal_priority (
    provider_id         STRING NOT NULL  COMMENT 'Provider ID',
    provider_name       STRING NOT NULL  COMMENT 'Provider name',
    contract_id         STRING           COMMENT 'FK to contract registry',
    
    -- Urgency (0-40)
    urgency_score       FLOAT            COMMENT 'Urgency component (0-40)',
    days_to_expiry      INT              COMMENT 'Days until contract expires',
    auto_renewal        BOOLEAN          COMMENT 'Whether contract auto-renews',
    
    -- Impact (0-40)
    impact_score        FLOAT            COMMENT 'Financial impact component (0-40)',
    estimated_spend     FLOAT            COMMENT 'Estimated annual spend',
    savings_opportunity FLOAT            COMMENT 'Savings if renegotiated',
    
    -- Risk (0-20)
    risk_score          FLOAT            COMMENT 'Network risk component (0-20)',
    pct_above_median    FLOAT            COMMENT 'Percent of rates above median',
    
    -- Total
    priority_score      FLOAT            COMMENT 'Total priority (0-100)',
    priority_rank       INT              COMMENT 'Rank (1=most urgent)',
    recommended_action  STRING           COMMENT 'ALLOW_AUTO_RENEW|NEGOTIATE|ISSUE_NON_RENEWAL|ESCALATE',
    
    computed_at         TIMESTAMP        COMMENT 'Computation timestamp'
) USING DELTA
COMMENT 'Contract renewal priority scoring for proactive negotiation planning.'
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
""")

spark.sql(f"""
INSERT OVERWRITE {FQ}.tbl_intel_renewal_priority
WITH base AS (
    SELECT
        c.provider_id, c.provider_name, c.contract_id,
        DATEDIFF(c.effective_to, current_date()) AS days_to_expiry,
        CASE WHEN c.auto_renewal THEN TRUE ELSE FALSE END AS auto_renewal,
        COALESCE(s.estimated_annual_spend, 0) AS estimated_spend,
        COALESCE(s.total_savings_opportunity, 0) AS savings_opportunity,
        COALESCE(s.pct_above_median, 50) AS pct_above_median
    FROM {FQ}.tbl_v2_contract_registry c
    LEFT JOIN {FQ}.tbl_intel_provider_spend_summary s ON c.provider_id = s.provider_id
    WHERE c.status = 'ACTIVE'
)
SELECT
    provider_id, provider_name, contract_id,
    -- Urgency: higher if expiring soon
    CAST(CASE
        WHEN days_to_expiry IS NULL THEN 10
        WHEN days_to_expiry < 30 THEN 40
        WHEN days_to_expiry < 90 THEN 30
        WHEN days_to_expiry < 180 THEN 20
        WHEN days_to_expiry < 365 THEN 10
        ELSE 5
    END AS FLOAT) AS urgency_score,
    days_to_expiry, auto_renewal,
    -- Impact: higher spend/savings = higher priority
    CAST(LEAST(40, estimated_spend / NULLIF((SELECT MAX(estimated_annual_spend) FROM {FQ}.tbl_intel_provider_spend_summary), 0) * 40) AS FLOAT) AS impact_score,
    estimated_spend, savings_opportunity,
    -- Risk: rates above market
    CAST(LEAST(20, (pct_above_median - 50) / 50 * 20) AS FLOAT) AS risk_score,
    pct_above_median,
    -- Total
    CAST(
        CASE WHEN days_to_expiry IS NULL THEN 10 WHEN days_to_expiry < 30 THEN 40 WHEN days_to_expiry < 90 THEN 30 WHEN days_to_expiry < 180 THEN 20 WHEN days_to_expiry < 365 THEN 10 ELSE 5 END
        + LEAST(40, estimated_spend / NULLIF((SELECT MAX(estimated_annual_spend) FROM {FQ}.tbl_intel_provider_spend_summary), 0) * 40)
        + LEAST(20, (pct_above_median - 50) / 50 * 20)
    AS FLOAT) AS priority_score,
    CAST(ROW_NUMBER() OVER (ORDER BY
        CASE WHEN days_to_expiry IS NULL THEN 10 WHEN days_to_expiry < 30 THEN 40 WHEN days_to_expiry < 90 THEN 30 WHEN days_to_expiry < 180 THEN 20 WHEN days_to_expiry < 365 THEN 10 ELSE 5 END
        + LEAST(40, estimated_spend / NULLIF((SELECT MAX(estimated_annual_spend) FROM {FQ}.tbl_intel_provider_spend_summary), 0) * 40)
        + LEAST(20, (pct_above_median - 50) / 50 * 20)
    DESC) AS INT) AS priority_rank,
    CASE
        WHEN savings_opportunity > 100000 THEN 'NEGOTIATE'
        WHEN pct_above_median > 70 THEN 'NEGOTIATE'
        WHEN days_to_expiry IS NOT NULL AND days_to_expiry < 60 AND savings_opportunity < 10000 THEN 'ALLOW_AUTO_RENEW'
        WHEN pct_above_median > 85 THEN 'ISSUE_NON_RENEWAL'
        ELSE 'ALLOW_AUTO_RENEW'
    END AS recommended_action,
    current_timestamp()
FROM base
""")

renewal_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_intel_renewal_priority").collect()[0]["n"]
print(f"  ✓ {renewal_count} renewal priorities scored")

# ============================================================
# SUMMARY
# ============================================================
print("\n" + "=" * 60)
print("INTELLIGENCE PIPELINE COMPLETE")
print("=" * 60)
tables = [
    "tbl_intel_benchmark_results",
    "tbl_intel_provider_spend_summary",
    "tbl_intel_savings_opportunity",
    "tbl_intel_renewal_priority",
]
for t in tables:
    c = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.{t}").collect()[0]["n"]
    print(f"  {t:<40} {c:>6} rows")
print("=" * 60)
