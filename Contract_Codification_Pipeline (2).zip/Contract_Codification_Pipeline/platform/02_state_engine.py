"""
V2 Step 4: State Engine — Contract & Amendment Registry Population
===================================================================
Populates the state engine tables from existing V1 extraction data.
Uses structural signals for deterministic scope classification.

Run AFTER: 01_execute_ddl.py
Run BEFORE: 04_legal_chunking_pipeline.py

Results (initial population):
  - tbl_v2_contract_registry: ~1,948 contracts (139+ providers)
  - tbl_v2_amendment_registry: ~1,570 amendments with scope classification
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"

def log_step(name, status, details=""):
    ts = datetime.now().strftime("%H:%M:%S")
    icon = "✓" if status == "SUCCESS" else "✗" if status == "FAILED" else "○"
    print(f"[{ts}] {icon} {name}: {status}")
    if details:
        print(f"    {details}")

print("=" * 60)
print("V2 STATE ENGINE — Population")
print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 60)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

# ============================================================
# STEP 1: Populate Contract Registry
# One row per unique provider × base agreement document
# Source: tbl_genie_amendment_timeline (base agreement rows)
# ============================================================
log_step("Contract Registry", "RUNNING")

spark.sql(f"""
INSERT INTO {FQ}.tbl_v2_contract_registry (
    contract_id, provider_id, provider_name,
    agreement_type, payment_model, network_scope,
    status, effective_from, effective_to,
    auto_renewal, term_years,
    base_agreement_doc, total_amendments, latest_amendment_date, latest_amendment_doc,
    state_computed_at, state_version, computation_rule
)
SELECT
    sha2(concat_ws('|', a.provider_id, a.source_filename), 256) AS contract_id,
    a.provider_id,
    a.provider_name,
    CASE
        WHEN a.agreement_type ILIKE '%capitation%' THEN 'capitation'
        WHEN a.agreement_type ILIKE '%fee%service%' OR a.agreement_type ILIKE '%ffs%' THEN 'fee_for_service'
        WHEN a.agreement_type ILIKE '%settlement%' THEN 'settlement'
        ELSE 'mixed'
    END AS agreement_type,
    CASE
        WHEN a.payment_type ILIKE '%per_diem%' OR a.payment_type ILIKE '%per diem%' THEN 'per_diem'
        WHEN a.payment_type ILIKE '%case_rate%' OR a.payment_type ILIKE '%case rate%' THEN 'case_rate'
        WHEN a.payment_type ILIKE '%percentage%' OR a.payment_type ILIKE '%pct%' THEN 'percentage'
        WHEN a.payment_type ILIKE '%pmpm%' OR a.payment_type ILIKE '%capitation%' THEN 'pmpm'
        ELSE 'mixed'
    END AS payment_model,
    'commercial' AS network_scope,
    CASE
        WHEN a.expiration_date_parsed IS NOT NULL AND a.expiration_date_parsed < current_date() THEN 'EXPIRED'
        ELSE 'ACTIVE'
    END AS status,
    a.effective_date_parsed AS effective_from,
    a.expiration_date_parsed AS effective_to,
    CASE WHEN a.auto_renewal = 'True' THEN TRUE ELSE FALSE END AS auto_renewal,
    try_cast(a.contract_term_years AS FLOAT) AS term_years,
    a.source_filename AS base_agreement_doc,
    (SELECT COUNT(*) FROM {FQ}.tbl_genie_amendment_timeline x
     WHERE x.provider_id = a.provider_id AND x.amendment_order > 0
       AND x.source_filename != a.source_filename) AS total_amendments,
    (SELECT MAX(x.effective_date_parsed) FROM {FQ}.tbl_genie_amendment_timeline x
     WHERE x.provider_id = a.provider_id AND x.amendment_order > 0) AS latest_amendment_date,
    (SELECT x.source_filename FROM {FQ}.tbl_genie_amendment_timeline x
     WHERE x.provider_id = a.provider_id AND x.amendment_order > 0
     ORDER BY x.amendment_order DESC LIMIT 1) AS latest_amendment_doc,
    current_timestamp(), 1, 'v2_initial_population'
FROM {FQ}.tbl_genie_amendment_timeline a
WHERE a.amendment_order = 0
   OR a.doc_category = 'Base Agreement'
   OR (a.document_type ILIKE '%base%' AND a.amendment_order <= 1)
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.provider_id, a.source_filename ORDER BY a.amendment_order) = 1
""")

c = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_v2_contract_registry").collect()[0]["n"]
log_step("Contract Registry", "SUCCESS", f"{c} contracts")

# ============================================================
# STEP 2: Populate Amendment Registry with Scope Classification
# Uses structural signals for deterministic classification
# Columns: exhibits_replaced_count is STRING (JSON array), not INT
#           prior_rates_superseded is STRING 'True'/'False'
# ============================================================
log_step("Amendment Registry", "RUNNING")

spark.sql(f"""
INSERT INTO {FQ}.tbl_v2_amendment_registry (
    amendment_id, contract_id,
    source_filename, document_type, amendment_order,
    scope_type, exhibits_modified, sections_modified, rate_categories_modified,
    effective_date, execution_date,
    summary_of_changes, amendments_impact_raw,
    scope_confidence, scope_source,
    created_at, classification_rule
)
SELECT
    sha2(concat_ws('|', a.provider_id, a.source_filename), 256) AS amendment_id,
    sha2(concat_ws('|', a.provider_id, 
        COALESCE((SELECT x.source_filename FROM {FQ}.tbl_genie_amendment_timeline x 
         WHERE x.provider_id = a.provider_id 
           AND (x.amendment_order = 0 OR x.doc_category = 'Base Agreement')
         ORDER BY x.amendment_order LIMIT 1), a.source_filename)), 256) AS contract_id,
    a.source_filename,
    a.document_type,
    a.amendment_order,
    -- Scope classification: structural signals (string types)
    CASE
        WHEN LENGTH(a.exhibits_replaced_count) > 30 AND a.prior_rates_superseded = 'True' THEN 'FULL_REPLACEMENT'
        WHEN LENGTH(a.exhibits_replaced_count) > 4 THEN 'EXHIBIT_SPECIFIC'
        WHEN a.prior_rates_superseded = 'True' THEN 'RATE_SPECIFIC'
        WHEN LENGTH(a.sections_modified_count) > 4 THEN 'SECTION_SPECIFIC'
        WHEN a.document_type ILIKE '%extension%' OR a.document_type ILIKE '%renewal%' THEN 'TERM_EXTENSION'
        WHEN a.document_type ILIKE '%addendum%' THEN 'ADDENDUM'
        WHEN a.rate_count > 10 THEN 'FULL_REPLACEMENT'
        WHEN a.rate_count > 0 THEN 'RATE_SPECIFIC'
        ELSE 'SECTION_SPECIFIC'
    END AS scope_type,
    CASE WHEN LENGTH(a.exhibits_replaced_count) > 4 THEN a.exhibits_replaced_count END,
    CASE WHEN LENGTH(a.sections_modified_count) > 4 THEN a.sections_modified_count END,
    NULL,
    a.effective_date_parsed, NULL,
    a.summary_of_changes, NULL,
    CASE
        WHEN LENGTH(a.exhibits_replaced_count) > 4 OR a.prior_rates_superseded = 'True' THEN 0.85
        WHEN LENGTH(a.sections_modified_count) > 4 THEN 0.75
        WHEN a.document_type ILIKE '%extension%' THEN 0.90
        ELSE 0.60
    END,
    'structural_signals',
    current_timestamp(), 'v2_structural_heuristic_v1'
FROM {FQ}.tbl_genie_amendment_timeline a
WHERE a.amendment_order > 0
  AND a.doc_category != 'Base Agreement'
""")

c = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_v2_amendment_registry").collect()[0]["n"]
log_step("Amendment Registry", "SUCCESS", f"{c} amendments classified")

# ============================================================
# SUMMARY
# ============================================================
print("\n" + "=" * 60)
print("STATE ENGINE COMPLETE")
scope_dist = spark.sql(f"""
    SELECT scope_type, COUNT(*) AS cnt
    FROM {FQ}.tbl_v2_amendment_registry
    GROUP BY scope_type ORDER BY cnt DESC
""").collect()
print("\nAmendment scope distribution:")
for r in scope_dist:
    print(f"  {r['scope_type']:<20} {r['cnt']:>5}")
print("=" * 60)
