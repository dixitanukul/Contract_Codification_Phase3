# FULL IMPLEMENTATION PROMPT
## Use this in a fresh Genie/Claude session to execute the entire V2 platform build

---

## INSTRUCTIONS FOR THE AI

Read `/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/CONTEXT_HANDOFF.md` first — it contains full architecture context, table schemas, design decisions, and folder structure.

Then execute the implementation plan below. Work step by step, creating each file/notebook and executing code cells before moving to the next step.

---

## CLEAN FOLDER STRUCTURE (V2 separated from V1)

The old V1 pipeline (notebooks 01-25) stays in the root folder UNTOUCHED. All new V2 implementation goes into the engine subfolders:

```
/Contract_Codification_Pipeline/
├── [01-25 notebooks — V1 LEGACY, DO NOT MODIFY]
├── CONTEXT_HANDOFF.md
├── IMPLEMENTATION_PROMPT.md (this file)
│
├── v2_implementation/                    ← NEW: All executable V2 code
│   ├── 00_v2_config.py                   ← Shared config, constants, utilities
│   ├── 01_execute_ddl.py                 ← Run all DDL (tables, views, seed)
│   ├── 02_state_engine.py                ← State engine pipeline
│   ├── 03_reimbursement_migration.py     ← V1→V2 data migration
│   ├── 04_legal_chunking_pipeline.py     ← Clause-aware chunking + embedding
│   ├── 05_retrieval_engine.py            ← Hybrid retrieval implementation
│   ├── 06_reranking_service.py           ← Cross-encoder + legal signals
│   ├── 07_citation_verification.py       ← Faithfulness verification
│   ├── 08_intelligence_pipeline.py       ← Spend-weighted analytics
│   ├── 09_scenario_engine.py             ← Negotiation simulation
│   ├── 10_leverage_scoring.py            ← Provider leverage computation
│   └── 11_evaluation_harness.py          ← Retrieval quality evaluation
│
├── State Engine/                          ← DESIGN DOCS (already exist)
│   └── [3 files — architecture + DDL]
├── Reimbursement Engine/                  ← DESIGN DOCS + DDL (already exist)
│   └── [10 files — design + SQL]
├── Retrieval Engine/                      ← DESIGN DOCS (already exist)
│   └── [5 files — architecture]
└── Intelligence Engine/                   ← DESIGN DOCS (already exist)
    └── [5 files — architecture]
```

---

## EXECUTION PLAN (16 Steps, in order)

### PHASE A: Foundation (Steps 1-4)

#### Step 1: Create shared config module
**File**: `v2_implementation/00_v2_config.py`
**What it does**:
- Defines all constants: catalog (`dev_adb`), schema (`raw`), table prefixes
- Utility functions: `run_sql()`, `table_exists()`, `log_step()`
- Claims feed connection config (placeholder if not yet available)
- Model endpoints: embedding model, reranker, LLM judge
- Feature flags: `CLAIMS_AVAILABLE = False`, `RERANKER_DEPLOYED = False`

```python
# Key constants needed:
CATALOG = "dev_adb"
SCHEMA = "raw"
EMBEDDING_MODEL = "databricks-gte-large-en"
RERANKER_MODEL = "bge-reranker-v2-m3"  # Deploy later
LLM_JUDGE = "databricks-claude-sonnet-4-5"
VS_ENDPOINT = "contract_intelligence_vs_endpoint"
VS_INDEX_LEGAL_UNITS = "idx_legal_units_v2"

# Feature flags (toggle as integrations come online)
CLAIMS_AVAILABLE = False
RERANKER_DEPLOYED = False
FULL_CORPUS_PROCESSED = False
```

#### Step 2: Execute all DDL (create empty tables)
**File**: `v2_implementation/01_execute_ddl.py`
**What it does**:
- Reads and executes each SQL file in order:
  1. `/State Engine/V2_SCHEMA_DDL.sql` — 5 state tables
  2. `/Reimbursement Engine/V2_REIMB_01_DDL_tables.sql` — 9 reimbursement tables
  3. `/Reimbursement Engine/V2_REIMB_04_taxonomy_seed.sql` — Seed data
- Verifies all tables created with SHOW TABLES
- Does NOT run migration or views yet (needs data first)
- Logs results: tables created, row counts

**SQL files to execute** (read from existing files, execute via spark.sql()):
```
/State Engine/V2_SCHEMA_DDL.sql
/Reimbursement Engine/V2_REIMB_01_DDL_tables.sql
/Reimbursement Engine/V2_REIMB_04_taxonomy_seed.sql
```

**Validation**: 
```sql
SELECT 'tbl_reimb_rate_rules' AS t, COUNT(*) FROM dev_adb.raw.tbl_reimb_rate_rules
UNION ALL SELECT 'dim_service_line_taxonomy', COUNT(*) FROM dev_adb.raw.dim_service_line_taxonomy
-- ... (all 14 tables should exist, taxonomy should have ~51 rows)
```

#### Step 3: Run V1→V2 data migration
**File**: `v2_implementation/03_reimbursement_migration.py`
**What it does**:
- Reads and executes `/Reimbursement Engine/V2_REIMB_02_migration.sql`
  - Migrates `tbl_contract_rates_all` → `tbl_reimb_rate_rules`
  - Migrates `tbl_contract_financial_protections` → `tbl_reimb_stop_loss` + `tbl_reimb_carve_outs`
  - Migrates `tbl_serving_capitation_card` → capitation rules + escalators
  - Migrates lesser-of provisions → `tbl_reimb_lesser_of`
  - Updates modifier flags via MERGE
- Creates backward-compatible views: `/Reimbursement Engine/V2_REIMB_03_views.sql`
- Runs validation queries: `/Reimbursement Engine/V2_REIMB_05_validation.sql`
- Logs: migration coverage %, orphan count, row counts

**Success criteria**:
- Migration coverage ≥ 95% of V1 current rates
- Zero NULL formula_json in rate_rules
- Backward-compat views return comparable row counts to V1 tables

#### Step 4: State Engine population
**File**: `v2_implementation/02_state_engine.py`
**What it does**:
- Populates `tbl_v2_contract_registry` from existing extraction data
  - One row per unique (provider_id, base_agreement_doc)
  - Derives agreement_type, payment_model from rate_category patterns
- Populates `tbl_v2_amendment_registry` from `tbl_genie_amendment_timeline`
  - Classifies scope_type using LLM (Claude Sonnet 4.5) on summary_of_changes
  - Extracts exhibits_modified, rate_categories_modified
- Computes supersession: updates `tbl_v2_rate_facts_bitemporal` with is_current flags
- Links amendments to contracts via contract_id

**Key logic**:
```python
# Scope classification prompt for amendments
SCOPE_PROMPT = """Classify this amendment's scope:
- FULL_REPLACEMENT: Replaces entire agreement or all rates
- EXHIBIT_SPECIFIC: Replaces specific exhibit(s)
- RATE_SPECIFIC: Changes specific rate categories only
- SECTION_SPECIFIC: Modifies specific sections
- TERM_EXTENSION: Extends dates only
- ADDENDUM: Adds new provisions without replacing

Amendment summary: {summary}
Modified categories: {categories}

Respond: {"scope_type": "...", "exhibits_modified": [...], "confidence": 0.0-1.0}"""
```

---

### PHASE B: Retrieval Infrastructure (Steps 5-8)

#### Step 5: Legal chunking pipeline
**File**: `v2_implementation/04_legal_chunking_pipeline.py`
**What it does**:
- Reads existing OCR text from parsed PDFs (or `tbl_contract_clauses_all` as bootstrap)
- Implements 5-stage chunking (see LEGAL_GROUNDING_ARCHITECTURE.md §3):
  1. Structure detection (regex-based section/exhibit boundary finding)
  2. Boundary identification (clause-level splitting with no-split zones)
  3. Unit classification (LLM-assisted: CLAUSE | RATE_TABLE | CONDITION | etc.)
  4. Context resolution (cross-reference linking, parent-child hierarchy)
  5. Embedding (databricks-gte-large-en via ai_query)
- Writes to `tbl_retrieval_legal_units` table
- Registers VS index on the table

**Bootstrap approach** (before full re-OCR):
- Use existing `tbl_contract_clauses_all` as initial legal units (~3,000 rows)
- Use `tbl_contract_rates_all` rate_text as RATE_TABLE units (~5,000 rows)
- Each gets: unit_type classification, provider_id, source_filename, is_current flag
- Total initial units: ~8,000 (upgradeable to ~200K when full corpus processes)

**VS Index creation**:
```python
# Create new VS index for legal units
from databricks.vector_search.client import VectorSearchClient
vsc = VectorSearchClient()

vsc.create_delta_sync_index(
    endpoint_name="contract_intelligence_vs_endpoint",
    index_name="dev_adb.raw.idx_legal_units_v2",
    source_table_name="dev_adb.raw.tbl_retrieval_legal_units",
    pipeline_type="TRIGGERED",
    primary_key="unit_id",
    embedding_source_column="unit_text",
    embedding_model_endpoint_name="databricks-gte-large-en",
    columns_to_sync=["unit_id", "unit_text", "unit_type", "source_filename",
                     "provider_id", "contract_id", "section_type", "is_current",
                     "effective_date", "rate_domain", "page_start"]
)
```

#### Step 6: Hybrid retrieval engine
**File**: `v2_implementation/05_retrieval_engine.py`
**What it does**:
- Implements 4-channel retrieval (see RETRIEVAL_ARCHITECTURE_V2.md §4):
  1. Semantic: VS search against `idx_legal_units_v2`
  2. Lexical: BM25-style SQL search with RLIKE/ILIKE on chunk table
  3. Metadata: Direct SQL against V2 rate_rules/stop_loss/escalator tables
  4. Structural: Section-aware expansion of anchor results
- Implements query understanding:
  - Intent classification (RATE_LOOKUP | CLAUSE_SEARCH | COMPARISON | TIMELINE)
  - Entity extraction (providers, service lines, programs)
  - Temporal scope (CURRENT_ONLY | HISTORICAL | AS_OF_DATE)
- Implements Reciprocal Rank Fusion with intent-weighted channels
- Returns top-30 candidates for reranking

**Key class**:
```python
class HybridRetriever:
    def retrieve(self, query: str, provider_id: str = None) -> List[ScoredChunk]:
        parsed = self.understand_query(query)
        semantic = self.retrieve_semantic(parsed)
        lexical = self.retrieve_lexical(parsed)
        metadata = self.retrieve_metadata(parsed)
        structural = self.retrieve_structural(parsed, semantic[:10])
        fused = self.fuse_results([semantic, lexical, metadata, structural], parsed)
        enriched = self.enrich_with_state(fused)
        return enriched[:30]
```

#### Step 7: Reranking service
**File**: `v2_implementation/06_reranking_service.py`
**What it does**:
- Stage 1: Cross-encoder scoring
  - If RERANKER_DEPLOYED=True: call Model Serving endpoint (bge-reranker-v2-m3)
  - If False: fall back to LLM-as-reranker (Claude Haiku for cost control)
- Stage 2: Legal signal scoring (6 signals — see RERANKING_PIPELINE_DESIGN.md §4):
  - State score (current=1.0, superseded=0.1)
  - Recency score (exponential decay, 2-year half-life)
  - Specificity score (RATE_TABLE=1.0 > CLAUSE=0.9 > DEFINITION=0.6)
  - Scope match (correct provider/program/network)
  - Authority score (base_agreement=1.0 > amendment=0.95 > memo=0.5)
  - Completeness score (entity coverage relative to query)
- Stage 3: Weighted fusion (intent-specific profiles) + diversity enforcement
- Returns top-5 final results

#### Step 8: Citation verification
**File**: `v2_implementation/07_citation_verification.py`
**What it does**:
- Implements inline citation protocol:
  - Generation prompt forces [1], [2] markers on every claim
  - Each marker maps to a source unit_id
- Implements 6-check verification (see CITATION_VERIFICATION_FRAMEWORK.md §3):
  1. Uncited claim detection
  2. Numerical accuracy (extract numbers, compare to source)
  3. Entity scope correctness (right provider?)
  4. State correctness (not citing superseded as current?)
  5. NLI entailment (LLM judge: does evidence support claim?)
  6. Conditional completeness (conditions/exceptions preserved?)
- Computes calibrated confidence score (5 components → weighted 0-1)
- Implements answer remediation (fix numerical errors, add disclaimers)
- Logs to `tbl_retrieval_telemetry`

---

### PHASE C: Intelligence Layer (Steps 9-12)

#### Step 9: Spend-weighted analytics pipeline
**File**: `v2_implementation/08_intelligence_pipeline.py`
**What it does**:
- Creates `tbl_claims_summary_feed` and `tbl_utilization_feed` (empty, ready for integration)
- If CLAIMS_AVAILABLE=False:
  - Estimates volume from V1 data heuristics (stop-loss thresholds, provider size)
  - Marks all metrics with `source='estimated'`
- Computes benchmarks: `tbl_intel_benchmark_results`
  - Percentile rates per service line (p10, p25, median, p75, p90)
  - Uses V2 rate_rules with taxonomy JOIN for service-line normalization
- Computes provider spend summary: `tbl_intel_provider_spend_summary`
  - Total spend (actual or estimated), spend rank, savings opportunity
  - Rate vs benchmark %, market percentile
- Computes service-line detail: `tbl_intel_service_line_spend`
  - Per-line: current rate, volume, spend, benchmark comparison, savings
- Computes savings opportunities: `tbl_intel_savings_opportunity`
  - Pareto-ranked by annual $ impact

#### Step 10: Scenario modeling engine
**File**: `v2_implementation/09_scenario_engine.py`
**What it does**:
- Implements scenario runner (see SCENARIO_MODELING_ENGINE.md §3):
  - `run_scenario(scenario)` → baseline + modified + projection + impact + sensitivity
- Implements scenario types:
  - RATE_CHANGE: apply % change to selected service lines, project 5 years
  - TERMINATION: model volume redistribution + OON cost + attrition
  - ESCALATION_CHANGE: model cap/floor/conversion on escalator terms
  - BUDGET_BACKWARD: reverse-solve for rate that hits target spend
- Implements multi-scenario comparison (side-by-side DataFrame output)
- Implements sensitivity analysis (tornado chart data)
- Writes results to `tbl_intel_scenario_results`
- Exposes function callable from Genie Space natural language queries

#### Step 11: Leverage scoring
**File**: `v2_implementation/10_leverage_scoring.py`
**What it does**:
- Computes plan leverage per provider (5 components):
  - Revenue share estimate, volume redirectability, market share, alternatives, quality data
- Computes provider leverage per provider (7 components):
  - Sole community, member lock, AMC status, system size, payer diversity, brand, regulatory
- Computes net leverage score (-1 to +1) and strategic implication
- Computes dependency metrics (plan_dependency, provider_dependency, ratio)
- Market position analysis (rate percentile vs peers and Medicare reference)
- Writes to `tbl_intel_leverage_scores`
- Generates leverage-adjusted negotiation targets per provider

#### Step 12: Renewal priority computation
**File**: (embedded in `08_intelligence_pipeline.py` or separate)
**What it does**:
- Computes `tbl_intel_renewal_priority` from:
  - Contract terms (expiry, auto-renewal, notice period) from `tbl_v2_contract_registry`
  - Spend context from `tbl_intel_provider_spend_summary`
  - Network risk from leverage scoring
  - Escalation exposure from `tbl_reimb_escalators`
- Priority scoring: urgency (0-40) + impact (0-40) + risk (0-20) = 0-100
- Recommended action: ALLOW_AUTO_RENEW | NEGOTIATE | ISSUE_NON_RENEWAL | ESCALATE
- Creates `v_intel_renewal_calendar` view for dashboard consumption

---

### PHASE D: Evaluation & Integration (Steps 13-16)

#### Step 13: Evaluation harness
**File**: `v2_implementation/11_evaluation_harness.py`
**What it does**:
- Creates `tbl_retrieval_telemetry` table (from RETRIEVAL_EVALUATION_FRAMEWORK.md)
- Creates starter golden query set (20 queries, manually labeled):
  - 5 rate lookups, 3 clause searches, 3 comparisons, 3 timeline, 3 amendment, 3 complex
- Implements `run_regression_suite()`: runs all golden queries, computes metrics
- Computes: precision@5, NDCG@5, MRR, state_precision, scope_purity
- Creates `v_retrieval_health_daily` monitoring view
- Logs baseline metrics for future regression detection

#### Step 14: Genie Space V2 integration
**What it does**:
- Updates existing Genie Space (ID: `01f14d360bd51f8d801452065b2df600`) with:
  - New V2 tables added as data sources (rate_rules, taxonomy, leverage, scenarios)
  - New SQL examples demonstrating V2 capabilities:
    - "What's the spend-weighted savings opportunity for Providence?"
    - "Compare leverage scores for top 5 providers"
    - "Run a 5% rate reduction scenario for Kaiser inpatient"
    - "Show renewal priorities for next 90 days"
  - New instructions referencing V2 schema and formula_json interpretation

#### Step 15: Dashboard V2 widgets
**What it does**:
- Add new widgets to existing Dashboard (ID: `01f153b41dc51de8bb4e0a3cf16bb7e1`):
  - Renewal calendar (priority-colored timeline)
  - Savings opportunity waterfall (top 10 providers × top 3 lines)
  - Leverage distribution (scatter: plan leverage vs provider leverage)
  - Escalation projection (5-year stacked bar)
  - Taxonomy coverage metric (% classified vs unclassified)

#### Step 16: Orchestration job
**What it does**:
- Creates Databricks Job with task DAG:
  ```
  00_v2_config → 01_execute_ddl → [02_state_engine, 03_reimbursement_migration]
                                          ↓
                              04_legal_chunking_pipeline
                                          ↓
                              [05_retrieval_engine (library, no run)]
                                          ↓
                              08_intelligence_pipeline → [09_scenario_engine, 10_leverage_scoring]
                                          ↓
                              11_evaluation_harness
  ```
- Schedule: Monthly refresh (aligned with claims close cycle)
- Alerting: Email on failure, Slack on success with key metrics

---

## EXECUTION RULES

1. **Create `v2_implementation/` folder first** — all new code goes there
2. **Never modify notebooks 01-25** — they are V1 legacy (still in production)
3. **Each file is a standalone notebook** — can run independently after 00_config
4. **Use parameterized SQL everywhere** — no f-strings in queries (addresses W4)
5. **Every new table gets COMMENT on every column** — matches Genie convention
6. **Log everything** — each step prints: start time, row counts, success/failure
7. **Graceful degradation** — check feature flags before using claims/reranker/full corpus
8. **Test before moving to next step** — each step has validation criteria
9. **Files stay under 300 lines** — split if approaching limit (editor crash prevention)
10. **Commit message style**: "V2 Step N: [description]" in notebook titles

---

## DEPENDENCIES BETWEEN STEPS

```
Step 1 (config) ← Everything depends on this
Step 2 (DDL) ← Steps 3, 4, 5, 9, 10, 11, 12
Step 3 (migration) ← Steps 5, 8, 9, 10
Step 4 (state engine) ← Steps 5, 6, 7, 12
Step 5 (chunking) ← Steps 6, 7
Step 6 (retrieval) ← Steps 7, 8, 13
Step 7 (reranking) ← Step 8
Step 8 (verification) ← Step 13
Step 9 (intelligence) ← Steps 10, 11, 12, 14, 15
Step 10 (scenarios) ← Step 14
Step 11 (leverage) ← Steps 12, 14
Step 13 (evaluation) ← Step 14
Step 14 (Genie) ← Step 15
Step 16 (orchestration) ← All above
```

**Minimum viable path** (gets value fastest):
Steps 1 → 2 → 3 → 9 → 11 → 12 → 14
(DDL + migration + intelligence + Genie update = negotiation value without full retrieval rebuild)

---

## VALIDATION CHECKLIST (run after all steps)

```sql
-- 1. All V2 tables exist and have data
SELECT 'tbl_reimb_rate_rules' AS t, COUNT(*) AS n FROM dev_adb.raw.tbl_reimb_rate_rules
UNION ALL SELECT 'tbl_reimb_stop_loss', COUNT(*) FROM dev_adb.raw.tbl_reimb_stop_loss
UNION ALL SELECT 'tbl_reimb_escalators', COUNT(*) FROM dev_adb.raw.tbl_reimb_escalators
UNION ALL SELECT 'dim_service_line_taxonomy', COUNT(*) FROM dev_adb.raw.dim_service_line_taxonomy
UNION ALL SELECT 'tbl_v2_contract_registry', COUNT(*) FROM dev_adb.raw.tbl_v2_contract_registry
UNION ALL SELECT 'tbl_intel_provider_spend_summary', COUNT(*) FROM dev_adb.raw.tbl_intel_provider_spend_summary
UNION ALL SELECT 'tbl_intel_leverage_scores', COUNT(*) FROM dev_adb.raw.tbl_intel_leverage_scores
UNION ALL SELECT 'tbl_intel_renewal_priority', COUNT(*) FROM dev_adb.raw.tbl_intel_renewal_priority;

-- 2. Backward-compat views match V1 row counts (±10%)
SELECT 'genie_rates' AS view_name,
       (SELECT COUNT(*) FROM dev_adb.raw.v_genie_rates_current_v2) AS v2_rows,
       (SELECT COUNT(*) FROM dev_adb.raw.tbl_genie_rates_current) AS v1_rows;

-- 3. Taxonomy coverage > 60%
SELECT ROUND(SUM(CASE WHEN t.service_line_id IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS pct
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t
    ON EXISTS (SELECT 1 FROM dev_adb.raw.dim_service_line_patterns p
               WHERE p.service_line_id = t.service_line_id
                 AND r.service_category ILIKE p.pattern_value);

-- 4. All providers have leverage scores
SELECT COUNT(DISTINCT provider_id) AS scored_providers
FROM dev_adb.raw.tbl_intel_leverage_scores;

-- 5. No SQL injection vectors (search for f-strings in new notebooks)
-- Run: grep -r "f\"" v2_implementation/*.py | grep -i "select\|insert\|update\|delete"
-- Expected: 0 results
```

---

## ESTIMATED EFFORT

| Phase | Steps | Estimated Time | Compute Cost |
| --- | --- | --- | --- |
| A: Foundation | 1-4 | 2-3 hours | Low (DDL + SQL transforms) |
| B: Retrieval | 5-8 | 4-6 hours | Medium (embedding + LLM calls) |
| C: Intelligence | 9-12 | 3-4 hours | Low (SQL analytics) |
| D: Integration | 13-16 | 2-3 hours | Low (config + dashboarding) |
| **Total** | **16 steps** | **11-16 hours** | **~$50-100 LLM cost** |

**Minimum viable (Steps 1-3, 9, 11-12, 14)**: 4-6 hours, delivers negotiation intelligence.

---

## START HERE

Begin by:
1. Reading `/Contract_Codification_Pipeline/CONTEXT_HANDOFF.md`
2. Creating folder: `/Contract_Codification_Pipeline/v2_implementation/`
3. Creating `00_v2_config.py` with all constants
4. Then proceed step by step through the execution plan

Do not skip steps. Do not modify V1 notebooks. Keep each file under 300 lines.
