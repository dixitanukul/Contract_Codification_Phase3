# RERANKING PIPELINE DESIGN
## Multi-Stage Scoring for Legal Relevance, Recency, and State Awareness

**Document Class:** Pipeline Architecture  
**Date:** 2026-05-22  
**Scope:** Transform over-retrieved candidates into precisely ranked results  
**Position in Pipeline:** After Retrieval Fusion, before Grounding & Verification  

---

## 1. WHY RERANKING IS CRITICAL FOR LEGAL RETRIEVAL

### 1.1 The Precision Gap

ANN/BM25 retrieval optimizes for **recall** — "find everything potentially relevant."  
Legal contract queries demand **precision** — "find the *authoritative* answer."

| Retrieval Stage | Optimizes For | Output |
| --- | --- | --- |
| Initial retrieval (4 channels) | Recall: don't miss relevant docs | ~50 candidates per channel, ~120 unique |
| Fusion (RRF) | Balance: combine signal types | Top 30 fused candidates |
| **Reranking** | **Precision: legal authority** | **Top 5 authoritative results** |

### 1.2 Failure Modes Without Reranking

| Failure | Example | Consequence |
| --- | --- | --- |
| Semantic similarity ≠ legal authority | Amendment summary is similar to base agreement text — but amendment supersedes it | Wrong version cited |
| Topical match ≠ scope match | Provider B's per diem is topically similar to Provider A's query | Scope leakage |
| Recency blindness | 2019 base agreement ranks above 2024 amendment (more text mass) | Stale answer |
| Specificity inversion | General "compensation" clause ranks above specific "Exhibit B, Table 2" | Imprecise answer |

---

## 2. RERANKING ARCHITECTURE

### 2.1 Three-Stage Pipeline

```
Fused Candidates (30 results)
        │
        ▼
┌─────────────────────────────────┐
│ STAGE 1: Cross-Encoder Scoring  │  Semantic relevance at query-document level
│ (model-based, expensive)        │  Score: 0.0 - 1.0
└────────────┬────────────────────┘
             │ (30 → 30, rescored)
             ▼
┌─────────────────────────────────┐
│ STAGE 2: Legal Signal Scoring   │  Domain-specific signals:
│ (rule-based, fast)              │  state, recency, specificity, scope
│                                 │  Score: multi-dimensional
└────────────┬────────────────────┘
             │ (30 → 30, multi-score)
             ▼
┌─────────────────────────────────┐
│ STAGE 3: Final Fusion & Cut     │  Weighted combination → top-K selection
│ (learned weights)               │  Diversity enforcement
└────────────┬────────────────────┘
             │ (30 → 5-10 final results)
             ▼
        Final Ranked Results
```

---

## 3. STAGE 1: CROSS-ENCODER RERANKING

### 3.1 Model Selection

| Option | Latency | Quality | Deployment |
| --- | --- | --- | --- |
| `bge-reranker-v2-m3` (BAAI) | ~15ms/pair | SOTA open-source | Serve via Model Serving |
| `databricks-gte-large-en` (as bi-encoder rerank) | ~5ms/pair | Good but not cross-encoder | Already deployed |
| LLM-as-reranker (Claude Haiku) | ~200ms/pair | Highest quality, expensive | Pay-per-use |

**Recommendation:** Deploy `bge-reranker-v2-m3` on Model Serving for production. Use LLM-as-reranker for evaluation/calibration only.

### 3.2 Cross-Encoder Scoring

```python
def cross_encoder_rerank(query: str, candidates: List[ScoredChunk]) -> List[ScoredChunk]:
    """
    Score each (query, document) pair with cross-encoder.
    Unlike bi-encoder (independent embeddings), cross-encoder sees
    query and document together — captures fine-grained relevance.
    """
    # Batch inference for efficiency
    pairs = [(query, chunk.text[:512]) for chunk in candidates]  # Truncate to model max
    
    scores = reranker_endpoint.predict(
        instances=[{"query": q, "passage": p} for q, p in pairs]
    )
    
    for chunk, score in zip(candidates, scores):
        chunk.cross_encoder_score = sigmoid(score)  # Normalize to 0-1
    
    return candidates
```

### 3.3 LLM-as-Reranker (High-Quality Fallback)

```python
LLM_RERANK_PROMPT = """Rate the relevance of this contract passage to the user's question.

Question: {query}

Passage (from {provider_name}, effective {effective_date}):
"{passage_text}"

Rate on a scale of 0-10:
- 10: Directly answers the question with specific, authoritative contract language
- 7-9: Highly relevant, contains key information but may need interpretation
- 4-6: Partially relevant, provides useful context but doesn't directly answer
- 1-3: Tangentially related, same topic but different scope/provider/timeframe
- 0: Not relevant to the question at all

Consider:
- Does this passage apply to the specific provider/program asked about?
- Is this the CURRENT version (not superseded by a later amendment)?
- Does it contain the specific details requested (rates, dates, conditions)?

Score (integer 0-10):"""

def llm_rerank(query: str, candidates: List[ScoredChunk]) -> List[ScoredChunk]:
    """Use LLM for highest-quality relevance scoring. Expensive — use selectively."""
    for chunk in candidates[:15]:  # Only top-15 to control cost
        response = call_llm(
            model="databricks-claude-sonnet-4-5",
            prompt=LLM_RERANK_PROMPT.format(
                query=query,
                provider_name=chunk.metadata.get('provider_name', 'Unknown'),
                effective_date=chunk.metadata.get('effective_date', 'Unknown'),
                passage_text=chunk.text[:1000]
            ),
            max_tokens=10,
            temperature=0.0
        )
        chunk.llm_relevance_score = int(response.strip()) / 10.0
    
    return candidates
```

---

## 4. STAGE 2: LEGAL SIGNAL SCORING

### 4.1 Signal Definitions

Six domain-specific signals computed per candidate:

```python
@dataclass
class LegalSignals:
    """Domain-specific scoring signals for contract retrieval."""
    # State signal: is this the authoritative current version?
    state_score: float          # 1.0=current, 0.5=possibly_superseded, 0.1=superseded
    
    # Recency signal: more recent documents preferred (for current-intent queries)
    recency_score: float        # Decay function based on effective_date
    
    # Specificity signal: specific clauses preferred over general sections
    specificity_score: float    # Based on unit_type and section depth
    
    # Scope match: does this apply to the queried entity?
    scope_score: float          # 1.0=exact match, 0.5=partial, 0.0=mismatch
    
    # Authority signal: base agreement > amendment excerpt > summary
    authority_score: float      # Based on document_type and section_type
    
    # Completeness signal: does this unit contain all needed info?
    completeness_score: float   # Based on unit length and entity coverage
```

### 4.2 State Scoring

```python
def compute_state_score(chunk: ScoredChunk, query: ParsedQuery) -> float:
    """
    Score based on document state relative to query intent.
    
    Rules:
    - CURRENT_ONLY queries: superseded docs get 0.1 (not 0 — still useful for context)
    - HISTORICAL queries: all docs get 1.0 (state doesn't penalize)
    - TREND queries: boost documents that show progression
    """
    if query.temporal_intent == 'HISTORICAL':
        return 1.0
    
    state = chunk.state
    if state.is_current:
        return 1.0
    elif state.state_label == 'POSSIBLY_SUPERSEDED':
        return 0.5 + (0.3 * state.supersession_confidence)  # Higher conf = lower score
    else:  # SUPERSEDED
        if query.temporal_intent == 'CURRENT_ONLY':
            return 0.1  # Heavily penalize but don't eliminate
        return 0.3
```

### 4.3 Recency Scoring

```python
def compute_recency_score(chunk: ScoredChunk, query: ParsedQuery) -> float:
    """
    Time-decay scoring: more recent documents preferred for current-intent queries.
    Uses exponential decay with configurable half-life.
    """
    if query.temporal_intent in ('HISTORICAL', 'FULL_LINEAGE'):
        return 1.0  # No recency bias for historical queries
    
    if not chunk.effective_date:
        return 0.5  # Unknown date = neutral
    
    days_old = (date.today() - chunk.effective_date).days
    half_life_days = 730  # 2 years — adjustable
    
    # Exponential decay: score = 0.5^(days_old / half_life)
    score = 0.5 ** (days_old / half_life_days)
    
    # Floor at 0.2 — old documents still have some value
    return max(score, 0.2)
```

### 4.4 Specificity Scoring

```python
def compute_specificity_score(chunk: ScoredChunk, query: ParsedQuery) -> float:
    """
    Prefer specific clauses over general sections.
    
    Hierarchy (most specific → least):
    RATE_TABLE > CLAUSE > CONDITION > EXHIBIT_SECTION > DEFINITION > CROSS_REFERENCE
    """
    SPECIFICITY_WEIGHTS = {
        'RATE_TABLE': 1.0,        # Exact rate data
        'CLAUSE': 0.9,            # Specific obligation
        'CONDITION': 0.85,        # Specific conditional
        'AMENDMENT_DELTA': 0.8,   # Specific change
        'EXHIBIT_SECTION': 0.7,   # Section-level
        'DEFINITION': 0.6,        # Term definition (supportive)
        'CROSS_REFERENCE': 0.4,   # Just a pointer
    }
    
    base_score = SPECIFICITY_WEIGHTS.get(chunk.unit_type, 0.5)
    
    # Boost if unit contains entities matching query
    entity_overlap = compute_entity_overlap(chunk.key_entities, query.entities)
    
    return min(base_score + (0.2 * entity_overlap), 1.0)
```

### 4.5 Scope Match Scoring

```python
def compute_scope_score(chunk: ScoredChunk, query: ParsedQuery) -> float:
    """
    Verify the chunk applies to the queried entity (provider, program, network).
    
    Critical: prevents Provider B's rates from answering a query about Provider A.
    """
    score = 1.0
    
    # Provider match
    if query.providers:
        if chunk.provider_id in query.provider_ids:
            score *= 1.0  # Exact match
        elif chunk.provider_name_matches_any(query.providers, threshold=0.8):
            score *= 0.9  # Fuzzy name match
        else:
            score *= 0.1  # Wrong provider — severe penalty
    
    # Program match
    if query.programs:
        chunk_programs = chunk.metadata.get('programs', ['All'])
        if 'All' in chunk_programs or any(p in chunk_programs for p in query.programs):
            score *= 1.0
        else:
            score *= 0.4  # Wrong program
    
    # Network match
    if query.networks:
        chunk_networks = chunk.metadata.get('networks', ['All Networks'])
        if 'All Networks' in chunk_networks or any(n in chunk_networks for n in query.networks):
            score *= 1.0
        else:
            score *= 0.5  # Wrong network
    
    return score
```

### 4.6 Authority Scoring

```python
def compute_authority_score(chunk: ScoredChunk) -> float:
    """
    Score based on document authority level.
    Executed contracts > amendments > summaries > memos.
    """
    AUTHORITY_WEIGHTS = {
        'base_agreement': 1.0,     # Highest authority
        'amendment': 0.95,         # Very high (supersedes base)
        'exhibit': 0.9,            # Part of executed agreement
        'addendum': 0.85,          # Supplementary
        'cover_memo': 0.5,         # Informational, not binding
        'settlement': 0.7,         # Binding but limited scope
        'llm_summary': 0.3,        # Derived, not source
    }
    
    doc_type = chunk.metadata.get('document_type', 'base_agreement')
    return AUTHORITY_WEIGHTS.get(doc_type, 0.5)
```

---

## 5. STAGE 3: FINAL FUSION & SELECTION

### 5.1 Weighted Score Combination

```python
def compute_final_score(chunk: ScoredChunk, query: ParsedQuery) -> float:
    """
    Combine cross-encoder score with legal signals using learned weights.
    
    Weights are tuned per query intent via evaluation framework.
    """
    # Intent-specific weight profiles
    WEIGHT_PROFILES = {
        'RATE_LOOKUP': {
            'cross_encoder': 0.25,
            'state': 0.20,
            'recency': 0.15,
            'specificity': 0.15,
            'scope': 0.20,
            'authority': 0.05,
        },
        'CLAUSE_SEARCH': {
            'cross_encoder': 0.35,
            'state': 0.15,
            'recency': 0.10,
            'specificity': 0.15,
            'scope': 0.15,
            'authority': 0.10,
        },
        'COMPARISON': {
            'cross_encoder': 0.20,
            'state': 0.20,
            'recency': 0.10,
            'specificity': 0.10,
            'scope': 0.30,    # Scope is critical for comparisons
            'authority': 0.10,
        },
        'TIMELINE': {
            'cross_encoder': 0.20,
            'state': 0.10,     # All states relevant for timeline
            'recency': 0.30,   # Temporal ordering matters most
            'specificity': 0.15,
            'scope': 0.20,
            'authority': 0.05,
        },
    }
    
    weights = WEIGHT_PROFILES.get(query.intent, WEIGHT_PROFILES['CLAUSE_SEARCH'])
    
    scores = {
        'cross_encoder': chunk.cross_encoder_score,
        'state': chunk.legal_signals.state_score,
        'recency': chunk.legal_signals.recency_score,
        'specificity': chunk.legal_signals.specificity_score,
        'scope': chunk.legal_signals.scope_score,
        'authority': chunk.legal_signals.authority_score,
    }
    
    return sum(weights[k] * scores[k] for k in weights)
```

### 5.2 Diversity Enforcement

```python
def enforce_diversity(ranked: List[ScoredChunk], top_k: int = 5) -> List[ScoredChunk]:
    """
    Ensure result set covers different aspects of the answer.
    Prevent 5 results all from the same exhibit section.
    
    Diversity dimensions:
    - source_filename (different documents)
    - section_type (different sections)
    - unit_type (mix of rate tables, clauses, conditions)
    """
    selected = []
    seen_sources = set()
    seen_sections = set()
    
    for chunk in ranked:
        # Check diversity constraints
        source_key = chunk.source_filename
        section_key = f"{chunk.source_filename}:{chunk.section_path}"
        
        # Allow at most 2 from same source, 1 from same section
        source_count = sum(1 for s in selected if s.source_filename == source_key)
        section_dup = section_key in seen_sections
        
        if source_count >= 2:
            continue  # Skip — enough from this source
        if section_dup and len(selected) < top_k - 1:
            continue  # Skip duplicate sections (unless we're running out)
        
        selected.append(chunk)
        seen_sources.add(source_key)
        seen_sections.add(section_key)
        
        if len(selected) >= top_k:
            break
    
    return selected
```

---

## 6. PERFORMANCE SPECIFICATIONS

### 6.1 Latency Budget

| Stage | Target p50 | Target p95 | Technique |
| --- | --- | --- | --- |
| Cross-encoder (30 pairs) | 50ms | 150ms | Batched GPU inference on Model Serving |
| Legal signals (30 candidates) | 10ms | 30ms | Rule-based computation, cached state lookups |
| Final fusion + diversity | 2ms | 5ms | In-memory sort + filter |
| **Total reranking** | **62ms** | **185ms** | |

### 6.2 Quality Targets

| Metric | Without Reranking | With Reranking | Measurement |
| --- | --- | --- | --- |
| NDCG@5 | ~0.55 (estimated) | >0.80 | Human relevance judgments |
| State correctness in top-5 | ~70% | >95% | Supersession accuracy |
| Scope purity (correct provider) | ~85% | >99% | Entity match validation |
| Authority in top-1 | ~60% | >90% | Is top result from authoritative source? |

### 6.3 Cost Model

```
Per query:
- Cross-encoder inference: ~$0.0001 (30 pairs × $0.000003/pair on GPU serving)
- Legal signals: $0 (rule-based, no external calls)
- LLM reranker (if used): ~$0.003 (15 calls × $0.0002/call Haiku)

Monthly at 10K queries/month:
- Cross-encoder only: ~$1/month
- With LLM reranker fallback (10% of queries): ~$4/month
```

---

## 7. IMPLEMENTATION

### 7.1 Model Serving Endpoint

```python
# Deploy cross-encoder reranker on Databricks Model Serving
import mlflow

model_name = "contract_reranker_v1"
mlflow.transformers.log_model(
    transformers_model={"model": reranker_model, "tokenizer": tokenizer},
    artifact_path="reranker",
    registered_model_name=f"dev_adb.models.{model_name}",
    task="text-classification",  # Reranking is a classification task
    input_example={"query": "per diem rate", "passage": "Hospital shall be reimbursed..."}
)
```

### 7.2 Caching Strategy

```python
# Cache legal signals that don't change per-query
STATE_CACHE = TTLCache(maxsize=100000, ttl=3600)  # 1-hour TTL

def get_cached_state(unit_id: str) -> ChunkState:
    if unit_id in STATE_CACHE:
        return STATE_CACHE[unit_id]
    state = compute_state_from_db(unit_id)
    STATE_CACHE[unit_id] = state
    return state
```

---

*The reranking pipeline bridges the gap between "topically similar results" and "legally authoritative, scope-correct, temporally valid evidence." Without it, retrieval returns relevant noise; with it, retrieval returns actionable contract intelligence.*
