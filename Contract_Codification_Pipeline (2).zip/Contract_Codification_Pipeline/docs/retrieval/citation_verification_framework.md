# CITATION VERIFICATION FRAMEWORK
## Faithfulness Verification, Provenance Chains, and Hallucination Detection

**Document Class:** Verification Architecture  
**Date:** 2026-05-22  
**Scope:** Ensure every generated answer is faithfully grounded in source contract text  
**Critical Requirement:** Healthcare contracts are legally binding — hallucinated terms are liability  

---

## 1. THE FAITHFULNESS PROBLEM

### 1.1 Why Verification Is Non-Negotiable

In general-purpose RAG, a hallucinated fact is an inconvenience.  
In contract intelligence, a hallucinated rate is a **legal liability**:

- "Provider X's per diem is $1,500" → If wrong, payment disputes, audit findings
- "The stop-loss threshold is $75,000" → If wrong, incorrect financial projections
- "This contract expires 12/31/2025" → If wrong, missed renewal windows
- "Amendment 3 replaced all Exhibit B rates" → If wrong, incorrect supersession logic

### 1.2 Faithfulness Failure Taxonomy

| Failure Type | Description | Detection Difficulty |
| --- | --- | --- |
| FABRICATION | Claim has no basis in any retrieved evidence | Medium (no supporting unit found) |
| NUMERICAL_DISTORTION | Dollar amount, percentage, or date is wrong | Easy (exact match check) |
| SCOPE_LEAKAGE | Applies Provider A's terms to Provider B | Medium (entity mismatch) |
| CONDITIONAL_DROP | States obligation without its conditions/exceptions | Hard (requires clause understanding) |
| TEMPORAL_CONFUSION | Mixes current and superseded terms | Medium (state check) |
| AGGREGATION_ERROR | "All providers" when only subset has this term | Medium (quantifier verification) |
| INFERENCE_OVERREACH | Draws conclusions not supported by source text | Hard (entailment check) |

---

## 2. VERIFICATION ARCHITECTURE

### 2.1 Two-Phase Verification

```
Phase 1: INLINE VERIFICATION (during generation)
──────────────────────────────────────────────────
LLM generates answer WITH citation markers → each marker maps to a source unit
→ Verification checks happen BEFORE answer is returned to user

Phase 2: POST-HOC VERIFICATION (quality assurance)
──────────────────────────────────────────────────
Separate verifier LLM evaluates (claim, evidence) pairs
→ Flags violations → Triggers human review if critical
→ Feeds back into confidence calibration
```

### 2.2 Inline Citation Protocol

The generation prompt enforces structured citation:

```python
CITATION_GENERATION_PROMPT = """You are a contract intelligence assistant. 
Answer the user's question using ONLY the provided contract evidence.

CITATION RULES (MANDATORY):
1. Every factual claim MUST have a citation marker: [1], [2], etc.
2. Each citation maps to one evidence unit (provided below).
3. If you cannot find evidence for a claim, DO NOT make the claim.
4. If evidence is ambiguous, state the ambiguity explicitly.
5. If a provision has been superseded, note this with the citation.
6. Never combine information from different providers without clear attribution.

NUMERICAL ACCURACY:
- Quote dollar amounts EXACTLY as they appear in the source.
- Quote percentages EXACTLY as they appear in the source.
- Quote dates EXACTLY as they appear in the source.
- If you need to compute (e.g., annual from monthly), show the math.

STATE AWARENESS:
- If evidence is marked SUPERSEDED, prefix with "Previously, ..." 
- If evidence is marked POSSIBLY_SUPERSEDED, add "⚠️ Verify: may have been amended"
- Always state the effective date of the provision being cited.

Evidence Units:
{formatted_evidence_units}

User Question: {query}

Respond with your answer including [N] citation markers, then a CITATIONS block:
---
CITATIONS:
[1] unit_id: {id}, page: {page}, summary: "{one_line}"
[2] ...
"""
```

### 2.3 Citation Extraction & Mapping

```python
@dataclass
class ExtractedCitation:
    """A citation extracted from the generated answer."""
    marker: str                    # "[1]", "[2]", etc.
    claim_text: str               # The sentence containing this marker
    claim_start_char: int         # Position in answer text
    claim_end_char: int
    referenced_unit_id: str       # Which evidence unit was cited
    
    # Verification results (populated by verifier)
    is_faithful: Optional[bool]
    violation_type: Optional[str]
    violation_detail: Optional[str]
    support_strength: Optional[float]  # 0-1

def extract_citations(answer: str, citation_block: str) -> List[ExtractedCitation]:
    """Parse answer text and citation block into structured citations."""
    # Extract [N] markers from answer body
    markers = re.findall(r'\[(\d+)\]', answer)
    
    # Parse citation block to get unit_id mappings
    citation_map = parse_citation_block(citation_block)
    
    # For each marker, extract the containing sentence
    citations = []
    for marker_num in markers:
        sentence = get_containing_sentence(answer, f'[{marker_num}]')
        unit_id = citation_map.get(marker_num)
        
        citations.append(ExtractedCitation(
            marker=f'[{marker_num}]',
            claim_text=sentence,
            claim_start_char=answer.index(sentence),
            claim_end_char=answer.index(sentence) + len(sentence),
            referenced_unit_id=unit_id
        ))
    
    return citations
```

---

## 3. FAITHFULNESS VERIFICATION ENGINE

### 3.1 Multi-Check Verification Pipeline

```python
def verify_answer(answer: str, citations: List[ExtractedCitation],
                  evidence: Dict[str, LegalSemanticUnit]) -> VerificationResult:
    """
    Run all verification checks on a generated answer.
    Returns pass/fail with detailed violation report.
    """
    violations = []
    
    # Check 1: Every claim has a citation
    uncited = find_uncited_claims(answer, citations)
    for claim in uncited:
        violations.append(Violation('UNCITED_CLAIM', claim, severity='MEDIUM'))
    
    # Check 2: Numerical accuracy
    for citation in citations:
        unit = evidence[citation.referenced_unit_id]
        num_errors = verify_numbers(citation.claim_text, unit.text)
        for err in num_errors:
            violations.append(Violation('NUMERICAL_DISTORTION', err, severity='HIGH'))
    
    # Check 3: Entity scope correctness
    for citation in citations:
        unit = evidence[citation.referenced_unit_id]
        scope_err = verify_entity_scope(citation.claim_text, unit)
        if scope_err:
            violations.append(Violation('SCOPE_LEAKAGE', scope_err, severity='HIGH'))
    
    # Check 4: State correctness
    for citation in citations:
        unit = evidence[citation.referenced_unit_id]
        state_err = verify_state_representation(citation.claim_text, unit)
        if state_err:
            violations.append(Violation('TEMPORAL_CONFUSION', state_err, severity='HIGH'))
    
    # Check 5: NLI-based faithfulness (LLM judge)
    for citation in citations:
        unit = evidence[citation.referenced_unit_id]
        nli_result = verify_entailment(citation.claim_text, unit.text)
        citation.is_faithful = nli_result.entailed
        citation.support_strength = nli_result.confidence
        if not nli_result.entailed:
            violations.append(Violation(
                'INFERENCE_OVERREACH', 
                f"Claim: {citation.claim_text}\nEvidence: {unit.text[:200]}",
                severity='MEDIUM'
            ))
    
    # Check 6: Conditional completeness
    for citation in citations:
        unit = evidence[citation.referenced_unit_id]
        cond_err = verify_conditions_preserved(citation.claim_text, unit.text)
        if cond_err:
            violations.append(Violation('CONDITIONAL_DROP', cond_err, severity='MEDIUM'))
    
    return VerificationResult(
        is_faithful=len([v for v in violations if v.severity == 'HIGH']) == 0,
        violations=violations,
        overall_confidence=compute_confidence(citations),
        citation_count=len(citations),
        verified_count=sum(1 for c in citations if c.is_faithful)
    )
```

### 3.2 Numerical Verification (Deterministic)

```python
def verify_numbers(claim_text: str, evidence_text: str) -> List[str]:
    """
    Extract all numbers from claim and verify they appear in evidence.
    
    Critical for: dollar amounts, percentages, dates, days, codes
    """
    errors = []
    
    # Extract numeric patterns from claim
    claim_numbers = extract_numeric_patterns(claim_text)
    # Types: DOLLAR ($1,500), PERCENT (88.9%), DATE (01/01/2025), 
    #         INTEGER (30 days), CODE (DRG 470)
    
    evidence_numbers = extract_numeric_patterns(evidence_text)
    
    for cn in claim_numbers:
        # Find matching number in evidence
        match = find_numeric_match(cn, evidence_numbers)
        
        if not match:
            errors.append(
                f"Claim states {cn.formatted} but evidence does not contain this value. "
                f"Evidence numbers found: {[e.formatted for e in evidence_numbers[:5]]}"
            )
        elif cn.value != match.value:
            errors.append(
                f"Claim states {cn.formatted} but evidence says {match.formatted}"
            )
    
    return errors
```

### 3.3 NLI-Based Faithfulness (LLM Judge)

```python
ENTAILMENT_PROMPT = """You are a legal accuracy verifier. Determine if the CLAIM 
is faithfully supported by the EVIDENCE.

EVIDENCE (from a healthcare provider contract):
"{evidence_text}"

CLAIM (generated by AI assistant):
"{claim_text}"

Evaluate:
1. Is the claim directly stated or logically entailed by the evidence? (ENTAILED / NOT_ENTAILED / NEUTRAL)
2. Are all numbers/dates/amounts in the claim exactly matching the evidence?
3. Are all conditions/exceptions from the evidence preserved in the claim?
4. Does the claim apply the evidence to the correct entity/scope?

Respond as JSON:
{
    "verdict": "ENTAILED | NOT_ENTAILED | NEUTRAL",
    "confidence": 0.0-1.0,
    "reasoning": "one sentence explaining",
    "numbers_match": true/false,
    "conditions_preserved": true/false,
    "scope_correct": true/false
}"""

def verify_entailment(claim: str, evidence: str) -> EntailmentResult:
    """Use LLM as NLI judge for claim-evidence faithfulness."""
    response = call_llm(
        model="databricks-claude-sonnet-4-5",
        prompt=ENTAILMENT_PROMPT.format(
            evidence_text=evidence[:2000],  # Cap evidence length
            claim_text=claim
        ),
        max_tokens=500,
        temperature=0.0  # Deterministic for consistency
    )
    return parse_entailment_response(response)
```

---

## 4. CONFIDENCE ARCHITECTURE

### 4.1 Calibrated Confidence (Replacing Heuristic Buckets)

Current system: "High/Medium/Low" based on chunk count (not meaningful).

V2: Calibrated probability that the answer is correct, computed from multiple signals.

```python
@dataclass
class ConfidenceScore:
    """Calibrated confidence with interpretable components."""
    overall: float                    # 0-1, calibrated probability
    
    # Component scores (all 0-1)
    retrieval_confidence: float       # How relevant was retrieved evidence?
    citation_coverage: float          # What % of claims are cited?
    faithfulness_score: float         # What % of citations are verified faithful?
    state_confidence: float           # How confident in current/superseded labels?
    numerical_accuracy: float         # Did all numbers verify?
    
    # Calibration metadata
    calibration_bucket: str           # For monitoring: which calibration bin
    expected_accuracy: float          # Based on historical calibration curve
    
    @property
    def display_label(self) -> str:
        if self.overall >= 0.9:
            return "HIGH CONFIDENCE"
        elif self.overall >= 0.7:
            return "MODERATE CONFIDENCE"
        elif self.overall >= 0.5:
            return "LOW CONFIDENCE — verify with source"
        else:
            return "INSUFFICIENT EVIDENCE — manual review required"

def compute_confidence(citations: List[ExtractedCitation],
                       retrieval_scores: List[float],
                       state_annotations: List[ChunkState]) -> ConfidenceScore:
    """
    Compute calibrated confidence from verification signals.
    
    Calibration: Periodically validate against human judgments to ensure
    that "0.85 confidence" means "correct 85% of the time."
    """
    # Retrieval confidence: avg relevance of top-k evidence
    retrieval_conf = np.mean(retrieval_scores[:5]) if retrieval_scores else 0.0
    
    # Citation coverage: % of factual sentences that have citations
    total_factual = count_factual_sentences(answer)
    cited = len(citations)
    citation_cov = min(cited / max(total_factual, 1), 1.0)
    
    # Faithfulness: % of citations that passed verification
    verified = sum(1 for c in citations if c.is_faithful)
    faith_score = verified / max(len(citations), 1)
    
    # State confidence: min confidence across state annotations
    state_conf = min(s.supersession_confidence for s in state_annotations) if state_annotations else 0.5
    
    # Numerical accuracy: binary (all numbers verified or not)
    num_accuracy = 1.0 if all(c.support_strength > 0.8 for c in citations) else 0.6
    
    # Weighted combination (weights from calibration)
    overall = (
        0.25 * retrieval_conf +
        0.20 * citation_cov +
        0.30 * faith_score +    # Faithfulness weighted highest
        0.15 * state_conf +
        0.10 * num_accuracy
    )
    
    return ConfidenceScore(
        overall=overall,
        retrieval_confidence=retrieval_conf,
        citation_coverage=citation_cov,
        faithfulness_score=faith_score,
        state_confidence=state_conf,
        numerical_accuracy=num_accuracy,
        calibration_bucket=get_calibration_bucket(overall),
        expected_accuracy=lookup_calibration_curve(overall)
    )
```

### 4.2 Confidence Calibration Protocol

```python
def calibrate_confidence(evaluation_set: DataFrame) -> CalibrationCurve:
    """
    Calibrate confidence scores against human judgments.
    
    Process:
    1. Collect N=200+ (query, answer, confidence) triples from production
    2. Human annotators label each as CORRECT / PARTIALLY_CORRECT / INCORRECT
    3. Bin by confidence score (0.0-0.1, 0.1-0.2, ..., 0.9-1.0)
    4. Compute actual accuracy in each bin
    5. If bin accuracy diverges from bin midpoint by >10%, adjust weights
    
    Target: Expected Calibration Error (ECE) < 0.10
    """
    bins = np.linspace(0, 1, 11)
    bin_accuracies = []
    
    for i in range(len(bins) - 1):
        mask = (evaluation_set.confidence >= bins[i]) & (evaluation_set.confidence < bins[i+1])
        bin_samples = evaluation_set[mask]
        if len(bin_samples) > 0:
            accuracy = (bin_samples.human_label == 'CORRECT').mean()
            bin_accuracies.append((bins[i], bins[i+1], accuracy, len(bin_samples)))
    
    # ECE = weighted average of |accuracy - confidence| per bin
    ece = sum(n * abs(acc - (lo + hi) / 2) 
              for lo, hi, acc, n in bin_accuracies) / evaluation_set.shape[0]
    
    return CalibrationCurve(bins=bin_accuracies, ece=ece)
```

---

## 5. ANSWER REMEDIATION

### 5.1 When Verification Fails

```python
def remediate_answer(answer: str, violations: List[Violation],
                     evidence: Dict[str, LegalSemanticUnit]) -> str:
    """
    Fix or flag violations in generated answer before returning to user.
    """
    if not violations:
        return answer  # Clean pass
    
    critical_violations = [v for v in violations if v.severity == 'HIGH']
    
    if len(critical_violations) > 2:
        # Too many critical issues — regenerate with tighter constraints
        return regenerate_with_constraints(answer, violations, evidence)
    
    # Apply targeted fixes
    remediated = answer
    for violation in violations:
        if violation.type == 'NUMERICAL_DISTORTION':
            # Replace incorrect number with correct one from evidence
            remediated = fix_numerical_error(remediated, violation)
        elif violation.type == 'UNCITED_CLAIM':
            # Add disclaimer to uncited sentence
            remediated = add_disclaimer(remediated, violation.claim_text,
                                        "⚠️ Unable to verify this claim against contract text.")
        elif violation.type == 'TEMPORAL_CONFUSION':
            # Add state context
            remediated = add_state_context(remediated, violation)
        elif violation.type == 'CONDITIONAL_DROP':
            # Append missing conditions
            remediated = append_conditions(remediated, violation)
    
    return remediated
```

### 5.2 Escalation Rules

| Condition | Action |
| --- | --- |
| 0 violations | Return answer with HIGH CONFIDENCE |
| 1-2 MEDIUM violations | Return answer with disclaimer, MODERATE CONFIDENCE |
| 1 HIGH violation | Attempt auto-remediation, return with warning |
| 2+ HIGH violations | Regenerate answer with tighter prompt |
| 3+ HIGH after regeneration | Return "Unable to verify" + raw evidence links |
| FABRICATION detected | Block answer entirely, return evidence only |

---

## 6. VERIFICATION TELEMETRY

### 6.1 Metrics Tracked Per Query

```python
@dataclass
class VerificationTelemetry:
    query_id: str
    timestamp: datetime
    
    # Citation metrics
    total_claims: int
    cited_claims: int
    verified_faithful: int
    citation_coverage_pct: float
    
    # Violation metrics
    violations_critical: int
    violations_medium: int
    violation_types: List[str]
    
    # Confidence
    raw_confidence: float
    calibrated_confidence: float
    
    # Remediation
    was_remediated: bool
    remediation_type: Optional[str]
    
    # Latency
    verification_latency_ms: int
    total_latency_ms: int
```

### 6.2 Monitoring Dashboards

| Metric | Alert Threshold | Action |
| --- | --- | --- |
| Daily fabrication rate | >2% | Investigate retrieval coverage gap |
| Numerical distortion rate | >5% | Check extraction quality or LLM model drift |
| Average citation coverage | <80% | Tighten generation prompt constraints |
| Confidence ECE | >0.15 | Recalibrate confidence weights |
| Verification latency p95 | >3s | Optimize NLI judge or switch to lighter model |

---

*The citation verification framework is the difference between "AI that probably gets contract terms right" and "AI that provably traces every claim to source contract text with verified numerical accuracy." For legal-grade enterprise use, the latter is the only acceptable standard.*
