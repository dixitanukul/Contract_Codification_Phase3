-- ═══════════════════════════════════════════════════════════════════════════════
-- REIMBURSEMENT MODEL V2 — Validation Queries (Part 5 of 5)
-- 
-- Run AFTER migration to verify completeness, referential integrity,
-- and backward-compatibility of V2 tables.
-- 
-- Prerequisites: Parts 1-4 executed successfully
-- ═══════════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- CHECK 1: Table Row Counts Post-Migration
-- ─────────────────────────────────────────────────────────────────────────────
SELECT 'tbl_reimb_rate_rules' AS table_name, COUNT(*) AS row_count FROM dev_adb.raw.tbl_reimb_rate_rules
UNION ALL
SELECT 'tbl_reimb_formula_components', COUNT(*) FROM dev_adb.raw.tbl_reimb_formula_components
UNION ALL
SELECT 'tbl_reimb_stop_loss', COUNT(*) FROM dev_adb.raw.tbl_reimb_stop_loss
UNION ALL
SELECT 'tbl_reimb_carve_outs', COUNT(*) FROM dev_adb.raw.tbl_reimb_carve_outs
UNION ALL
SELECT 'tbl_reimb_escalators', COUNT(*) FROM dev_adb.raw.tbl_reimb_escalators
UNION ALL
SELECT 'tbl_reimb_conditions', COUNT(*) FROM dev_adb.raw.tbl_reimb_conditions
UNION ALL
SELECT 'tbl_reimb_lesser_of', COUNT(*) FROM dev_adb.raw.tbl_reimb_lesser_of
UNION ALL
SELECT 'dim_service_line_taxonomy', COUNT(*) FROM dev_adb.raw.dim_service_line_taxonomy
UNION ALL
SELECT 'dim_service_line_patterns', COUNT(*) FROM dev_adb.raw.dim_service_line_patterns
ORDER BY table_name;

-- ─────────────────────────────────────────────────────────────────────────────
-- CHECK 2: Orphan Check — Rules Without Formula Components
-- Expected: All rules should either have formula_json populated OR linked components
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    'Rules with NULL formula_json' AS check_name,
    COUNT(*) AS orphan_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM dev_adb.raw.tbl_reimb_rate_rules), 1) AS pct_of_total
FROM dev_adb.raw.tbl_reimb_rate_rules
WHERE formula_json IS NULL OR formula_json = ''
UNION ALL
SELECT
    'Rules with UNLINKED stop-loss',
    COUNT(*),
    NULL
FROM dev_adb.raw.tbl_reimb_stop_loss
WHERE rule_id = 'UNLINKED'
UNION ALL
SELECT
    'Rules with UNLINKED escalators',
    COUNT(*),
    NULL
FROM dev_adb.raw.tbl_reimb_escalators
WHERE rule_id = 'UNLINKED'
UNION ALL
SELECT
    'Rules with UNLINKED lesser-of',
    COUNT(*),
    NULL
FROM dev_adb.raw.tbl_reimb_lesser_of
WHERE rule_id = 'UNLINKED';

-- ─────────────────────────────────────────────────────────────────────────────
-- CHECK 3: Migration Coverage — % of V1 rates_all migrated to V2 rate_rules
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    (SELECT COUNT(*) FROM dev_adb.raw.tbl_contract_rates_all WHERE status = 'current') AS v1_current_rates,
    (SELECT COUNT(*) FROM dev_adb.raw.tbl_reimb_rate_rules) AS v2_rate_rules,
    ROUND(
        (SELECT COUNT(*) FROM dev_adb.raw.tbl_reimb_rate_rules) * 100.0 /
        NULLIF((SELECT COUNT(*) FROM dev_adb.raw.tbl_contract_rates_all WHERE status = 'current'), 0),
        1
    ) AS migration_coverage_pct;

-- ─────────────────────────────────────────────────────────────────────────────
-- CHECK 4: Taxonomy Coverage — % of rates classified vs "Unclassified"
-- Uses the same pattern-matching logic as v_rates_with_service_line
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    COUNT(*) AS total_rates,
    SUM(CASE WHEN t.service_line_id IS NOT NULL THEN 1 ELSE 0 END) AS classified_count,
    SUM(CASE WHEN t.service_line_id IS NULL THEN 1 ELSE 0 END) AS unclassified_count,
    ROUND(
        SUM(CASE WHEN t.service_line_id IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*),
        1
    ) AS classification_pct
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t
    ON EXISTS (
        SELECT 1 FROM dev_adb.raw.dim_service_line_patterns p
        WHERE p.service_line_id = t.service_line_id
          AND r.service_category ILIKE p.pattern_value
          AND (p.exclude_pattern IS NULL OR r.service_category NOT ILIKE p.exclude_pattern)
    );

-- Top unclassified categories (for pattern expansion)
SELECT
    r.service_category,
    r.rate_category,
    COUNT(*) AS occurrence_count,
    COUNT(DISTINCT r.provider_id) AS provider_count
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t
    ON EXISTS (
        SELECT 1 FROM dev_adb.raw.dim_service_line_patterns p
        WHERE p.service_line_id = t.service_line_id
          AND r.service_category ILIKE p.pattern_value
    )
WHERE t.service_line_id IS NULL
  AND r.service_category IS NOT NULL
  AND r.service_category != ''
GROUP BY r.service_category, r.rate_category
ORDER BY occurrence_count DESC
LIMIT 20;

-- ─────────────────────────────────────────────────────────────────────────────
-- CHECK 5: Backward-Compat View Row Count Comparison (V2 view vs V1 table)
-- Views should return comparable row counts to their V1 source tables
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    'v_genie_rates_current_v2 vs tbl_genie_rates_current' AS comparison,
    (SELECT COUNT(*) FROM dev_adb.raw.v_genie_rates_current_v2) AS v2_view_rows,
    (SELECT COUNT(*) FROM dev_adb.raw.tbl_genie_rates_current) AS v1_table_rows,
    ROUND(
        (SELECT COUNT(*) FROM dev_adb.raw.v_genie_rates_current_v2) * 100.0 /
        NULLIF((SELECT COUNT(*) FROM dev_adb.raw.tbl_genie_rates_current), 0),
        1
    ) AS v2_as_pct_of_v1
UNION ALL
SELECT
    'v_serving_capitation_v2 vs tbl_serving_capitation_card',
    (SELECT COUNT(*) FROM dev_adb.raw.v_serving_capitation_v2),
    (SELECT COUNT(*) FROM dev_adb.raw.tbl_serving_capitation_card),
    ROUND(
        (SELECT COUNT(*) FROM dev_adb.raw.v_serving_capitation_v2) * 100.0 /
        NULLIF((SELECT COUNT(*) FROM dev_adb.raw.tbl_serving_capitation_card), 0),
        1
    );

-- ─────────────────────────────────────────────────────────────────────────────
-- CHECK 6: Formula Type Distribution (sanity check on classification logic)
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    formula_type,
    COUNT(*) AS rule_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) AS pct_of_total,
    ROUND(AVG(rate_numeric), 2) AS avg_rate_numeric
FROM dev_adb.raw.tbl_reimb_rate_rules
GROUP BY formula_type
ORDER BY rule_count DESC;

-- ─────────────────────────────────────────────────────────────────────────────
-- CHECK 7: Domain Distribution (should roughly match V1 rate_category mix)
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    rate_domain,
    COUNT(*) AS rule_count,
    COUNT(DISTINCT provider_id) AS provider_count,
    ROUND(AVG(confidence_score), 2) AS avg_confidence
FROM dev_adb.raw.tbl_reimb_rate_rules
GROUP BY rate_domain
ORDER BY rule_count DESC;
