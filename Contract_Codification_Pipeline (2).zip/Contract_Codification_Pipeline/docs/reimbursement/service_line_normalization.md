# SERVICE LINE NORMALIZATION
## Extensible Taxonomy Replacing Hardcoded CASE WHEN Logic

**Document Class:** Taxonomy Design  
**Date:** 2026-05-22  
**Problem:** Current system uses a 25-entry hardcoded CASE WHEN in 13_build_serving.py. New service categories from LLM extraction silently fall into "Other Inpatient." No monitoring, no extensibility.  

---

## 1. CURRENT STATE (Verified)

### 1.1 Hardcoded Classification (13_build_serving.py, lines 111-129)

```sql
CASE
  WHEN service_category ILIKE '%Medical/Surgical%' THEN 'Medical/Surgical/Peds'
  WHEN service_category ILIKE '%ICU/CCU%' THEN 'ICU/CCU/PICU'
  ...
  ELSE 'Other Inpatient'  ← Silent catch-all
END AS service_line
```

**Problems:**
- 26 static entries — no way to add without code change
- "Other Inpatient" bucket grows as extraction improves (new services extracted)
- No hierarchical grouping (Subacute Levels I-III are siblings, not children of "Subacute")
- Outpatient, Professional, Capitation have NO taxonomy — just raw LLM text
- No standard codes (no linkage to CMS MS-DRG, APC, or HCPCS categories)

### 1.2 Impact at Full Scale

At 10,372 files (100% extraction), the LLM will extract hundreds of unique `service_category` values. The 26-entry CASE WHEN will correctly classify ~60% and dump 40% into "Other."

---

## 2. V2 TAXONOMY DESIGN

### 2.1 Hierarchical Service Line Taxonomy

```
Level 0: Domain
  └── Level 1: Service Group
       └── Level 2: Service Line (comparable unit)
            └── Level 3: Service Subtype (detail)
```

**Example:**
```
INPATIENT (L0)
  └── Acute Care (L1)
       ├── Medical/Surgical/Peds (L2)
       │    ├── General Med/Surg (L3)
       │    ├── Pediatrics (L3)
       │    └── Step-Down (L3)
       ├── ICU/CCU/PICU (L2)
       │    ├── Adult ICU (L3)
       │    ├── Cardiac ICU (L3)
       │    └── Pediatric ICU (L3)
       └── NICU (L2)
            ├── Level I (L3)
            ├── Level II (L3)
            ├── Level III (L3)
            └── Level IV (L3)
  └── Specialty Care (L1)
       ├── Cardiac (L2)
       │    ├── Coronary Surgery (L3)
       │    ├── PTCA (L3)
       │    └── Cardiac Catheterization (L3)
       ├── Psychiatric/Behavioral (L2)
       ├── Rehabilitation (L2)
       └── Transplant (L2)
  └── Subacute (L1)
       ├── Level I (L2)
       ├── Level II (L2)
       └── Level III (L2)
  └── Maternity (L1)
       ├── Normal Delivery (L2)
       ├── C-Section (L2)
       └── Boarder Baby (L2)

OUTPATIENT (L0)
  └── Surgical (L1)
       ├── Tier 1 - Minor (L2)
       ├── Tier 2 - Intermediate (L2)
       ├── ...
       └── Tier 10 - Major (L2)
  └── Emergency (L1)
       ├── ER Visit (L2)
       └── Urgent Care (L2)
  └── Therapy (L1)
       ├── Physical Therapy (L2)
       ├── Occupational Therapy (L2)
       ├── Speech Therapy (L2)
       └── Respiratory Therapy (L2)
  └── Diagnostic (L1)
       ├── Radiology (L2)
       ├── Pathology (L2)
       ├── Lab (L2)
       └── Imaging (L2)
  └── Infusion/Injection (L1)

PROFESSIONAL (L0)
  └── Physician Services (L1)
  └── Anesthesia (L1)
  └── Allied Health (L1)

CAPITATION (L0)
  └── By Aid Category (L1)
       ├── Aged (L2)
       ├── Disabled (L2)
       ├── Family/Child (L2)
       └── MCE (L2)
```

### 2.2 Delta Table Schema

```sql
CREATE TABLE dev_adb.raw.dim_service_line_taxonomy (
    -- Identity
    service_line_id         INT NOT NULL,
    service_line_code       STRING NOT NULL,    -- Machine-friendly: 'IP_ACUTE_MEDSURG'
    
    -- Hierarchy
    level                   INT NOT NULL,       -- 0=Domain, 1=Group, 2=Line, 3=Subtype
    domain                  STRING NOT NULL,    -- INPATIENT | OUTPATIENT | PROFESSIONAL | CAPITATION
    parent_id               INT,               -- FK to parent service_line_id (NULL for L0)
    
    -- Names
    display_name            STRING NOT NULL,    -- Human-friendly: 'Medical/Surgical/Peds'
    short_name              STRING,            -- Abbreviated: 'Med/Surg'
    
    -- Matching (replaces CASE WHEN)
    match_patterns          STRING NOT NULL,    -- JSON array: ["%Medical/Surgical%", "%Med/Surg%", "%Med-Surg%"]
    match_priority          INT DEFAULT 0,     -- Higher = match first (for overlapping patterns)
    
    -- Standard codes (optional linkage)
    cms_category            STRING,            -- CMS service category
    drg_range               STRING,            -- DRG range (e.g., "001-099" for Nervous System)
    apc_range               STRING,            -- APC range for outpatient
    revenue_code_range      STRING,            -- Revenue code range (e.g., "0200-0219")
    
    -- Analytics
    sort_order              INT NOT NULL,
    is_active               BOOLEAN DEFAULT TRUE,
    comparable_group        STRING,            -- For benchmarking: which lines are comparable
    
    -- Audit
    created_at              TIMESTAMP DEFAULT current_timestamp(),
    updated_at              TIMESTAMP
) USING DELTA;
```

### 2.3 Match Pattern Table (for complex matches)

```sql
CREATE TABLE dev_adb.raw.dim_service_line_patterns (
    pattern_id              INT NOT NULL,
    service_line_id         INT NOT NULL,    -- FK to taxonomy
    
    -- Pattern specification
    pattern_type            STRING NOT NULL,  -- ILIKE | REGEX | EXACT | STARTS_WITH
    pattern_value           STRING NOT NULL,  -- The actual pattern
    
    -- Exclusion patterns (match this BUT NOT that)
    exclude_pattern         STRING,          -- If this ALSO matches, skip this rule
    
    -- Priority
    priority                INT DEFAULT 0,   -- Higher wins on conflict
    
    -- Context (when should this pattern apply?)
    applies_to_domain       STRING,          -- Only match within this domain
    applies_to_provider     STRING           -- Provider-specific override
) USING DELTA;
```

---

## 3. CLASSIFICATION ALGORITHM

### 3.1 Replace CASE WHEN with Table-Driven Matching

```python
def classify_service_line(raw_service_category: str, domain: str = None) -> dict:
    """
    Classify a raw service_category string into the taxonomy.
    
    Returns: {service_line_id, display_name, level, confidence}
    """
    if not raw_service_category:
        return {'service_line_id': None, 'display_name': 'Unknown', 'confidence': 0}
    
    # Load patterns (cached in memory)
    patterns = get_active_patterns(domain)
    
    # Try patterns in priority order
    best_match = None
    best_priority = -1
    
    for pat in patterns:
        matched = False
        
        if pat.pattern_type == 'ILIKE':
            matched = sql_ilike(raw_service_category, pat.pattern_value)
        elif pat.pattern_type == 'REGEX':
            matched = bool(re.search(pat.pattern_value, raw_service_category, re.IGNORECASE))
        elif pat.pattern_type == 'EXACT':
            matched = raw_service_category.lower().strip() == pat.pattern_value.lower().strip()
        elif pat.pattern_type == 'STARTS_WITH':
            matched = raw_service_category.lower().startswith(pat.pattern_value.lower())
        
        if matched:
            # Check exclusion
            if pat.exclude_pattern and sql_ilike(raw_service_category, pat.exclude_pattern):
                continue
            
            if pat.priority > best_priority:
                best_match = pat
                best_priority = pat.priority
    
    if best_match:
        taxonomy = get_taxonomy_entry(best_match.service_line_id)
        return {
            'service_line_id': taxonomy.service_line_id,
            'service_line_code': taxonomy.service_line_code,
            'display_name': taxonomy.display_name,
            'domain': taxonomy.domain,
            'level': taxonomy.level,
            'parent_id': taxonomy.parent_id,
            'confidence': 0.90
        }
    
    return {
        'service_line_id': None,
        'display_name': f'Unclassified: {raw_service_category[:50]}',
        'domain': domain or 'UNKNOWN',
        'confidence': 0,
        'needs_review': True
    }
```

### 3.2 SQL-Based Classification (for bulk table operations)

```sql
-- Replace the CASE WHEN with a JOIN to the taxonomy
CREATE OR REPLACE VIEW dev_adb.raw.v_rates_with_service_line AS
SELECT 
    r.*,
    COALESCE(t.display_name, 'Unclassified') AS service_line,
    COALESCE(t.domain, 'UNKNOWN') AS service_domain,
    COALESCE(t.comparable_group, 'other') AS benchmark_group,
    t.service_line_id
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t
    ON EXISTS (
        SELECT 1 FROM dev_adb.raw.dim_service_line_patterns p
        WHERE p.service_line_id = t.service_line_id
          AND r.service_category ILIKE p.pattern_value
          AND (p.exclude_pattern IS NULL OR r.service_category NOT ILIKE p.exclude_pattern)
    );
```

---

## 4. MONITORING: UNCLASSIFIED DETECTION

### 4.1 New Category Alert

```sql
-- Run after every table rebuild to detect unmapped categories
CREATE OR REPLACE VIEW dev_adb.raw.v_unclassified_service_categories AS
SELECT 
    r.service_category,
    r.rate_category,
    COUNT(*) AS occurrence_count,
    COUNT(DISTINCT r.provider_id) AS provider_count,
    MIN(r.source_filename) AS example_source
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t
    ON EXISTS (
        SELECT 1 FROM dev_adb.raw.dim_service_line_patterns p
        WHERE p.service_line_id = t.service_line_id
          AND r.service_category ILIKE p.pattern_value
    )
WHERE t.service_line_id IS NULL
  AND r.service_category IS NOT NULL
  AND r.service_category != ''
GROUP BY r.service_category, r.rate_category
ORDER BY occurrence_count DESC;
```

### 4.2 Classification Coverage Metrics

```sql
-- Dashboard metric: what percentage of rates are classified?
SELECT 
    ROUND(SUM(CASE WHEN t.service_line_id IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) 
        AS classification_pct,
    COUNT(*) AS total_rates,
    SUM(CASE WHEN t.service_line_id IS NULL THEN 1 ELSE 0 END) AS unclassified_count
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN ... -- same join pattern
```

---

## 5. INITIAL TAXONOMY DATA

```sql
-- Seed with current 26 inpatient categories + expanded outpatient/capitation
INSERT INTO dev_adb.raw.dim_service_line_taxonomy VALUES
-- INPATIENT DOMAIN
(100, 'IP', 0, 'INPATIENT', NULL, 'Inpatient', 'IP', '[]', 0, 0, TRUE, NULL, NULL, NULL, NULL, NULL),
(110, 'IP_ACUTE', 1, 'INPATIENT', 100, 'Acute Care', NULL, '[]', 0, 1, TRUE, NULL, NULL, NULL, NULL, NULL),
(111, 'IP_ACUTE_MEDSURG', 2, 'INPATIENT', 110, 'Medical/Surgical/Peds', 'Med/Surg', '["%Medical/Surgical%","%Med/Surg%","%Med-Surg%","%Pediatric%"]', 10, 2, TRUE, 'medsurg', NULL, NULL, '0200-0219', NULL),
(112, 'IP_ACUTE_ICU', 2, 'INPATIENT', 110, 'ICU/CCU/PICU', 'ICU', '["%ICU%","%CCU%","%PICU%","%Critical Care%"]', 20, 3, TRUE, 'icu', NULL, NULL, '0210-0219', NULL),
(113, 'IP_ACUTE_NICU4', 2, 'INPATIENT', 110, 'NICU Level IV', 'NICU IV', '["%NICU%IV%","%NICU%Level 4%"]', 30, 4, TRUE, 'nicu', NULL, NULL, NULL, NULL),
(114, 'IP_ACUTE_NICU3', 2, 'INPATIENT', 110, 'NICU Level III', 'NICU III', '["%NICU%III%","%NICU%Level 3%"]', 29, 5, TRUE, 'nicu', NULL, NULL, NULL, NULL),
(115, 'IP_ACUTE_NICU2', 2, 'INPATIENT', 110, 'NICU Level II', 'NICU II', '["%NICU%II%","%NICU%Level 2%"]', 28, 6, TRUE, 'nicu', NULL, NULL, NULL, NULL),
(116, 'IP_ACUTE_NICU1', 2, 'INPATIENT', 110, 'NICU Level I', 'NICU I', '["%NICU%","%Neonatal%"]', 5, 7, TRUE, 'nicu', NULL, NULL, NULL, NULL),
-- ... (full seed in DDL file)

-- OUTPATIENT DOMAIN
(200, 'OP', 0, 'OUTPATIENT', NULL, 'Outpatient', 'OP', '[]', 0, 30, TRUE, NULL, NULL, NULL, NULL, NULL),
(210, 'OP_SURGICAL', 1, 'OUTPATIENT', 200, 'Surgical', NULL, '["%Surgical%","%Surgery%"]', 0, 31, TRUE, NULL, NULL, NULL, NULL, NULL),
(211, 'OP_SURG_TIER1', 2, 'OUTPATIENT', 210, 'Tier 1 - Minor', 'T1', '["%Tier 1%","%Tier I%","%Minor%"]', 10, 32, TRUE, 'op_surgical', NULL, NULL, NULL, NULL),
-- ... (10 surgical tiers)
(220, 'OP_EMERGENCY', 1, 'OUTPATIENT', 200, 'Emergency', 'ER', '["%Emergency%","%ER %","%Urgent%"]', 0, 42, TRUE, NULL, NULL, NULL, '0450-0459', NULL),
(230, 'OP_THERAPY', 1, 'OUTPATIENT', 200, 'Therapy Services', NULL, '["%Therapy%","%Rehab%"]', 0, 50, TRUE, NULL, NULL, NULL, NULL, NULL),
(240, 'OP_DIAGNOSTIC', 1, 'OUTPATIENT', 200, 'Diagnostic', NULL, '["%Radiology%","%Pathology%","%Lab%","%Imaging%"]', 0, 55, TRUE, NULL, NULL, NULL, NULL, NULL),
(250, 'OP_INFUSION', 1, 'OUTPATIENT', 200, 'Infusion/Injection', NULL, '["%Infusion%","%Injection%","%Chemotherapy%"]', 0, 60, TRUE, NULL, NULL, NULL, NULL, NULL);
```

---

## 6. MIGRATION

### Step 1: Create dim_service_line_taxonomy with seed data (non-breaking)
### Step 2: Create dim_service_line_patterns with expanded patterns
### Step 3: Create v_rates_with_service_line view (parallel to existing)
### Step 4: Run unclassified detection — add patterns for new categories
### Step 5: Replace CASE WHEN in 13_build_serving with JOIN to taxonomy
### Step 6: Retire dim_service_category (26-row hardcoded table)

---

*The taxonomy transforms service line classification from a fragile hardcoded list into an extensible, monitorable, hierarchical system that adapts as extraction coverage grows.*
