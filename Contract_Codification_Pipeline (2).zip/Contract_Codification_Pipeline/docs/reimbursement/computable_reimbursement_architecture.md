# COMPUTABLE REIMBURSEMENT ARCHITECTURE
## End-to-End System for Adjudication Simulation and Negotiation Modeling

**Document Class:** System Architecture  
**Date:** 2026-05-22  
**Scope:** Full architecture connecting rate rules, claim scenarios, and business intelligence  

---

## 1. ARCHITECTURE OVERVIEW

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                    COMPUTABLE REIMBURSEMENT PLATFORM                            │
├───────────────────────────────────────────────────────────────────────────────┤
│                                                                                │
│  DATA LAYER                      COMPUTE LAYER                 INTELLIGENCE    │
│  ───────────                     ─────────────                 ────────────    │
│                                                                                │
│  ┌─────────────────┐           ┌─────────────────┐          ┌──────────────┐ │
│  │ Rate Rules      │──────────▶│ Rule Engine     │─────────▶│ Adjudication │ │
│  │ (formula_json)  │           │ (evaluator)     │          │ Simulator    │ │
│  └─────────────────┘           └─────────────────┘          └──────────────┘ │
│                                                                                │
│  ┌─────────────────┐           ┌─────────────────┐          ┌──────────────┐ │
│  │ Stop-Loss       │──────────▶│ Modifier Chain  │─────────▶│ Negotiation  │ │
│  │ Carve-Outs      │           │ (apply mods)    │          │ Modeler      │ │
│  │ Escalators      │           └─────────────────┘          └──────────────┘ │
│  └─────────────────┘                                                          │
│                                                                                │
│  ┌─────────────────┐           ┌─────────────────┐          ┌──────────────┐ │
│  │ Service Line    │──────────▶│ Scenario Engine │─────────▶│ Financial    │ │
│  │ Taxonomy        │           │ (batch eval)    │          │ Projections  │ │
│  └─────────────────┘           └─────────────────┘          └──────────────┘ │
│                                                                                │
│  ┌─────────────────┐           ┌─────────────────┐          ┌──────────────┐ │
│  │ Conditions      │──────────▶│ Comparator      │─────────▶│ Network      │ │
│  │ Lesser-Of       │           │ (multi-prov)    │          │ Benchmarks   │ │
│  └─────────────────┘           └─────────────────┘          └──────────────┘ │
│                                                                                │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. USE CASE: ADJUDICATION SIMULATION

### 2.1 Purpose

Given a set of claims (real or synthetic), compute what the contracted reimbursement SHOULD be under each provider's terms. This enables:
- Payment accuracy validation
- Provider cost ranking for specific DRGs
- Network adequacy financial analysis

### 2.2 Implementation

```python
def simulate_adjudication(claims: DataFrame, provider_id: str) -> DataFrame:
    """
    Compute expected reimbursement for a set of claims.
    
    Input: claims DataFrame with columns:
        claim_id, service_line, los, total_charges, drg_code, drg_weight,
        implant_cost, drug_cost, program, network, admit_date
    
    Output: claims + computed reimbursement columns
    """
    results = []
    
    for claim in claims.collect():
        scenario = ClaimScenario(
            service_line=claim.service_line,
            rate_domain='INPATIENT' if claim.los > 0 else 'OUTPATIENT',
            length_of_stay=claim.los,
            total_charges=claim.total_charges,
            drg_code=claim.drg_code,
            drg_weight=claim.drg_weight,
            implant_cost=claim.implant_cost or 0,
            drug_cost=claim.drug_cost or 0,
            program=claim.program,
            network=claim.network,
            admit_date=claim.admit_date
        )
        
        result = evaluate_reimbursement(scenario, provider_id)
        
        results.append({
            'claim_id': claim.claim_id,
            'expected_payment': result.total_reimbursement,
            'formula_used': result.formula_type,
            'base_amount': result.base_amount,
            'stop_loss_adj': result.stop_loss_adjustment,
            'carve_out_add': result.carve_out_additions,
            'payment_vs_charges': result.total_reimbursement / claim.total_charges * 100
        })
    
    return spark.createDataFrame(results)
```

### 2.3 Batch Performance

```python
# For large claim volumes, use Spark UDF for parallel evaluation
@pandas_udf(result_schema)
def evaluate_claims_udf(claims_batch: pd.DataFrame) -> pd.DataFrame:
    """Vectorized claim evaluation using pandas_udf for Spark parallelism."""
    results = []
    for _, claim in claims_batch.iterrows():
        result = evaluate_reimbursement_fast(claim)
        results.append(result)
    return pd.DataFrame(results)
```

---

## 3. USE CASE: NEGOTIATION MODELING

### 3.1 Scenario Definition

```python
@dataclass
class NegotiationScenario:
    """Defines a proposed rate change for modeling."""
    provider_id: str
    
    # Rate changes (applied to matching rules)
    per_diem_change_pct: float = 0        # +3.0 = 3% increase
    case_rate_change_pct: float = 0
    outpatient_change_pct: float = 0
    stop_loss_threshold_change: float = 0  # +5000 = raise threshold by $5K
    
    # Structural changes
    add_lesser_of: bool = False            # Add lesser-of provision
    add_stop_loss: bool = False            # Add stop-loss where none exists
    convert_to_drg: bool = False           # Convert per-diem to DRG-weighted
    
    # Escalator changes
    new_escalator_pct: float = None        # Replace escalator with this rate
    cap_escalator_at: float = None         # Cap escalator at this percentage
```

### 3.2 Impact Modeling

```python
def model_negotiation_impact(scenario: NegotiationScenario, 
                            historical_claims: DataFrame = None) -> dict:
    """
    Model the financial impact of a proposed rate change.
    
    If historical_claims provided: compute actual dollar impact
    If not: compute representative scenario impact
    """
    provider_id = scenario.provider_id
    current_rules = get_rate_rules(provider_id)
    
    # Create modified rule set
    proposed_rules = apply_negotiation_changes(current_rules, scenario)
    
    # Generate or use claim scenarios
    if historical_claims is None:
        claims = generate_representative_claims(provider_id)
    else:
        claims = historical_claims
    
    # Evaluate both rule sets
    current_payments = batch_evaluate(claims, current_rules)
    proposed_payments = batch_evaluate(claims, proposed_rules)
    
    # Compute impact
    return {
        'summary': {
            'current_annual_cost': current_payments.sum(),
            'proposed_annual_cost': proposed_payments.sum(),
            'annual_impact': proposed_payments.sum() - current_payments.sum(),
            'impact_pct': (proposed_payments.sum() - current_payments.sum()) / current_payments.sum() * 100,
        },
        'by_service_line': compute_impact_by_service_line(current_payments, proposed_payments),
        'by_scenario_type': compute_impact_by_claim_type(current_payments, proposed_payments),
        'outlier_cases': find_high_impact_cases(current_payments, proposed_payments),
        'break_even_analysis': compute_break_even(current_rules, proposed_rules),
    }
```

### 3.3 Multi-Provider Comparison

```python
def compare_network_rates(service_line: str, scenario: ClaimScenario) -> DataFrame:
    """
    Compare reimbursement across all providers for a standard scenario.
    
    Returns ranked list showing what each provider would pay.
    """
    providers = get_active_providers()
    results = []
    
    for prov in providers:
        result = evaluate_reimbursement(scenario, prov.provider_id)
        results.append({
            'provider_name': prov.provider_name,
            'provider_id': prov.provider_id,
            'payment_amount': result.total_reimbursement,
            'formula_type': result.formula_type,
            'has_stop_loss': result.stop_loss_adjustment != 0,
            'per_diem_equivalent': result.total_reimbursement / max(scenario.length_of_stay, 1),
        })
    
    df = pd.DataFrame(results).sort_values('payment_amount')
    df['percentile'] = df['payment_amount'].rank(pct=True) * 100
    df['vs_median_pct'] = (df['payment_amount'] / df['payment_amount'].median() - 1) * 100
    
    return df
```

---

## 4. USE CASE: FINANCIAL PROJECTIONS

### 4.1 Multi-Year Forecasting

```python
def project_rates(provider_id: str, years_ahead: int = 5) -> DataFrame:
    """
    Project future rates using escalator formulas.
    
    For each rate rule with an escalator, compute Year 1-N values.
    """
    rules_with_escalators = get_rules_with_escalators(provider_id)
    projections = []
    
    for rule in rules_with_escalators:
        escalator = get_escalator(rule.rule_id)
        base_rate = rule.rate_numeric
        
        for year in range(1, years_ahead + 1):
            if escalator.escalator_type == 'FIXED_PERCENTAGE':
                projected = base_rate * ((1 + escalator.annual_increase_pct / 100) ** year)
            elif escalator.escalator_type == 'STEP_SCHEDULE':
                projected = getattr(escalator, f'year_{min(year, 4)}_rate', base_rate)
            elif escalator.escalator_type == 'CPI_LINKED':
                # Use historical CPI average as proxy
                avg_cpi = 3.2  # Historical average
                bounded_cpi = max(escalator.cpi_floor or 0, min(avg_cpi, escalator.cpi_cap or 10))
                projected = base_rate * ((1 + bounded_cpi / 100) ** year)
            else:
                projected = base_rate
            
            projections.append({
                'rule_id': rule.rule_id,
                'service_line': rule.service_line,
                'year': year,
                'projected_rate': round(projected, 2),
                'escalation_type': escalator.escalator_type,
                'cumulative_increase_pct': round((projected / base_rate - 1) * 100, 1)
            })
    
    return pd.DataFrame(projections)
```

---

## 5. DATA PIPELINE INTEGRATION

### 5.1 Extraction Enhancement

The LLM extraction prompt needs enhancement to capture compound formulas:

```
ENHANCED EXTRACTION INSTRUCTIONS (for V7 schema):

For EVERY rate, determine the formula structure:
- If "percentage of charges" → extract percentage AND any cap
- If "per diem" with stop-loss → extract per diem AND stop-loss threshold AND above-threshold rate
- If "lesser of" → extract ALL comparators
- If "DRG weight × base" → extract base rate AND weight source
- If "conversion factor × RVU" → extract CF, geographic adjustments
- If "escalated" → extract base year, annual increase, cap/floor

Output format for compound rates:
{
  "rate_numeric": <best single number>,
  "formula_structured": {
    "type": "PERCENTAGE_PLUS_CAP | PER_DIEM_WITH_STOP_LOSS | LESSER_OF | DRG_WEIGHTED | ...",
    "components": [...]
  }
}
```

### 5.2 Table Build Integration

```python
# In 08_build_rates.py, after extracting rate_numeric:
def build_formula_json(rate_row, doc_context):
    """
    Construct formula_json from extracted rate data.
    
    Uses multiple fields: rate_numeric, formula, percentage_of_charges,
    cap_amount, stop_loss provisions, conversion_factor, multiplier
    """
    formula = {'formula_type': 'FIXED', 'amount': rate_row.get('rate_numeric')}
    
    # Detect compound formulas
    if rate_row.get('percentage_of_charges'):
        formula = {
            'formula_type': 'PERCENTAGE_PLUS_CAP' if rate_row.get('cap_amount') else 'PERCENTAGE',
            'percentage': safe_float(rate_row['percentage_of_charges'].replace('%', '')),
            'of': 'BILLED_CHARGES',
        }
        if rate_row.get('cap_amount'):
            formula['cap'] = safe_float(rate_row['cap_amount'])
    
    elif rate_row.get('conversion_factor'):
        formula = {
            'formula_type': 'CONVERSION_FACTOR',
            'conversion_factor': safe_float(rate_row['conversion_factor']),
            'multiplied_by': 'RVU',
        }
        if rate_row.get('multiplier'):
            formula['geographic_multiplier'] = safe_float(rate_row['multiplier'])
    
    elif rate_row.get('rate_category', '').startswith('inpatient_per_diem'):
        formula = {
            'formula_type': 'PER_DIEM',
            'base_rate': rate_row.get('rate_numeric'),
            'unit': 'day'
        }
    
    elif rate_row.get('rate_category') == 'inpatient_case_rate':
        formula = {
            'formula_type': 'FIXED',
            'amount': rate_row.get('rate_numeric'),
            'unit': 'case',
            'included_days': rate_row.get('included_days')
        }
    
    return json.dumps(formula)
```

---

## 6. INTELLIGENCE NOTEBOOK ENHANCEMENTS

### 6.1 Enhanced Rate Benchmark (Notebook 25)

```python
def get_rate_benchmark_v2(provider_name: str, scenario: ClaimScenario = None):
    """
    Enhanced benchmark that uses computable reimbursement.
    
    Instead of comparing flat rate_numeric values, evaluates what
    each provider would actually PAY for a standard scenario.
    """
    if scenario is None:
        # Standard benchmark scenario
        scenario = ClaimScenario(
            service_line='Medical/Surgical/Peds',
            rate_domain='INPATIENT',
            length_of_stay=5,
            total_charges=50000,
            program='Commercial',
            network='All Networks'
        )
    
    # Compute for target provider
    target_result = evaluate_reimbursement(scenario, target_provider_id)
    
    # Compute for network
    network_results = compare_network_rates(scenario.service_line, scenario)
    
    # Position target within network
    percentile = network_results[
        network_results['provider_id'] == target_provider_id
    ]['percentile'].values[0]
    
    return {
        'provider_payment': target_result.total_reimbursement,
        'formula_used': target_result.formula_type,
        'network_percentile': percentile,
        'network_median': network_results['payment_amount'].median(),
        'network_p25': network_results['payment_amount'].quantile(0.25),
        'network_p75': network_results['payment_amount'].quantile(0.75),
        'computation_breakdown': target_result.computation_steps,
    }
```

---

## 7. TABLE DEPENDENCY MAP

```
[LLM Extraction]
    │
    ▼
[tbl_reimb_rate_rules]              ← Core: every rate as a structured rule
    │
    ├──▶ [tbl_reimb_formula_components] ← Expression tree nodes
    ├──▶ [tbl_reimb_stop_loss]          ← Multi-tier stop-loss
    ├──▶ [tbl_reimb_carve_outs]         ← Exception provisions
    ├──▶ [tbl_reimb_escalators]         ← Rate progression
    ├──▶ [tbl_reimb_conditions]         ← Applicability rules
    └──▶ [tbl_reimb_lesser_of]          ← Comparison logic
    
[dim_service_line_taxonomy]          ← Hierarchical classification
    └──▶ [dim_service_line_patterns]    ← Matching rules

[Rate Rule Engine]                   ← Compute layer (Python)
    ├──▶ Adjudication Simulator
    ├──▶ Negotiation Modeler
    ├──▶ Financial Projector
    └──▶ Network Benchmarker
```

---

## 8. IMPLEMENTATION TIMELINE

| Week | Deliverable | Dependencies |
| --- | --- | --- |
| 1 | dim_service_line_taxonomy + patterns (seed data) | None |
| 1 | tbl_reimb_rate_rules (DDL + migration from v1) | None |
| 2 | tbl_reimb_formula_components + builders | Rate rules table |
| 2 | tbl_reimb_stop_loss + tbl_reimb_carve_outs | Rate rules table |
| 3 | tbl_reimb_escalators + tbl_reimb_conditions | Rate rules table |
| 3 | tbl_reimb_lesser_of | Rate rules table |
| 4 | Rate Rule Engine (Python evaluator) | All tables |
| 5 | Adjudication Simulator | Engine |
| 5 | Negotiation Modeler | Engine |
| 6 | Integration with intelligence notebooks | All |
| 6 | Backward-compatible views | All |

**Total: 6 weeks to full computable reimbursement**

---

## 9. MIGRATION COMPATIBILITY

### 9.1 Non-Breaking Deployment

1. All v2 tables created alongside existing v1 tables
2. Existing intelligence notebooks continue working via v1 tables
3. v2 views created with backward-compatible schemas
4. Switchover is a SCHEMA reference change (one line per notebook)
5. v1 tables retained for 30 days post-switch

### 9.2 Data Quality During Migration

```python
def validate_migration():
    """Ensure v2 produces same results as v1 for simple cases."""
    # For every rate in v1 with a simple fixed rate:
    # Evaluate through v2 engine → should produce same rate_numeric
    v1_rates = spark.table("tbl_genie_rates_current")
    v2_results = []
    
    for rate in v1_rates.limit(1000).collect():
        scenario = ClaimScenario(
            service_line=rate.rate_category,
            rate_domain='INPATIENT',
            length_of_stay=1,  # 1 day for per-diem comparison
            total_charges=0,
            program=rate.program_normalized,
            network=rate.network
        )
        result = evaluate_reimbursement(scenario, rate.provider_id)
        v2_results.append({
            'v1_rate': rate.rate_numeric,
            'v2_rate': result.base_amount,
            'match': abs(rate.rate_numeric - result.base_amount) < 0.01
        })
    
    match_pct = sum(1 for r in v2_results if r['match']) / len(v2_results) * 100
    print(f"Migration validation: {match_pct:.1f}% match (target: >99%)")
```

---

*This architecture transforms the platform from a rate lookup system into a financial computation engine — enabling adjudication simulation, what-if negotiation modeling, multi-year projections, and true reimbursement intelligence.*
