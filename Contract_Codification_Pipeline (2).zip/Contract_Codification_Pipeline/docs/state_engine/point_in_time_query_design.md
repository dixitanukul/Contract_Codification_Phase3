# POINT-IN-TIME QUERY DESIGN
## Temporal Reconstruction Patterns for Contract Intelligence

**Document Class:** Query Architecture Specification  
**Date:** 2026-05-22  
**Scope:** SQL patterns for reconstructing contract state at any historical date  

---

## 1. QUERY TAXONOMY

| Query Type | Question Answered | Example |
| --- | --- | --- |
| Current State | What's true right now? | "Show current rates for Kaiser" |
| Point-in-Time | What was true on date X? | "What were rates on 2023-06-15?" |
| Rate History | How did a rate change over time? | "Per diem history for Sutter" |
| Delta Report | What changed between two dates? | "Rate changes Q1 2023 vs Q1 2024" |
| Amendment Impact | What did amendment X change? | "Impact of Amendment 5" |
| Retroactive Audit | What did we believe at time T? | "System state as of last Tuesday" |

---

## 2. CORE TEMPORAL PREDICATES

### 2.1 Standard Temporal Filters

```sql
-- Predicate: "valid at date D" (business reality)
-- A rate is valid at date D if it started before D and hasn't ended
valid_from <= :as_of_date AND (valid_to IS NULL OR valid_to > :as_of_date)

-- Predicate: "believed at timestamp T" (system knowledge)  
-- A record represents current belief if tx_to is NULL
-- A record was believed at timestamp T if it was recorded before T and not yet retracted
tx_from <= :knowledge_time AND (tx_to IS NULL OR tx_to > :knowledge_time)

-- Combined: "what we believed at T about date D"
tx_from <= :knowledge_time AND (tx_to IS NULL OR tx_to > :knowledge_time)
AND valid_from <= :as_of_date AND (valid_to IS NULL OR valid_to > :as_of_date)
```

### 2.2 Reusable View Functions

```sql
-- Create parameterized functions for temporal queries
CREATE OR REPLACE FUNCTION dev_adb.raw.rates_as_of(
    p_provider_id STRING,
    p_as_of_date DATE
)
RETURNS TABLE (
    rate_category STRING,
    service_category STRING,
    rate_numeric FLOAT,
    program STRING,
    source_filename STRING,
    effective_from DATE,
    supersession_confidence FLOAT
)
RETURN
    SELECT rate_category, service_category, rate_numeric, program,
           source_filename, valid_from AS effective_from, supersession_confidence
    FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal
    WHERE contract_id IN (
        SELECT contract_id FROM dev_adb.raw.tbl_v2_contract_registry
        WHERE provider_id = p_provider_id AND status IN ('ACTIVE', 'AMENDED')
    )
    AND tx_to IS NULL  -- Current belief
    AND valid_from <= p_as_of_date
    AND (valid_to IS NULL OR valid_to > p_as_of_date);
```

---

## 3. QUERY PATTERNS

### 3.1 Pattern: Current State (Most Common)

**Use case:** "What are Provider X's current rates?"

```sql
-- Optimized: uses materialized current-state snapshot
SELECT 
    r.provider_name,
    r.rate_category,
    r.service_category,
    r.rate_numeric,
    r.program_normalized,
    r.source_filename,
    r.effective_date
FROM dev_adb.raw.tbl_v2_rates_current_snapshot r
JOIN dev_adb.raw.tbl_v2_contract_registry c ON r.contract_id = c.contract_id
WHERE c.provider_id = :provider_id
  AND c.status = 'ACTIVE'
ORDER BY r.rate_category, r.service_category;
```

**Performance:** Direct table scan on pre-materialized snapshot. Sub-second.

### 3.2 Pattern: Point-in-Time Rate Reconstruction

**Use case:** "What were Kaiser's inpatient rates on July 1, 2023?"

```sql
SELECT 
    rf.rate_category,
    rf.service_category,
    rf.rate_numeric,
    rf.rate_text,
    rf.program,
    rf.source_filename,
    rf.valid_from AS effective_since,
    rf.valid_to AS effective_until,
    rf.supersession_confidence
FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal rf
JOIN dev_adb.raw.tbl_v2_contract_registry cr ON rf.contract_id = cr.contract_id
WHERE cr.provider_name ILIKE '%Kaiser%'
  AND cr.status IN ('ACTIVE', 'AMENDED', 'TERMINATED')  -- Include terminated for historical
  AND rf.tx_to IS NULL                         -- Current belief (most recent knowledge)
  AND rf.valid_from <= DATE '2023-07-01'       -- Rate was in effect
  AND (rf.valid_to IS NULL OR rf.valid_to > DATE '2023-07-01')  -- Still in effect on that date
  AND rf.rate_category LIKE 'inpatient%'
ORDER BY rf.rate_category, rf.service_category;
```

### 3.3 Pattern: Rate Change History (Timeline)

**Use case:** "Show me how Sutter's per diem rate changed over time"

```sql
WITH rate_versions AS (
    SELECT 
        rf.rate_numeric,
        rf.valid_from,
        rf.valid_to,
        rf.source_filename,
        rf.superseded_by_amendment,
        rf.supersession_type,
        LAG(rf.rate_numeric) OVER (
            PARTITION BY rf.contract_id, rf.rate_category, rf.service_category
            ORDER BY rf.valid_from
        ) AS previous_rate
    FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal rf
    JOIN dev_adb.raw.tbl_v2_contract_registry cr ON rf.contract_id = cr.contract_id
    WHERE cr.provider_name ILIKE '%Sutter%'
      AND rf.rate_category = 'inpatient_per_diem'
      AND rf.tx_to IS NULL  -- Current belief only
)
SELECT
    valid_from AS effective_date,
    valid_to AS superseded_date,
    rate_numeric AS rate,
    previous_rate,
    rate_numeric - COALESCE(previous_rate, rate_numeric) AS change_amount,
    ROUND((rate_numeric - COALESCE(previous_rate, rate_numeric)) / NULLIF(previous_rate, 0) * 100, 1) AS change_pct,
    source_filename AS established_by,
    superseded_by_amendment AS replaced_by
FROM rate_versions
ORDER BY valid_from;
```

### 3.4 Pattern: Amendment Impact Analysis

**Use case:** "What did Amendment 3 for Provider X change?"

```sql
WITH amendment_changes AS (
    SELECT
        -- New rate (introduced by this amendment)
        new_rf.rate_category,
        new_rf.service_category,
        new_rf.rate_numeric AS new_rate,
        new_rf.valid_from AS new_effective_date,
        -- Old rate (superseded)
        old_rf.rate_numeric AS old_rate,
        old_rf.valid_from AS old_effective_date,
        old_rf.source_filename AS previously_from,
        -- Metadata
        sd.supersession_type,
        sd.confidence
    FROM dev_adb.raw.tbl_v2_supersession_decisions sd
    JOIN dev_adb.raw.tbl_v2_rate_facts_bitemporal new_rf 
        ON sd.superseding_fact_id = new_rf.rate_fact_id AND new_rf.tx_to IS NULL
    JOIN dev_adb.raw.tbl_v2_rate_facts_bitemporal old_rf 
        ON sd.superseded_fact_id = old_rf.rate_fact_id AND old_rf.tx_to IS NULL
    WHERE sd.amendment_id = :amendment_id
      AND sd.superseded_fact_type = 'rate'
)
SELECT
    rate_category,
    service_category,
    old_rate,
    new_rate,
    new_rate - old_rate AS absolute_change,
    ROUND((new_rate - old_rate) / NULLIF(old_rate, 0) * 100, 1) AS pct_change,
    supersession_type,
    confidence,
    new_effective_date,
    previously_from
FROM amendment_changes
ORDER BY ABS(new_rate - old_rate) DESC;
```

### 3.5 Pattern: Delta Report (Period Comparison)

**Use case:** "Compare rates between Q1 2023 and Q1 2024"

```sql
WITH rates_q1_2023 AS (
    SELECT rate_fact_id, contract_id, rate_category, service_category, rate_numeric, program
    FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal
    WHERE tx_to IS NULL
      AND valid_from <= DATE '2023-03-31'
      AND (valid_to IS NULL OR valid_to > DATE '2023-01-01')
      AND contract_id IN (
          SELECT contract_id FROM dev_adb.raw.tbl_v2_contract_registry
          WHERE provider_id = :provider_id
      )
),
rates_q1_2024 AS (
    SELECT rate_fact_id, contract_id, rate_category, service_category, rate_numeric, program
    FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal
    WHERE tx_to IS NULL
      AND valid_from <= DATE '2024-03-31'
      AND (valid_to IS NULL OR valid_to > DATE '2024-01-01')
      AND contract_id IN (
          SELECT contract_id FROM dev_adb.raw.tbl_v2_contract_registry
          WHERE provider_id = :provider_id
      )
)
SELECT
    COALESCE(r24.rate_category, r23.rate_category) AS rate_category,
    COALESCE(r24.service_category, r23.service_category) AS service_category,
    r23.rate_numeric AS rate_q1_2023,
    r24.rate_numeric AS rate_q1_2024,
    r24.rate_numeric - r23.rate_numeric AS change,
    ROUND((r24.rate_numeric - r23.rate_numeric) / NULLIF(r23.rate_numeric, 0) * 100, 1) AS pct_change,
    CASE 
        WHEN r23.rate_fact_id IS NULL THEN 'NEW'
        WHEN r24.rate_fact_id IS NULL THEN 'REMOVED'
        WHEN r24.rate_numeric > r23.rate_numeric THEN 'INCREASED'
        WHEN r24.rate_numeric < r23.rate_numeric THEN 'DECREASED'
        ELSE 'UNCHANGED'
    END AS change_type
FROM rates_q1_2023 r23
FULL OUTER JOIN rates_q1_2024 r24 
    ON r23.contract_id = r24.contract_id
    AND r23.rate_category = r24.rate_category
    AND r23.service_category = r24.service_category
ORDER BY ABS(COALESCE(r24.rate_numeric, 0) - COALESCE(r23.rate_numeric, 0)) DESC;
```

### 3.6 Pattern: Retroactive Audit

**Use case:** "What did the system show for Provider X on May 16 at 3pm?"

```sql
-- Reconstruct system state at a specific moment
SELECT 
    rf.rate_category,
    rf.service_category,
    rf.rate_numeric,
    rf.valid_from,
    rf.tx_from AS recorded_at,
    rf.supersession_type
FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal rf
WHERE rf.contract_id IN (
    SELECT contract_id FROM dev_adb.raw.tbl_v2_contract_registry
    WHERE provider_id = :provider_id
)
-- Transaction time: what was believed at that moment
AND rf.tx_from <= TIMESTAMP '2026-05-16 15:00:00'
AND (rf.tx_to IS NULL OR rf.tx_to > TIMESTAMP '2026-05-16 15:00:00')
-- Valid time: what was considered "current" at that moment
AND rf.valid_to IS NULL  -- Was still considered valid
ORDER BY rf.rate_category;
```

---

## 4. INTELLIGENCE LAYER INTEGRATION

### 4.1 Updated Intelligence Functions

```python
def get_rate_benchmark(provider_name: str, as_of_date: date = None):
    """
    Enhanced rate benchmark with optional temporal parameter.
    
    If as_of_date is provided: reconstruct rates at that date
    If as_of_date is None: use current-state snapshot (fast path)
    """
    if as_of_date is None:
        # Fast path: use materialized current state
        rates = spark.sql(f"""
            SELECT * FROM tbl_v2_rates_current_snapshot
            WHERE provider_id = '{_safe_input(provider_name)}'
        """)
    else:
        # Temporal path: point-in-time reconstruction
        rates = spark.sql(f"""
            SELECT * FROM rates_as_of('{_safe_input(provider_name)}', '{as_of_date}')
        """)
    
    return compute_benchmark(rates)


def get_amendment_impact(provider_name: str, amendment_order: int):
    """
    Show exactly what changed in a specific amendment.
    Uses supersession decisions to identify paired rates.
    """
    amendment = find_amendment(provider_name, amendment_order)
    
    changes = spark.sql(f"""
        SELECT 
            new_r.rate_category,
            old_r.rate_numeric AS before,
            new_r.rate_numeric AS after,
            new_r.rate_numeric - old_r.rate_numeric AS change,
            sd.supersession_type,
            sd.confidence
        FROM tbl_v2_supersession_decisions sd
        JOIN tbl_v2_rate_facts_bitemporal new_r ON sd.superseding_fact_id = new_r.rate_fact_id
        JOIN tbl_v2_rate_facts_bitemporal old_r ON sd.superseded_fact_id = old_r.rate_fact_id
        WHERE sd.amendment_id = '{amendment.amendment_id}'
          AND new_r.tx_to IS NULL AND old_r.tx_to IS NULL
    """)
    
    return format_amendment_impact(changes)
```

### 4.2 Genie Space Integration

Add temporal parameters to Genie space:

```
SQL Examples (updated):
- "What are Kaiser's current per diem rates?" 
  → Uses tbl_v2_rates_current_snapshot (fast)
  
- "What were Kaiser's rates in January 2023?"
  → Uses rates_as_of('Kaiser', '2023-01-15')
  
- "How have Sutter's rates changed over time?"
  → Uses rate history timeline query

- "What did Amendment 3 change for Providence?"
  → Uses amendment impact analysis query
```

---

## 5. PERFORMANCE OPTIMIZATION

### 5.1 Indexing Strategy (Z-ORDER)

```sql
-- Rate facts: optimize for temporal range scans
OPTIMIZE tbl_v2_rate_facts_bitemporal
ZORDER BY (contract_id, valid_from, tx_from);

-- Supersession decisions: optimize for amendment lookups
OPTIMIZE tbl_v2_supersession_decisions
ZORDER BY (amendment_id, contract_id);
```

### 5.2 Materialized Snapshots

| Snapshot | Refresh Frequency | Purpose |
| --- | --- | --- |
| tbl_v2_rates_current_snapshot | After every table rebuild | Fast current-state queries |
| tbl_v2_rate_changes_summary | Weekly | Dashboard roll-ups |
| tbl_v2_provider_rate_timeline | After every amendment | Pre-computed history |

### 5.3 Query Performance Targets

| Query Type | Target Latency | Strategy |
| --- | --- | --- |
| Current state (single provider) | < 500ms | Materialized snapshot |
| Point-in-time (single provider) | < 2s | Z-ORDER on valid_from |
| Rate history (single provider) | < 3s | Partition + Z-ORDER |
| Delta report (period comparison) | < 5s | Pre-aggregated or cached |
| Full network benchmark | < 10s | Materialized + broadcast join |

---

## 6. BACKWARD COMPATIBILITY

### 6.1 Drop-In Replacement Views

```sql
-- These views ensure existing intelligence notebooks work unchanged
CREATE OR REPLACE VIEW dev_adb.raw.tbl_genie_rates_current AS
SELECT
    cr.provider_name,
    cr.provider_id,
    rf.rate_category,
    rf.service_category,
    rf.rate_text,
    rf.rate_numeric,
    rf.rate_type_detail,
    rf.valid_from AS effective_date_parsed,
    rf.formula,
    NULL AS notes,
    rf.revenue_codes,
    rf.program,
    rf.network,
    COALESCE(rf.program_normalized, rf.program) AS program_normalized,
    rf.source_filename
FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal rf
JOIN dev_adb.raw.tbl_v2_contract_registry cr ON rf.contract_id = cr.contract_id
WHERE rf.tx_to IS NULL           -- Current belief
  AND rf.valid_to IS NULL        -- Currently valid
  AND cr.status = 'ACTIVE';

-- Amendment timeline: backward compatible
CREATE OR REPLACE VIEW dev_adb.raw.tbl_genie_amendment_timeline AS
SELECT
    cr.provider_name,
    cr.provider_id,
    ar.source_filename,
    ar.document_type,
    ar.amendment_order,
    ar.effective_date,
    ar.summary_of_changes,
    ar.scope_type,
    ar.scope_confidence
FROM dev_adb.raw.tbl_v2_amendment_registry ar
JOIN dev_adb.raw.tbl_v2_contract_registry cr ON ar.contract_id = cr.contract_id
ORDER BY cr.provider_name, ar.amendment_order;
```

---

*Point-in-time queries transform the platform from "what's latest" to "what was true when" — enabling temporal analysis, amendment impact measurement, and retroactive auditing without any intelligence notebook changes.*
