# Databricks notebook source
# DBTITLE 1,OCR Extraction Overview
# MAGIC %md
# MAGIC # 02 — OCR Text Extraction (2-Tier)
# MAGIC **Extracts text from PDFs using pypdf (Tier 1) and ai_parse_document (Tier 2).**
# MAGIC 
# MAGIC | Tier | Tool | Handles | Speed |
# MAGIC |------|------|---------|-------|
# MAGIC | 1 | pypdf (14 processes) | ~82% of files | ~5x parallel via ProcessPoolExecutor |
# MAGIC | 2 | ai_parse_document | Scanned/complex PDFs | Paid API, batch of 25 |
# MAGIC 
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `file_registry` dict (from 01) | `checkpoints/step1_parsed_v2.parquet` |
# MAGIC | `valid_files` list (from 01) | Text for each PDF (full_text column) |
# MAGIC 
# MAGIC **Run after:** `01_file_discovery`  
# MAGIC **Run before:** `03_metadata_parsing`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,pypdf Extraction Function (Process-Safe)
def _pypdf_extract_proc(fname, path, provider_folder, file_size_bytes, timeout_sec):
    """Process-safe pypdf extraction with per-page timeout enforcement.
    
    Called by ProcessPoolExecutor — each invocation runs in a separate OS process,
    bypassing the GIL for true CPU parallelism. The internal timeout checks after
    each page and bails out if elapsed > timeout_sec.
    """
    import time
    from pypdf import PdfReader
    start = time.time()
    try:
        reader = PdfReader(path)
        if reader.is_encrypted:
            try:
                reader.decrypt('')
            except Exception:
                return {'filename': fname, 'path': path, 'num_pages': 0,
                        'full_text': '', 'text_length': 0, 'parse_error': 'encrypted_pdf',
                        'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}
        pages_text = []
        for page in reader.pages:
            if time.time() - start > timeout_sec:
                return {'filename': fname, 'path': path, 'num_pages': len(reader.pages),
                        'full_text': '\n\n'.join(pages_text),
                        'text_length': sum(len(t) for t in pages_text),
                        'parse_error': f'timeout_{timeout_sec}s',
                        'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}
            text = page.extract_text() or ''
            pages_text.append(text)
        full_text = '\n\n'.join(pages_text)
        return {'filename': fname, 'path': path, 'num_pages': len(reader.pages),
                'full_text': full_text, 'text_length': len(full_text), 'parse_error': None,
                'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}
    except Exception as e:
        return {'filename': fname, 'path': path, 'num_pages': 0,
                'full_text': '', 'text_length': 0, 'parse_error': f'pypdf error: {e}',
                'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}



# COMMAND ----------

# DBTITLE 1,Tier 1 - pypdf Multiprocess Extraction
all_results = []

# Process empty files
for f in empty_files:
    m = file_registry[f]
    all_results.append({'filename': f, 'path': m['path'], 'parse_error': 'Empty file',
        'num_pages': 0, 'full_text': '', 'text_length': 0, 'extraction_method': 'empty',
        'provider_folder': m['provider_folder'], 'file_size_bytes': 0, 'ocr_pages_processed': 0})

# ═══ TIER 1: pypdf (ProcessPoolExecutor — bypasses GIL for true parallelism) ═══
ocr_candidates_df = pd.DataFrame()
if valid_files and HAS_PYPDF:
    print(f"\n  ── Tier 1: pypdf ({len(valid_files):,} files, {PYPDF_WORKERS} processes, {PYPDF_TIMEOUT}s timeout)")
    t0 = time.time()
    _tier1_timeout_count = 0

    _tier1_args = [(fname, file_registry[fname]['path'], file_registry[fname]['provider_folder'],
                    file_registry[fname]['file_size_bytes'], PYPDF_TIMEOUT) for fname in valid_files]

    pypdf_results = []
    with ProcessPoolExecutor(max_workers=min(PYPDF_WORKERS, len(valid_files))) as ex:
        futures = {ex.submit(_pypdf_extract_proc, *args): args[0] for args in _tier1_args}
        done_count = 0
        for fut in as_completed(futures):
            result = fut.result()
            pypdf_results.append(result)
            if result.get('parse_error') and 'timeout' in str(result.get('parse_error', '')):
                _tier1_timeout_count += 1
            done_count += 1
            if done_count % 500 == 0:
                elapsed = time.time() - t0
                rate = done_count / elapsed
                eta_min = (len(valid_files) - done_count) / rate / 60 if rate > 0 else 0
                print(f"     Tier 1 progress: {done_count:,}/{len(valid_files):,} ({rate:.1f} files/s, ETA {eta_min:.0f}m, timeouts: {_tier1_timeout_count})")

    pypdf_df = pd.DataFrame(pypdf_results)
    good_mask = pypdf_df['text_length'].fillna(0) >= MIN_GOOD_CHARS
    per_page = pypdf_df['text_length'].fillna(0) / pypdf_df['num_pages'].clip(lower=1)
    needs_ocr_mask = ~good_mask | (per_page < MIN_CHARS_PER_PAGE)

    good_df = pypdf_df[~needs_ocr_mask].copy()
    good_df['extraction_method'] = 'pypdf'
    good_df['ocr_pages_processed'] = 0
    all_results.extend(good_df.to_dict('records'))
    ocr_candidates_df = pypdf_df[needs_ocr_mask].copy()
    print(f"     ✅ Tier 1 done: {len(good_df):,} OK, {len(ocr_candidates_df):,} → Tier 2 (timeouts: {_tier1_timeout_count}) ({time.time()-t0:.1f}s)")

    # ─── CHECKPOINT: Save Tier 1 results immediately ───
    if all_results:
        _t1_df = pd.DataFrame(all_results)
        _t1_combined = pd.concat([existing_df, _t1_df], ignore_index=True).drop_duplicates('filename', keep='last') if existing_df is not None else _t1_df
        _t1_combined.to_parquet(STEP1_FILE, index=False)
        existing_df = _t1_combined
        already_parsed = set(_t1_combined['filename'])
        print(f"     💾 Tier 1 checkpoint saved: {len(_t1_combined):,} files")


# COMMAND ----------

# DBTITLE 1,Tier 2 - ai_parse_document for Failed/Scanned PDFs
# ═══ TIER 2: ai_parse_document (scanned/complex PDFs) ═══
# Replaces pytesseract OCR which was too slow (150+ hrs for 1,246 files).
# ai_parse_document is Spark-distributed, batched, and produces higher quality
# output for scanned documents.
if len(ocr_candidates_df) > 0:
    ai_filenames = ocr_candidates_df['filename'].tolist()
    # Build lookup of pypdf partial text (used as fallback if ai_parse fails)
    _pypdf_partial = dict(zip(ocr_candidates_df['filename'],
                              zip(ocr_candidates_df['text_length'].fillna(0).astype(int),
                                  ocr_candidates_df['full_text'].fillna(''))))
    
    print(f"\n  ── Tier 2: ai_parse_document ({len(ai_filenames):,} files, batch={AI_BATCH_SIZE}, concurrency={AI_CONCURRENCY})")
    ai_filenames.sort(key=lambda f: file_registry[f]['file_size_bytes'])
    t_ai = time.time()

    binary_schema = StructType([StructField('filename', StringType()), StructField('content', BinaryType())])
    def _read_binary(fname):
        with open(file_registry[fname]['path'], 'rb') as fh:
            return (fname, fh.read())

    num_batches = math.ceil(len(ai_filenames) / AI_BATCH_SIZE)
    ai_ok = ai_fallback = ai_empty = 0

    for bi in range(num_batches):
        batch = ai_filenames[bi * AI_BATCH_SIZE : (bi + 1) * AI_BATCH_SIZE]
        with ThreadPoolExecutor(max_workers=min(8, len(batch))) as ex:
            batch_data = list(ex.map(_read_binary, batch))

        n_parts = min(len(batch), AI_CONCURRENCY)
        spark.createDataFrame(batch_data, schema=binary_schema).repartition(n_parts).createOrReplaceTempView("batch_pdfs")

        batch_results = spark.sql("""
            WITH raw AS (SELECT filename, ai_parse_document(content) AS p FROM batch_pdfs),
            extracted AS (
                SELECT filename,
                       try_cast(p:error_status AS STRING) AS parse_error,
                       size(try_cast(p:document:pages AS ARRAY<VARIANT>)) AS num_pages,
                       concat_ws('\\n\\n', transform(try_cast(p:document:elements AS ARRAY<VARIANT>), e -> try_cast(e:content AS STRING))) AS full_text
                FROM raw)
            SELECT *, length(full_text) AS text_length FROM extracted
        """).toPandas()

        for _, row in batch_results.iterrows():
            fname = row['filename']
            m = file_registry[fname]
            ai_len = int(row['text_length'] or 0)
            pypdf_len, pypdf_text = _pypdf_partial.get(fname, (0, ''))
            base = {'provider_folder': m['provider_folder'], 'file_size_bytes': m['file_size_bytes'],
                    'ocr_pages_processed': int(row['num_pages'] or 0)}

            if ai_len > pypdf_len:
                # ai_parse_document produced better text
                result = row.to_dict(); result['path'] = m['path']; result.update(base)
                result['extraction_method'] = 'ai_parse_document'
                ai_ok += 1
            elif pypdf_len > 0:
                # pypdf partial text is better (ai_parse failed or returned less)
                result = {'filename': fname, 'path': m['path'],
                    'num_pages': int(ocr_candidates_df[ocr_candidates_df['filename']==fname]['num_pages'].iloc[0]) if fname in ocr_candidates_df['filename'].values else 0,
                    'full_text': pypdf_text, 'text_length': pypdf_len,
                    'parse_error': None, 'extraction_method': 'pypdf_partial', **base}
                ai_fallback += 1
            else:
                # Both empty — keep ai_parse result anyway
                result = row.to_dict(); result['path'] = m['path']; result.update(base)
                result['extraction_method'] = 'ai_parse_document'
                ai_empty += 1
            all_results.append(result)

        print(f"     Tier 2 batch {bi+1}/{num_batches}: {len(batch)} files (ai_ok:{ai_ok} fallback:{ai_fallback} empty:{ai_empty})")

        # Checkpoint after each batch
        if all_results:
            _ckpt_df = pd.DataFrame(all_results)
            _combined = pd.concat([existing_df, _ckpt_df], ignore_index=True).drop_duplicates('filename', keep='last') if existing_df is not None else _ckpt_df
            _combined.to_parquet(STEP1_FILE, index=False)
            print(f"     💾 Checkpoint saved: {len(_combined):,} total files (batch {bi+1}/{num_batches})")

    print(f"     ✅ Tier 2 done: {ai_ok} ai_parse, {ai_fallback} pypdf_fallback, {ai_empty} empty ({time.time()-t_ai:.1f}s)")
else:
    pipe_log.info("No Tier 2 needed — all files passed Tier 1")

# ═══ SAVE FINAL CHECKPOINT ═══
if all_results:
    new_df = pd.DataFrame(all_results)
    combined = pd.concat([existing_df, new_df], ignore_index=True).drop_duplicates('filename', keep='last') if existing_df is not None else new_df
    combined.to_parquet(STEP1_FILE, index=False)
    print(f"\n  ═{'='*78}═")
    print(f"  ✅ STEP 1 COMPLETE: {len(combined):,} files saved to checkpoint")
    for m, c in combined['extraction_method'].value_counts().items():
        print(f"     {m:30s} {c:>6,} ({c/len(combined)*100:.1f}%)")
    print(f"  ═{'='*78}═")
else:
    print("\n  ✅ Step 1: No new files to process (all cached)")
