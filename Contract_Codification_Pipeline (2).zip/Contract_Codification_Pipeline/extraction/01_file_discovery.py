# Databricks notebook source
# DBTITLE 1,File Discovery and Preparation
# MAGIC %md
# MAGIC # 01 — File Discovery & Preparation
# MAGIC **Scans source Volume, prefetches to local SSD, recovers checkpoints, selects files for processing.**
# MAGIC 
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | PDF Volume at `DATA_DIR` | `file_registry` dict (in memory) |
# MAGIC | `checkpoints/file_registry_v2.parquet` | `valid_files` list (new files to process) |
# MAGIC | `checkpoints/step1_parsed_v2.parquet` | `NEW_FILES_FOUND` flag |
# MAGIC 
# MAGIC **Run after:** `_config` (via `%run`)  
# MAGIC **Run before:** `02_ocr_extraction`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,Step-Specific Imports and Config
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: 2-Tier PDF Text Extraction
#   Tier 1: pypdf (free, 14 PROCESSES, 30s internal timeout) — ~82% of files
#   Tier 2: ai_parse_document (paid, handles scanned/complex PDFs) — remaining ~18%
# Output: step1_parsed_v2.parquet (incremental, checkpoint-resumable)
#
# PERF NOTES:
#   - Tier 1 uses ProcessPoolExecutor (NOT threads) because pypdf is pure Python
#     and GIL makes threads 0.9x (slower than sequential). Processes = 5.1x speedup.
#   - pytesseract OCR was removed: too slow (150+ hrs for 1,246 files) and
#     ai_parse_document produces better results on scanned docs anyway.
# ═══════════════════════════════════════════════════════════════════════════════
import os, time, random, math, warnings, logging, shutil
import pandas as pd
import numpy as np
import io
from pyspark.sql.types import StructType, StructField, StringType, BinaryType
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed

print("\n" + "═"*80)
print("  ▶ STEP 1: 2-TIER PDF TEXT EXTRACTION")
print("    Tier 1: pypdf (multiprocess) | Tier 2: ai_parse_document")
print("═"*80)

try:
    from pypdf import PdfReader
    HAS_PYPDF = True
    warnings.filterwarnings('ignore', module='pypdf')
    logging.getLogger('pypdf').setLevel(logging.ERROR)
except ImportError:
    HAS_PYPDF = False
    pipe_log.warning("pypdf not installed — starting from Tier 2")

# ── Step-specific config ──
SAMPLE_MODE      = dbutils.widgets.get("run_mode") == "sample"
NUM_PROVIDERS    = int(dbutils.widgets.get("num_providers") or '5')
PYPDF_WORKERS    = 14      # ProcessPoolExecutor: match CPU cores (GIL-free, true parallelism)
PYPDF_TIMEOUT    = 30      # Internal per-page timeout (enforced inside function)
AI_BATCH_SIZE    = 25
AI_CONCURRENCY   = 20
MIN_GOOD_CHARS   = 500
MIN_CHARS_PER_PAGE = 100
LOCAL_PDF_DIR    = "/local_disk0/tmp/provider_contracts"  # Local NVMe SSD


# ───────────────────────────────────────────────────────────────────────────────
# TOP-LEVEL FUNCTION for ProcessPoolExecutor (must be picklable — no closures)
# ───────────────────────────────────────────────────────────────────────────────

# COMMAND ----------

# DBTITLE 1,File Registry - Discover PDFs in Volume
# ═══ DISCOVERY — recursive scan of Volume ═══
REGISTRY_CACHE = f"{CHECKPOINT_DIR}/file_registry_v2.parquet"
t_disc = time.time()
file_registry = {}

_actual_pdf_count = sum(1 for root, _, files in os.walk(DATA_DIR) for f in files if f.lower().endswith('.pdf'))
_cached_count = 0
if os.path.exists(REGISTRY_CACHE):
    try:
        _cached_count = len(pd.read_parquet(REGISTRY_CACHE, columns=['filename']))
    except Exception:
        _cached_count = -1
_registry_stale = _actual_pdf_count != _cached_count

if os.path.exists(REGISTRY_CACHE) and not _registry_stale:
    _reg_df = pd.read_parquet(REGISTRY_CACHE)
    file_registry = {r['filename']: {'path': r['path'], 'provider_folder': r['provider_folder'],
                      'file_size_bytes': int(r['file_size_bytes'])} for _, r in _reg_df.iterrows()}
    pipe_log.info(f"Discovery: {len(file_registry):,} PDFs from cache (matches actual: {_actual_pdf_count}) ({time.time()-t_disc:.1f}s)")
else:
    _reason = f"new files detected (cached={_cached_count}, actual={_actual_pdf_count})" if _cached_count >= 0 else "no cache or corrupt cache"
    print(f"  🔍 Scanning Volume for PDFs — {_reason}...")
    for root, _, files in os.walk(DATA_DIR):
        for f in files:
            if f.lower().endswith('.pdf'):
                fp = os.path.join(root, f)
                file_registry[f] = {'path': fp, 'provider_folder': os.path.relpath(root, DATA_DIR) if root != DATA_DIR else None,
                                     'file_size_bytes': os.path.getsize(fp)}
    pd.DataFrame([{'filename': k, **v} for k, v in file_registry.items()]).to_parquet(REGISTRY_CACHE, index=False)
    pipe_log.info(f"Discovery: {len(file_registry):,} PDFs scanned ({time.time()-t_disc:.1f}s)")

print(f"  📂 {len(file_registry):,} PDFs discovered")


# COMMAND ----------

# DBTITLE 1,Prefetch PDFs to Local NVMe SSD
# ═══ PREFETCH: Copy PDFs to local NVMe SSD for fast I/O ═══
t_prefetch = time.time()
os.makedirs(LOCAL_PDF_DIR, exist_ok=True)

_local_existing = set()
for root, _, files in os.walk(LOCAL_PDF_DIR):
    for f in files:
        if f.lower().endswith('.pdf'):
            _local_existing.add(f)

_to_copy = [(fname, meta) for fname, meta in file_registry.items() if fname not in _local_existing]
print(f"\n  📥 Prefetch to local SSD: {len(file_registry):,} total, {len(_local_existing):,} already local, {len(_to_copy):,} to copy")

if _to_copy:
    _copy_errors = []
    _copied_count = 0
    _copied_bytes = 0

    def _copy_file(args):
        fname, meta = args
        src = meta['path']
        rel_folder = meta['provider_folder'] or ''
        dst_dir = os.path.join(LOCAL_PDF_DIR, rel_folder)
        dst = os.path.join(dst_dir, fname)
        try:
            os.makedirs(dst_dir, exist_ok=True)
            shutil.copy2(src, dst)
            return ('ok', fname, meta['file_size_bytes'])
        except Exception as e:
            return ('err', fname, str(e))

    with ThreadPoolExecutor(max_workers=32) as ex:
        futures = {ex.submit(_copy_file, item): item[0] for item in _to_copy}
        for fut in as_completed(futures):
            status, fname, info = fut.result()
            if status == 'ok':
                _copied_count += 1
                _copied_bytes += info
            else:
                _copy_errors.append((fname, info))
            if _copied_count % 1000 == 0 and _copied_count > 0:
                print(f"     Copied {_copied_count:,}/{len(_to_copy):,} ({_copied_bytes/1024**3:.1f} GB)")

    prefetch_time = time.time() - t_prefetch
    print(f"  ✅ Prefetch done: {_copied_count:,} files ({_copied_bytes/1024**3:.1f} GB) in {prefetch_time:.0f}s")
    if _copy_errors:
        print(f"  ⚠️  {len(_copy_errors)} copy errors (will use Volume path as fallback)")
else:
    print(f"  ✅ All files already on local SSD (skipped copy)")

# Update file_registry paths to point to local SSD copies
_local_miss = 0
for fname, meta in file_registry.items():
    rel_folder = meta['provider_folder'] or ''
    local_path = os.path.join(LOCAL_PDF_DIR, rel_folder, fname)
    if os.path.exists(local_path):
        meta['path'] = local_path
    else:
        _local_miss += 1

if _local_miss > 0:
    print(f"  ℹ️  {_local_miss} files using Volume fallback (copy failed)")
print(f"  ⚡ All reads now from local NVMe SSD")


# COMMAND ----------

# DBTITLE 1,Checkpoint Recovery - Skip Already Parsed Files
# ═══ CHECKPOINT RECOVERY ═══
already_parsed = set()
existing_df = None
if os.path.exists(STEP1_FILE):
    try:
        existing_df = pd.read_parquet(STEP1_FILE)
        for col, default in [('extraction_method', 'unknown'), ('provider_folder', None),
                              ('file_size_bytes', 0), ('ocr_pages_processed', 0)]:
            if col not in existing_df.columns:
                existing_df[col] = default
        already_parsed = set(existing_df['filename'])
    except Exception:
        os.remove(STEP1_FILE)
        existing_df = None


# COMMAND ----------

# DBTITLE 1,File Selection and Summary
# ═══ FILE SELECTION (provider-folder-based sampling) ═══
all_filenames = sorted(file_registry.keys())
if SAMPLE_MODE:
    from collections import defaultdict
    folder_to_files = defaultdict(list)
    for fname, meta in file_registry.items():
        folder_key = meta['provider_folder'] or '__ROOT__'
        folder_to_files[folder_key].append(fname)
    
    all_folders = sorted(folder_to_files.keys())
    random.seed(42)
    selected_folders = random.sample(all_folders, min(NUM_PROVIDERS, len(all_folders)))
    
    all_filenames = []
    for folder in selected_folders:
        all_filenames.extend(sorted(folder_to_files[folder]))
    
    pipe_log.info(f"Sample mode: selected {len(selected_folders)} provider folders → {len(all_filenames):,} total files")
    for folder in selected_folders:
        pipe_log.info(f"  └ {folder}: {len(folder_to_files[folder])} files")

valid_files = [f for f in all_filenames if f not in already_parsed and file_registry[f]['file_size_bytes'] > 0]
empty_files = [f for f in all_filenames if f not in already_parsed and file_registry[f]['file_size_bytes'] == 0]

NEW_FILES_FOUND = len(valid_files) > 0 or len(empty_files) > 0

mode = f"SAMPLE({NUM_PROVIDERS} providers)" if SAMPLE_MODE else "FULL"
print(f"  📊 Mode: {mode} | Queued: {len(valid_files):,} | Cached: {len(already_parsed):,} | Empty: {len(empty_files)}")
if not NEW_FILES_FOUND:
    print(f"  ℹ️  No new files since last run — downstream steps will rebuild tables from existing JSONs")

