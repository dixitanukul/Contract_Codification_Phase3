# Databricks notebook source
# DBTITLE 1,LLM Prompts Overview
# MAGIC %md
# MAGIC # 04 — LLM Extraction Prompts
# MAGIC **4 document-type-specific prompts for Claude Sonnet 4.5 extraction.**
# MAGIC 
# MAGIC | Prompt | Document Type | Key Sections |
# MAGIC |--------|--------------|--------------|
# MAGIC | `EXTRACTION_PROMPT` | Base Agreements | All sections (rates, terms, parties, services) |
# MAGIC | `AMENDMENT_PROMPT` | Amendments | amendments_impact, supersession tracking |
# MAGIC | `COVER_MEMO_PROMPT` | Cover Memos | exhibits_replaced, summary_of_changes |
# MAGIC | `SETTLEMENT_PROMPT` | Settlements | settlement_amount, parties_involved |
# MAGIC 
# MAGIC **Iterate prompts here** without touching the extraction engine.  
# MAGIC **Run after:** `_config` | **Used by:** `05_llm_extraction`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,Base Agreement Extraction Prompt
EXTRACTION_PROMPT = f'''You are an expert legal contract analyst specializing in healthcare provider agreements. Extract ALL information from this provider contract document into a comprehensive JSON structure. Return ONLY valid JSON — no markdown, no explanation, no code fences.

IMPORTANT FORMATTING RULES:
- ALL date fields: normalize to YYYY-MM-DD format
- Dollar amounts: include exact values with $ prefix (e.g. "$5,748") in the text field AND the raw number in the _numeric field (e.g. 5748.00)
- Percentages: include exact values with % suffix (e.g. "88.9%")
- Revenue codes: extract as comma-separated strings (e.g. "0200-0204, 0274")
- Arrays of codes (ICD, CPT, etc.): extract as comma-separated strings (e.g. "99281-99285")

DELTA-READY REQUIREMENTS (CRITICAL — every rate row MUST include these):
- rate_numeric: The dollar amount as a plain number (no $, no commas). E.g. rate="$5,748" → rate_numeric=5748.00
- effective_date: The date this rate takes effect (YYYY-MM-DD). Use the contract or exhibit effective date if no rate-specific date.
- program: Which program this rate applies to (e.g. "Commercial", "Medicare", "Medi-Cal", "All Programs"). Use "Commercial" if not specified.
- network: Which network tier (e.g. "PPO", "HMO", "Value Network", "All Networks"). Use "All Networks" if not specified.
- exhibit_reference: Which exhibit/section contains this rate (e.g. "Exhibit C, Section I.A(1)", "Exhibit G")

FULL TEXT REQUIREMENT (CRITICAL — for legal clause sections):
For these sections, copy the COMPLETE contract language verbatim into the "full_clause_text" field:
- termination
- compliance_and_regulatory
- grievance_and_appeals
- dispute_resolution
- confidentiality_and_records
- indemnification_insurance
Do NOT summarize. Copy the EXACT text from the document so no one needs to read the original PDF.

The JSON MUST follow this exact schema (populate every field; use null if not found, [] for empty arrays, {{}} for empty objects):

{JSON_SCHEMA}

EXTRACTION INSTRUCTIONS:

1. INPATIENT RATES: Extract ALL per-diem rates (Med/Surg, ICU/CCU, NICU Level I-IV, Psych, Substance Abuse) with their revenue codes. Extract ALL case rates (Maternity Normal/C-Section, Coronary Surgery, PTCA, Cardiac Cath, etc.) with procedure codes, included days, and stop-loss per-diem. Include Other Acute Inpatient rates (Trauma, Rehabilitation, SNF). EVERY rate row must have rate_numeric, effective_date, program, network, exhibit_reference.

2. OUTPATIENT RATES: Extract surgical tier rates (Tiers 1-10 if present). Extract ER/Urgent Care as percentage of charges with cap amounts. Extract infusion therapy per-visit rates. Extract therapy services (PT, OT, Speech, Respiratory) per-visit rates. For Radiology/Pathology, capture the formula components (conversion factor, multiplier) and revenue codes. EVERY rate row must have rate_numeric, effective_date, program, network.

3. REGIONAL FACTORS: If county-level multiplier tables exist, extract ALL counties with their factors and effective_date.

4. EXCEPTION PROVISIONS: Extract implant threshold amounts and reimbursement percentages with revenue codes. Extract exception drug thresholds and percentages. Note relationship to stop-loss calculations. Include threshold_numeric.

5. CAPITATION: If capitated, extract rates by aid category (Aged, Disabled, Aged Dual, Disabled Dual, Family/Child, Family/Adult, MCE, BCCTP). For multi-year contracts, capture each year\'s rates with _numeric values. Capture supplemental payments with amount_numeric.

6. HAC/NEVER EVENTS: Extract the full list of Hospital Acquired Conditions with ICD codes (as comma-separated string) and adjustment rules. Extract Never Events with codes. Capture the dispute/IMR process.

7. CHARGEMASTER: Extract notification days, amendment requirements, FCR language (Yes/No), lesser-of language (Yes/No), Medicare lesser-of, COB language, Other Payor Surcharge, Midnight Rule.

8. STOP-LOSS: Extract per-diem attachment levels (with _numeric), stop-loss per-diem rates (with _numeric), case rate stop-loss coverage details.

9. AMENDMENTS_IMPACT: For base agreements, set prior_rates_superseded=false and leave other fields empty.

10. SETTLEMENT_TERMS: Leave ALL settlement_terms fields as empty strings/null.
    Base agreements are NOT settlement documents. Standard dispute resolution
    language, arbitration timeframes (e.g. "24 months"), and claims appeal
    procedures belong in the `dispute_resolution` section, NOT settlement_terms.
    ONLY populate settlement_terms if this document contains an ACTUAL monetary
    settlement — a specific dollar amount being paid to resolve a named legal
    dispute (e.g. "$31,000,000 to resolve AAA Case No. 12345").

CRITICAL DATE RULE: Extract ONLY dates explicitly written in the document. Do NOT calculate or infer dates from renewal language or term lengths. If not literally stated, set to null.
CRITICAL PROVIDER NAME RULE: Extract ONLY the entity name as written in the contract text. Do NOT substitute parent company names.
CRITICAL PAYMENT TYPE RULE: Extract ONLY if explicitly stated in THIS document.

DOCUMENT TEXT:
'''

# --- PROMPT 2: AMENDMENT ---

# COMMAND ----------

# DBTITLE 1,Amendment Extraction Prompt
AMENDMENT_PROMPT = f'''You are an expert legal contract analyst specializing in healthcare provider agreements. Extract ALL information from this provider contract AMENDMENT into a comprehensive JSON structure. Return ONLY valid JSON — no markdown, no explanation, no code fences.

IMPORTANT FORMATTING RULES:
- ALL date fields: normalize to YYYY-MM-DD format
- Dollar amounts: include exact values with $ prefix AND raw number in _numeric fields
- Percentages: include exact values with % suffix
- Revenue codes: extract as comma-separated strings
- Arrays of codes (ICD, CPT): extract as comma-separated strings

DELTA-READY REQUIREMENTS (CRITICAL — every rate row MUST include these):
- rate_numeric: The dollar amount as a plain number (no $, no commas)
- effective_date: The date this rate takes effect (YYYY-MM-DD). Use the amendment effective date if no rate-specific date.
- program: Which program ("Commercial", "Medicare", "Medi-Cal", "All Programs")
- network: Which network tier ("PPO", "HMO", "Value Network", "All Networks")
- exhibit_reference: Which exhibit/section (e.g. "Exhibit C, Section I.A(1)")

FULL TEXT REQUIREMENT: For termination, compliance_and_regulatory, grievance_and_appeals, dispute_resolution, confidentiality_and_records, indemnification_insurance — copy the COMPLETE contract language verbatim into "full_clause_text". Do NOT summarize.

Extract ALL content present in this amendment. Amendments frequently modify rates, effective dates, fee schedules, and service terms.

The JSON MUST follow this exact schema (populate every field found; use null only if genuinely absent):

{JSON_SCHEMA}

AMENDMENT-SPECIFIC INSTRUCTIONS:

1. AMENDMENTS_IMPACT (CRITICAL — this section tells downstream systems what this amendment changes):
   - exhibits_replaced: List ALL exhibit letters/numbers being replaced (e.g. ["Exhibit C", "Exhibit G"])
   - exhibits_added: List any NEW exhibits added
   - sections_modified: List specific section numbers modified (e.g. ["5.2(a)", "5.5(d)", "6.2(a)"])
   - prior_rates_superseded: true if this amendment replaces ANY rates from the base agreement or prior amendments
   - supersedes_effective_date: The effective date of the rates/terms being REPLACED (the old date being superseded)
   - summary_of_changes: One paragraph describing what this amendment does

2. CAPITATION TABLE: Amendments often replace capitation exhibits. Extract ALL aid categories with rates (include rate_numeric). If multi-year escalation tables are present, capture Year 1-4 rates with _numeric values and effective dates. Capture supplemental payments.

3. RATE CHANGES: Extract ALL modified inpatient and outpatient rates. Include rate_numeric, effective_date, program, network, exhibit_reference on EVERY row.

4. FINANCIAL TERMS: Pay special attention to payment_type, capitation_details, withhold %, and any risk_sharing changes.

5. EFFECTIVE DATES: Amendments have their own effective date — capture it in contract_overview.effective_date.

6. EXHIBIT REPLACEMENTS: Note which exhibits are deleted/replaced in amendments_and_attachments AND in amendments_impact.exhibits_replaced.

7. SETTLEMENT_TERMS: Leave ALL settlement_terms fields as empty strings/null.
   Claims reconciliation language, chargemaster modification notices, and
   arbitration clause updates are NOT settlements. Put dispute-related language
   in `dispute_resolution`. ONLY populate settlement_terms if this amendment
   contains an ACTUAL monetary settlement with a specific dollar amount paid
   to resolve a named legal dispute.

CRITICAL DATE RULE: Extract ONLY dates explicitly written in the document. Do NOT calculate or infer.
CRITICAL PROVIDER NAME RULE: Extract ONLY the entity name as written in the contract text.
CRITICAL PAYMENT TYPE RULE: Extract ONLY if explicitly stated in THIS document.

AMENDMENT TEXT:
'''

# --- PROMPT 3: COVER MEMO ---

# COMMAND ----------

# DBTITLE 1,Cover Memo Extraction Prompt
COVER_MEMO_PROMPT = f'''You are an expert legal contract analyst specializing in healthcare provider agreements. Extract ALL information from this contract COVER MEMO / ROUTING MEMORANDUM into a comprehensive JSON structure. Return ONLY valid JSON — no markdown, no explanation, no code fences.

Cover memos are internal routing documents that summarize contract amendments. They contain critical metadata about rate changes, exhibit versions, and contract configuration.

IMPORTANT FORMATTING RULES:
- ALL date fields: normalize to YYYY-MM-DD format
- Dollar amounts: include exact values with $ prefix AND raw number in _numeric fields
- Percentages: include exact values with % suffix

DELTA-READY REQUIREMENTS: Every rate row must include rate_numeric, effective_date, program, network, exhibit_reference where applicable.

The JSON MUST follow this exact schema (populate every field found; use null only if genuinely absent):

{JSON_SCHEMA}

COVER MEMO-SPECIFIC INSTRUCTIONS:

1. COVER_MEMO_METADATA is the most important section for this document type. Extract:
   - Rate percent increases (Yr 1, Yr 2, Yr 3 — often in table format)
   - Model contract version (e.g. "2008", "2012")
   - Rate/DOFR exhibit version numbers
   - Retro Hold Language (Yes/No)
   - Next Renewal Date
   - Liability Start Date
   - Provider Dispute Resolution timeframes (initial days, final days)

2. CHARGEMASTER_PROVISIONS: Extract:
   - Whether signed amendment required for chargemaster changes
   - Midnight Rule applicability (Yes/No)
   - Other Payor Surcharge (Yes/No)
   - FCR Language, Lesser-of Language, Medicare Lesser-of, COB Language

3. CONTRACT_OVERVIEW: Extract the contract effective date, amendment number, hospital name.

4. PARTIES: Extract provider name, PIN numbers if listed.

5. AMENDMENTS_IMPACT: Record which exhibits are referenced or replaced.

CRITICAL: Cover memos may have sparse content in most fields — that is expected. Focus on cover_memo_metadata and chargemaster_provisions which are unique to this document type.

COVER MEMO TEXT:
'''

# --- PROMPT 4: SETTLEMENT ---

# COMMAND ----------

# DBTITLE 1,Settlement Extraction Prompt
SETTLEMENT_PROMPT = f'''You are an expert legal contract analyst specializing in healthcare provider agreements. Extract ALL information from this SETTLEMENT AGREEMENT AND RELEASE into a comprehensive JSON structure. Return ONLY valid JSON — no markdown, no explanation, no code fences.

IMPORTANT FORMATTING RULES:
- ALL date fields: normalize to YYYY-MM-DD format
- Dollar amounts: include exact values with $ prefix AND raw number in _numeric fields (settlement_amount_numeric)

FULL TEXT REQUIREMENT: For termination, compliance_and_regulatory, dispute_resolution, confidentiality_and_records, indemnification_insurance — copy the COMPLETE contract language verbatim into "full_clause_text". Settlement agreements have critical confidentiality and release language that must be preserved word-for-word.

The JSON MUST follow this exact schema (populate every field found; use null only if genuinely absent):

{JSON_SCHEMA}

SETTLEMENT-SPECIFIC INSTRUCTIONS:

1. SETTLEMENT_TERMS is the most important section. Extract:
   - settlement_amount: The exact dollar amount (e.g. "$31,000,000.00")
   - settlement_amount_numeric: The raw number (e.g. 31000000.00)
   - arbitration_references: All AAA, AHLA, or other arbitration case numbers (comma-separated string)
   - release_scope: What claims/disputes are being released (FULL TEXT of release clause)
   - payment_timeline: When payment is due (e.g. "within 1 business day of execution")
   - exhibits_referenced: List all exhibits and what they contain (comma-separated string)
   - dispute_background: Detailed summary of what the dispute was about

2. PARTIES: Extract both sides — typically the provider/hospital system and Blue Shield entities.

3. CONTRACT_OVERVIEW: Capture execution date, effective date of the settlement.

4. CONFIDENTIALITY: Settlement agreements have confidentiality clauses — capture FULL TEXT in confidentiality_and_records.full_clause_text.

5. AMENDMENTS_IMPACT: Set prior_rates_superseded=false for settlements.

CRITICAL: Most rate/service fields will be null for settlements — that is expected. Focus on settlement_terms, parties, confidentiality, and contract_overview.

SETTLEMENT TEXT:
'''

# ── Pre-escape ALL prompts for SQL embedding ──
EXTRACT_ESC = EXTRACTION_PROMPT.replace("'", "''")
AMEND_ESC = AMENDMENT_PROMPT.replace("'", "''")
COVER_MEMO_ESC = COVER_MEMO_PROMPT.replace("'", "''")
SETTLEMENT_ESC = SETTLEMENT_PROMPT.replace("'", "''")


# COMMAND ----------

# DBTITLE 1,Prompt Router - Select by Document Type
# ══════════════════════════════════════════════════════════════════════════════
# DOCUMENT TYPE ROUTING LOGIC
# ══════════════════════════════════════════════════════════════════════════════
def _get_prompt_category(doc_type):
    """Route document type to the appropriate prompt category."""
    dt = (doc_type or '').lower()
    if 'settlement' in dt:
        return 'settlement'
    elif dt.endswith('cm') or 'covermemo' in dt:
        return 'cover_memo'
    elif 'amend' in dt or 'lra' in dt or 'addendum' in dt:
        return 'amendment'
    else:
        return 'base'

# ── Shared extraction helper with TIMEOUT and 4-way prompt routing ──

# ═══════════════════════════════════════════════════════════════════════════════
# DIRECT REST API EXTRACTION (Replaces Spark SQL ai_query for reliability)
# ═══════════════════════════════════════════════════════════════════════════════
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeout

# REST API setup
_TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
_WORKSPACE_URL = spark.conf.get("spark.databricks.workspaceUrl")
_ENDPOINT_URL = f"https://{_WORKSPACE_URL}/serving-endpoints/{LLM_MODEL}/invocations"
_HEADERS = {"Authorization": f"Bearer {_TOKEN}", "Content-Type": "application/json"}


def _get_prompt_for_doc(doc_type):
    """Return the appropriate prompt string based on document type."""
    category = _get_prompt_category(doc_type)
    if category == 'settlement':
        return SETTLEMENT_PROMPT
    elif category == 'cover_memo':
        return COVER_MEMO_PROMPT
    elif category == 'amendment':
        return AMENDMENT_PROMPT
    else:
        return EXTRACTION_PROMPT
