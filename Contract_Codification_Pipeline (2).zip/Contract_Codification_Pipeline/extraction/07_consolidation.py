# Databricks notebook source
# DBTITLE 1,Consolidation Overview
# MAGIC %md
# MAGIC # 07 — Contract-Level Consolidation
# MAGIC **Merges per-file JSONs into per-provider consolidated records with amendment chain ordering.**
# MAGIC 
# MAGIC | Logic | Description |
# MAGIC |-------|-------------|
# MAGIC | Version dedup | Keep highest version per provider/contract/doctype/date |
# MAGIC | Amendment ordering | Sort by effective_date + version within each provider |
# MAGIC | Rate supersession | Track which amendments supersede earlier rates |
# MAGIC | Doc role classification | base_agreement, amendment, cover_memo, settlement |
# MAGIC 
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `json_extract/*.json` | `json_consolidated/*.json` (one per provider) |
# MAGIC 
# MAGIC **Run after:** `06_validation`  
# MAGIC **Run before:** `08_build_rates`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,Consolidation Functions and Main Loop
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: Contract-Level Consolidation
#   Merges individual file extractions into per-PROVIDER consolidated records.
#   Logic:
#     1. De-duplicate extraction versions (keep highest version per effective_date)
#     2. Build amendment chains per provider (Base → Amend1 → Amend2 → ... → Current)
#     3. Determine current vs. superseded rates
#     4. Build contract timeline with status tracking
#   Input:  json_extract/*.json (133 individual files)
#   Output: json_consolidated/<provider_id>.json (5 provider-level records)
#   Zero LLM cost — pure Python logic.
# ═══════════════════════════════════════════════════════════════════════════════
import os, json, re, time
from datetime import datetime
from collections import defaultdict
import pandas as pd

print("\n" + "═"*80)
print("  ▶ STEP 6: CONTRACT-LEVEL CONSOLIDATION")
print("    De-duplicate versions | Build amendment chains | Determine current rates")
print("═"*80)

CONSOLIDATED_DIR = f"{BASE_DIR}/json_consolidated"
os.makedirs(CONSOLIDATED_DIR, exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 1: Load all file extractions and metadata
# ═══════════════════════════════════════════════════════════════════════════════
json_files = sorted([f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')])
print(f"  📄 Loading {len(json_files)} file extractions...")

all_docs = []
for jf in json_files:
    with open(os.path.join(OUTPUT_DIR, jf)) as f:
        doc = json.load(f)
    all_docs.append(doc)

print(f"  ✅ {len(all_docs)} documents loaded")

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 2: De-duplicate extraction versions
#   Same (provider_id, contract_id, doc_type, effective_date) with different
#   versions → keep highest version (latest extraction iteration)
# ═══════════════════════════════════════════════════════════════════════════════
def parse_version(v):
    """Extract numeric version from 'v1', 'v2', etc."""
    if not v:
        return 0
    m = re.search(r'(\d+)', str(v))
    return int(m.group(1)) if m else 0

def parse_date_flexible(date_str):
    """Parse dates in multiple formats to comparable datetime."""
    if not date_str or date_str in ('None', 'null', 'N/A', ''):
        return None
    for fmt in ('%Y-%m-%d', '%m/%d/%Y', '%B %d, %Y', '%b %d, %Y', '%m/%d/%y'):
        try:
            return datetime.strptime(str(date_str).strip(), fmt)
        except (ValueError, TypeError):
            continue
    # Try ISO-like
    m = re.match(r'(\d{4})-(\d{1,2})-(\d{1,2})', str(date_str))
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            pass
    return None

# Group by dedup key
dedup_groups = defaultdict(list)
for doc in all_docs:
    fm = doc.get('file_metadata', {})
    co = (doc.get('extracted_content') or {}).get('contract_overview', {}) or {}
    key = (
        fm.get('provider_id', ''),
        fm.get('contract_id', ''),
        fm.get('document_type', ''),
        co.get('effective_date', '')
    )
    dedup_groups[key].append(doc)

# Keep highest version per group
deduped_docs = []
dups_removed = 0
for key, docs in dedup_groups.items():
    if len(docs) == 1:
        deduped_docs.append(docs[0])
    else:
        # Sort by version number descending, take highest
        docs_sorted = sorted(docs, key=lambda d: parse_version(d.get('file_metadata', {}).get('version', '')), reverse=True)
        deduped_docs.append(docs_sorted[0])
        dups_removed += len(docs) - 1

print(f"\n  Phase 2: De-duplication")
print(f"    Input: {len(all_docs)} files")
print(f"    Duplicates removed: {dups_removed}")
print(f"    Unique documents: {len(deduped_docs)}")

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 3: Group by provider and build amendment chains
# ═══════════════════════════════════════════════════════════════════════════════
def get_amendment_order(doc_type):
    """Extract numeric amendment order from document_type name."""
    dt = (doc_type or '').lower()
    # Base agreements are order 0
    if 'baseagmt' in dt:
        return 0
    # Map ordinal names to numbers
    ordinals = {
        'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5,
        'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10,
        'eleventh': 11, 'twelfth': 12, 'thirteenth': 13, 'fourteenth': 14,
        'fifteenth': 15, 'sixteenth': 16, 'seventeenth': 17, 'eighteenth': 18,
        'nineteenth': 19, 'twentieth': 20
    }
    for word, num in ordinals.items():
        if word in dt:
            return num
    # Settlements, LOAs, etc. — put at end
    if 'settlement' in dt:
        return 900
    if 'letter' in dt or 'mutual' in dt:
        return 800
    return 500

def classify_doc_role(doc_type):
    """Classify document role in the contract lifecycle."""
    dt = (doc_type or '').lower()
    if 'baseagmt' in dt:
        return 'base_agreement'
    if 'amend' in dt or 'lra' in dt or 'addendum' in dt:
        if dt.endswith('cm'):
            return 'cover_memo'
        return 'amendment'
    if 'settlement' in dt:
        return 'settlement'
    if 'letter' in dt:
        return 'letter_of_agreement'
    if 'mutual' in dt:
        return 'mutual_agreement'
    return 'other'

# Group by provider
provider_groups = defaultdict(list)
for doc in deduped_docs:
    pid = doc.get('file_metadata', {}).get('provider_id', 'unknown')
    provider_groups[pid].append(doc)

print(f"\n  Phase 3: Provider grouping")
print(f"    Providers: {len(provider_groups)}")
for pid, docs in sorted(provider_groups.items()):
    pname = docs[0].get('file_metadata', {}).get('provider_name', 'Unknown')
    print(f"      {pid} ({pname}): {len(docs)} documents")

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 4: Build consolidated provider records
# ═══════════════════════════════════════════════════════════════════════════════
def extract_rates_summary(ec):
    """Extract all rates from extracted_content into a flat list with metadata."""
    rates = []
    ip = ec.get('inpatient_rates', {}) or {}
    for r in (ip.get('per_diem_rates') or []):
        if isinstance(r, dict) and r.get('rate'):
            rates.append({
                'rate_type': 'inpatient_per_diem',
                'service_category': r.get('service_category', ''),
                'rate': r.get('rate'),
                'rate_numeric': r.get('rate_numeric'),
                'program': r.get('program', ''),
                'network': r.get('network', ''),
            })
    for r in (ip.get('case_rates') or []):
        if isinstance(r, dict) and r.get('case_rate'):
            rates.append({
                'rate_type': 'inpatient_case_rate',
                'service_category': r.get('procedure', r.get('category', '')),
                'rate': r.get('case_rate'),
                'rate_numeric': r.get('rate_numeric'),
                'program': r.get('program', ''),
                'network': r.get('network', ''),
            })
    op = ec.get('outpatient_rates', {}) or {}
    for r in (op.get('surgical_tiers') or []):
        if isinstance(r, dict) and r.get('base_rate'):
            rates.append({
                'rate_type': 'outpatient_surgical',
                'service_category': r.get('tier_name', r.get('tier', '')),
                'rate': r.get('base_rate'),
                'rate_numeric': r.get('rate_numeric'),
                'program': r.get('program', ''),
                'network': r.get('network', ''),
            })
    cap = ec.get('capitation_table', {}) or {}
    for r in (cap.get('rates_by_category') or []):
        if isinstance(r, dict) and r.get('rate'):
            rates.append({
                'rate_type': 'capitation',
                'service_category': r.get('aid_category', ''),
                'rate': r.get('rate'),
                'rate_numeric': r.get('rate_numeric'),
                'program': r.get('program', ''),
                'network': r.get('network', ''),
            })
    return rates

def build_provider_consolidation(provider_id, docs):
    """Build consolidated record for a single provider."""
    # Sort documents by amendment order, then effective_date
    doc_entries = []
    for doc in docs:
        fm = doc.get('file_metadata', {})
        ec = doc.get('extracted_content') or {}
        co = ec.get('contract_overview', {}) or {}
        val = doc.get('validation', {}) or {}
        ai = ec.get('amendments_impact', {}) or {}
        
        eff_date = parse_date_flexible(co.get('effective_date'))
        doc_type = fm.get('document_type', '')
        
        doc_entries.append({
            'filename': fm.get('source_filename', ''),
            'contract_id': fm.get('contract_id', ''),
            'document_type': doc_type,
            'doc_role': classify_doc_role(doc_type),
            'amendment_order': get_amendment_order(doc_type),
            'effective_date': co.get('effective_date'),
            'effective_date_parsed': eff_date,
            'expiration_date': co.get('expiration_date'),
            'agreement_title': co.get('agreement_title'),
            'content_bucket': val.get('content_bucket'),
            'document_subtype': val.get('document_subtype'),
            'v6_coverage_pct': val.get('v6_coverage_pct', 0),
            'rates': extract_rates_summary(ec),
            'rate_count': len(extract_rates_summary(ec)),
            'amendments_impact': ai if ai else None,
            'has_full_clause_text': any(
                (ec.get(s, {}) or {}).get('full_clause_text')
                for s in ('termination', 'compliance_and_regulatory', 'dispute_resolution',
                          'confidentiality_and_records', 'indemnification_insurance')
            ),
            'extracted_content_ref': fm.get('source_filename', '').replace('.pdf', '.json'),
        })
    
    # Sort: base agreements first, then amendments by order, then by effective_date
    doc_entries.sort(key=lambda d: (
        0 if d['doc_role'] == 'base_agreement' else 1 if d['doc_role'] in ('amendment', 'cover_memo') else 2,
        d['amendment_order'],
        d['effective_date_parsed'] or datetime(1900, 1, 1)
    ))
    
    # Determine contract status
    latest_doc = max(doc_entries, key=lambda d: d['effective_date_parsed'] or datetime(1900, 1, 1))
    exp_date = parse_date_flexible(latest_doc.get('expiration_date'))
    is_active = exp_date is None or exp_date > datetime.now() if exp_date else True
    
    # Build rate timeline: track which rates are current vs. superseded
    rate_timeline = []
    current_rates = {}  # key: (rate_type, service_category, program, network) → latest rate
    
    for entry in doc_entries:
        eff = entry['effective_date']
        for rate in entry['rates']:
            rate_key = (rate['rate_type'], rate['service_category'], rate['program'], rate['network'])
            rate_record = {
                **rate,
                'effective_date': eff,
                'source_document': entry['filename'],
                'source_doc_type': entry['document_type'],
                'amendment_order': entry['amendment_order'],
            }
            
            if rate_key in current_rates:
                # Mark previous as superseded
                current_rates[rate_key]['status'] = 'superseded'
                current_rates[rate_key]['superseded_by'] = entry['filename']
                current_rates[rate_key]['superseded_date'] = eff
            
            rate_record['status'] = 'current'
            rate_record['superseded_by'] = None
            rate_record['superseded_date'] = None
            current_rates[rate_key] = rate_record
            rate_timeline.append(rate_record)
    
    # Build output
    provider_name = docs[0].get('file_metadata', {}).get('provider_name', 'Unknown')
    
    # Clean doc_entries for JSON serialization (remove parsed datetime)
    for entry in doc_entries:
        entry.pop('effective_date_parsed', None)
        entry.pop('rates', None)  # rates are in rate_timeline now
    
    consolidated = {
        'provider_id': provider_id,
        'provider_name': provider_name,
        'consolidation_metadata': {
            'consolidated_at': datetime.now().isoformat(),
            'total_source_documents': len(doc_entries),
            'base_agreements': sum(1 for d in doc_entries if d['doc_role'] == 'base_agreement'),
            'amendments': sum(1 for d in doc_entries if d['doc_role'] in ('amendment', 'cover_memo')),
            'other_documents': sum(1 for d in doc_entries if d['doc_role'] not in ('base_agreement', 'amendment', 'cover_memo')),
            'total_rates_extracted': len(rate_timeline),
            'current_rates_count': sum(1 for r in rate_timeline if r['status'] == 'current'),
            'superseded_rates_count': sum(1 for r in rate_timeline if r['status'] == 'superseded'),
        },
        'contract_status': {
            'is_active': is_active,
            'latest_effective_date': latest_doc['effective_date'],
            'latest_expiration_date': latest_doc.get('expiration_date'),
            'latest_document': latest_doc['filename'],
            'latest_amendment_order': latest_doc['amendment_order'],
        },
        'document_timeline': doc_entries,
        'rate_timeline': rate_timeline,
        'current_rates': [r for r in rate_timeline if r['status'] == 'current'],
        'superseded_rates': [r for r in rate_timeline if r['status'] == 'superseded'],
    }
    
    return consolidated

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 5: Execute consolidation and write output
# ═══════════════════════════════════════════════════════════════════════════════
t0 = time.time()
results = []

for provider_id, docs in sorted(provider_groups.items()):
    consolidated = build_provider_consolidation(provider_id, docs)
    results.append(consolidated)
    
    # Write to file
    out_path = os.path.join(CONSOLIDATED_DIR, f"{provider_id}.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(consolidated, f, indent=2, ensure_ascii=False, default=str)

elapsed = time.time() - t0

# ═══════════════════════════════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════════════════════════════
print(f"\n{'═'*80}")
print(f"✅ Step 6 complete in {elapsed:.1f}s")
print(f"   {len(results)} provider records consolidated")
print(f"   Output: {CONSOLIDATED_DIR}/")
print(f"{'═'*80}")

print(f"\n  {'Provider':<40s} {'Docs':>5s} {'Base':>5s} {'Amend':>6s} {'Rates':>7s} {'Current':>8s} {'Superseded':>10s}")
print(f"  {'─'*85}")
total_rates = total_current = total_superseded = 0
for r in results:
    cm = r['consolidation_metadata']
    print(f"  {r['provider_name']:<40s} {cm['total_source_documents']:>5d} {cm['base_agreements']:>5d} {cm['amendments']:>6d} {cm['total_rates_extracted']:>7d} {cm['current_rates_count']:>8d} {cm['superseded_rates_count']:>10d}")
    total_rates += cm['total_rates_extracted']
    total_current += cm['current_rates_count']
    total_superseded += cm['superseded_rates_count']

print(f"  {'─'*85}")
print(f"  {'TOTAL':<40s} {sum(r['consolidation_metadata']['total_source_documents'] for r in results):>5d} {'':>5s} {'':>6s} {total_rates:>7d} {total_current:>8d} {total_superseded:>10d}")
print(f"\n  Rate supersession: {total_superseded} rates superseded by amendments → {total_current} currently active")
print(f"  Supersession rate: {total_superseded/(total_rates or 1)*100:.1f}% of all extracted rates are historical")

# Display consolidated dataframe
stats = [{'provider_id': r['provider_id'], 'provider_name': r['provider_name'],
          'documents': r['consolidation_metadata']['total_source_documents'],
          'base_agreements': r['consolidation_metadata']['base_agreements'],
          'amendments': r['consolidation_metadata']['amendments'],
          'total_rates': r['consolidation_metadata']['total_rates_extracted'],
          'current_rates': r['consolidation_metadata']['current_rates_count'],
          'superseded_rates': r['consolidation_metadata']['superseded_rates_count'],
          'is_active': r['contract_status']['is_active'],
          'latest_effective': r['contract_status']['latest_effective_date']}
         for r in results]
cdf = pd.DataFrame(stats)
display(cdf)
