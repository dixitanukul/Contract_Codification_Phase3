# Databricks notebook source
# DBTITLE 1,Build Documents Overview
# MAGIC %md
# MAGIC # 10 — Build Base Layer: Documents Master + Identity Resolution
# MAGIC **Builds the 74-column document spine and resolves provider identity (456 IDs → 278 facilities).**
# MAGIC 
# MAGIC | Table | Description |
# MAGIC |-------|-------------|
# MAGIC | `tbl_contract_documents_master` | 74 columns: metadata, coverage scores, text stats, doc classification |
# MAGIC | `dim_provider_canonical` | Identity resolution dimension (many-to-one mapping) |
# MAGIC 
# MAGIC **Identity resolution logic:**
# MAGIC * Normalize provider names (strip legal suffixes, whitespace, case)
# MAGIC * Group IDs that share the same normalized name
# MAGIC * Assign primary_provider_id (most contracts wins)
# MAGIC * Result: 456 provider_ids → 278 canonical facilities
# MAGIC 
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `json_extract/*.json`, `json_consolidated/*.json` | 2 Delta tables in `dev_adb.raw` |
# MAGIC 
# MAGIC **Run after:** `09_build_terms`  
# MAGIC **Run before:** `11_enrich_tables`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,Build Documents Master Table
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11c: BUILD BASE LAYER FROM JSON — Documents Master
#   Reads from json_extract/ and json_consolidated/ — ZERO source table dependency.
#   Builds tbl_contract_documents_master (1 row per source PDF)
#   Parses: file_metadata, contract_overview, financial_terms, operational,
#           amendments_impact, settlements, cover_memo, chargemaster
# ═══════════════════════════════════════════════════════════════════════════════
import time

print("\n" + "═"*80)
print("  ▶ STEP 11c: BASE LAYER FROM JSON — Documents Master")
print("    No source table dependencies. Reads JSON directly.")
print("═"*80)

t0 = time.time()

# Build amendment_order lookup from consolidated JSONs
amend_order_map = {}  # source_filename -> amendment_order
for p in providers_data:
    for doc in p.get('document_timeline', []):
        fn = doc.get('filename', '')
        amend_order_map[fn] = doc.get('amendment_order', 0)

print(f"  Amendment order mapped for {len(amend_order_map)} documents")

# Build documents_master from individual JSONs
rows_dm = []
for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    co = ec.get('contract_overview', {}) or {}
    ft = ec.get('financial_terms', {}) or {}
    op = ec.get('operational_provisions', ec.get('operational', {})) or {}
    ai = ec.get('amendments_impact', {}) or {}
    st = ec.get('settlements', ec.get('settlement', {})) or {}
    cm = ec.get('chargemaster_provisions', {}) or {}
    cmr = ec.get('cover_memo_rate_escalators', ec.get('cover_memo', {})) or {}

    src_fn = fm.get('source_filename', jf.replace('.json', '.pdf'))

    # Handle delegated_activities (can be list or string)
    da = op.get('delegated_activities', '')
    if isinstance(da, list):
        da_str = json.dumps(da)
    else:
        da_str = safe_str(da, 2000)

    # Handle exhibits_replaced_list (can be list or string)
    erl = ai.get('exhibits_replaced_list', ai.get('exhibits_list', ''))
    if isinstance(erl, list):
        erl_str = json.dumps(erl)
    else:
        erl_str = safe_str(erl, 2000)

    row = {
        # --- file_metadata / documents ---
        'provider_id': fm.get('provider_id'),
        'provider_name': fm.get('provider_name'),
        'source_filename': src_fn,
        'contract_id': fm.get('contract_id'),
        'document_type': fm.get('document_type'),
        'doc_role': fm.get('doc_role', fm.get('document_role')),
        'amendment_order': amend_order_map.get(src_fn, 0),
        'effective_date': co.get('effective_date'),
        'expiration_date': co.get('expiration_date'),
        'agreement_title': safe_str(co.get('agreement_title'), 500),
        'content_bucket': fm.get('content_bucket'),
        'document_subtype': fm.get('document_subtype'),
        'v6_coverage_pct': fm.get('v6_coverage_pct', doc.get('validation', {}).get('v6_coverage_pct', 0)),
        'rate_count': fm.get('rate_count', 0),
        'has_full_clause_text': fm.get('has_full_clause_text', False),

        # --- contract_overview ---
        'agreement_type': safe_str(co.get('agreement_type'), 200),
        'payment_type': safe_str(ft.get('payment_type') or co.get('payment_type') or co.get('reimbursement_methodology'), 200),
        'auto_renewal': co.get('auto_renewal'),
        'contract_term_years': safe_str(co.get('contract_term_years', co.get('term_years'))),
        'service_area': safe_str(co.get('service_area', co.get('geographic_area')), 500),
        'hospital_type': safe_str(co.get('hospital_type', co.get('facility_type'))),
        'network_participation': safe_str(co.get('network_participation', co.get('network')), 200),
        'lines_of_business': safe_str(co.get('lines_of_business'), 500),
        'prior_agreement_reference': safe_str(co.get('prior_agreement_reference'), 500),

        # --- financial_terms ---
        'withhold_percentage': safe_str(ft.get('withhold_percentage', ft.get('withhold'))),
        'risk_sharing': safe_str(ft.get('risk_sharing', ft.get('risk_sharing_arrangement')), 1000),
        'incentive_programs': safe_str(ft.get('incentive_programs', ft.get('performance_incentives')), 1000),
        'payment_terms_days': ft.get('payment_terms_days', ft.get('payment_timing')),
        'interest_on_late_payment': safe_str(ft.get('interest_on_late_payment'), 200),
        'billing_timely_filing_days': ft.get('billing_timely_filing_days', ft.get('timely_filing')),
        'clean_claim_days': ft.get('clean_claim_days'),
        'rate_increase_cap': safe_str(ft.get('rate_increase_cap'), 200),

        # --- operational ---
        'delegated_activities': da_str,
        'edi_requirements': safe_str(op.get('edi_requirements', op.get('edi')), 1000),
        'behavioral_health_provisions': safe_str(op.get('behavioral_health_provisions', op.get('behavioral_health')), 1000),
        'credentialing_requirements': safe_str(op.get('credentialing_requirements', op.get('credentialing')), 1000),
        'medical_record_requirements': safe_str(op.get('medical_record_requirements', op.get('medical_records')), 1000),
        'quality_reporting': safe_str(op.get('quality_reporting', op.get('reporting_requirements')), 1000),
        'coordination_of_benefits': safe_str(op.get('coordination_of_benefits', op.get('cob')), 1000),
        'emergency_services': safe_str(op.get('emergency_services'), 500),
        'utilization_review': safe_str(op.get('utilization_review', op.get('utilization_management')), 1000),
        'claims_submission_address': safe_str(op.get('claims_submission_address'), 500),

        # --- amendments_impact ---
        'exhibits_replaced_count': ai.get('exhibits_replaced_count', ai.get('exhibits_replaced')),
        'exhibits_added_count': ai.get('exhibits_added_count', ai.get('exhibits_added')),
        'sections_modified_count': ai.get('sections_modified_count', ai.get('sections_modified')),
        'prior_rates_superseded': ai.get('prior_rates_superseded'),
        'supersedes_effective_date': ai.get('supersedes_effective_date'),
        'summary_of_changes': safe_str(ai.get('summary_of_changes', ai.get('change_summary')), 2000),
        'exhibits_replaced_list': erl_str,

        # --- settlements ---
        'settlement_amount_numeric': safe_float(st.get('settlement_amount_numeric', st.get('amount_numeric', st.get('settlement_amount')))),
        'settlement_amount_text': safe_str(st.get('settlement_amount_text', st.get('amount_text')), 200),
        'settlement_type': safe_str(st.get('settlement_type', st.get('type'))),
        'arbitration_outcome': safe_str(st.get('arbitration_outcome'), 500),
        'release_scope': safe_str(st.get('release_scope'), 1000),
        'settlement_effective_date': st.get('settlement_effective_date', st.get('effective_date')),

        # --- cover_memo rate escalators ---
        'rate_percent_increase_yr1': safe_str(cmr.get('rate_percent_increase_yr1', cmr.get('year1_increase'))),
        'rate_percent_increase_yr2': safe_str(cmr.get('rate_percent_increase_yr2', cmr.get('year2_increase'))),
        'rate_percent_increase_yr3': safe_str(cmr.get('rate_percent_increase_yr3', cmr.get('year3_increase'))),
        'model_contract_version': safe_str(cmr.get('model_contract_version')),
        'rate_exhibit_version': safe_str(cmr.get('rate_exhibit_version')),
        'dofr_exhibit_version': safe_str(cmr.get('dofr_exhibit_version')),
        'retro_hold_language': safe_str(cmr.get('retro_hold_language'), 1000),
        'next_renewal_date': cmr.get('next_renewal_date'),
        'liability_start_date': cmr.get('liability_start_date'),
        'provider_dispute_timeframe_initial_days': cmr.get('provider_dispute_timeframe_initial_days'),
        'provider_dispute_timeframe_final_days': cmr.get('provider_dispute_timeframe_final_days'),

        # --- chargemaster ---
        'cm_notification_days': cm.get('notification_days_before_increase'),
        'cm_requires_amendment': cm.get('requires_signed_amendment'),
        'fcr_language': safe_str(cm.get('fcr_language'), 2000),
        'lesser_of_language': safe_str(cm.get('lesser_of_language'), 2000),
        'medicare_lesser_of_language': safe_str(cm.get('medicare_lesser_of_language'), 2000),
        'cob_language': safe_str(cm.get('cob_language'), 2000),
        'other_payor_surcharge': safe_str(cm.get('other_payor_surcharge')),
        'midnight_rule_applicable': cm.get('midnight_rule_applicable'),
    }
    rows_dm.append(row)

write_base_table(rows_dm, 'tbl_contract_documents_master')

print(f"\n  ✅ tbl_contract_documents_master: {len(rows_dm)} rows, {len(rows_dm[0].keys())} cols")
print(f"     All fields parsed from JSON in single pass (no LEFT JOIN chain)")
print(f"     Time: {time.time()-t0:.1f}s")
print(f"  📁 Source: json_extract/ + json_consolidated/ (ZERO table dependencies)")

# COMMAND ----------

# DBTITLE 1,Canonical Provider Identity Resolution
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11c-resolve: CANONICAL PROVIDER IDENTITY RESOLUTION
#   Builds dim_provider_canonical — resolves the many-to-many problem:
#     - Same provider_name → multiple provider_ids (89 cases)
#     - Same provider_id → multiple provider_names (50 cases)
#   Resolution strategy:
#     1. For each provider_id, pick the most recent name (latest amendment_order)
#     2. Group all IDs sharing the same resolved name into one "facility"
#     3. Rank IDs within each facility by doc_count (most active = primary)
#   Output: dev_adb.raw.dim_provider_canonical (456 rows → 278 facilities)
#   Used by: Step 11d (serving layer) to build deduplicated profiles/rates
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═"*80)
print("  ▶ STEP 11c-resolve: CANONICAL PROVIDER IDENTITY RESOLUTION")
print("═"*80)

spark.sql("""
CREATE OR REPLACE TABLE dev_adb.raw.dim_provider_canonical AS

WITH
id_to_latest_name AS (
  SELECT provider_id, provider_name,
         ROW_NUMBER() OVER (
           PARTITION BY provider_id
           ORDER BY amendment_order DESC NULLS LAST, source_filename DESC
         ) AS rn
  FROM dev_adb.raw.tbl_contract_documents_master
  WHERE provider_name IS NOT NULL
),
resolved_names AS (
  SELECT provider_id, provider_name AS canonical_name
  FROM id_to_latest_name WHERE rn = 1
),
facility_stats AS (
  SELECT r.canonical_name, r.provider_id,
         COUNT(DISTINCT d.source_filename) AS doc_count,
         MAX(d.amendment_order) AS max_amendment_order,
         MAX(d.effective_date) AS latest_effective_date,
         SUM(d.rate_count) AS total_rate_count
  FROM resolved_names r
  JOIN dev_adb.raw.tbl_contract_documents_master d ON r.provider_id = d.provider_id
  GROUP BY r.canonical_name, r.provider_id
),
ranked AS (
  SELECT *, ROW_NUMBER() OVER (
    PARTITION BY canonical_name
    ORDER BY doc_count DESC, total_rate_count DESC, max_amendment_order DESC
  ) AS rank_in_facility
  FROM facility_stats
),
facility_assignment AS (
  SELECT canonical_name,
         FIRST_VALUE(provider_id) OVER (PARTITION BY canonical_name ORDER BY rank_in_facility) AS facility_id,
         provider_id, doc_count, max_amendment_order, latest_effective_date,
         total_rate_count, rank_in_facility,
         CASE WHEN rank_in_facility = 1 THEN TRUE ELSE FALSE END AS is_primary_id
  FROM ranked
),
alternate_names AS (
  SELECT r.canonical_name, COLLECT_SET(d.provider_name) AS all_names_used
  FROM resolved_names r
  JOIN dev_adb.raw.tbl_contract_documents_master d ON r.provider_id = d.provider_id
  GROUP BY r.canonical_name
)
SELECT
  fa.provider_id, fa.canonical_name,
  fa.facility_id AS primary_provider_id,
  fa.is_primary_id, fa.rank_in_facility,
  fa.doc_count, fa.total_rate_count, fa.latest_effective_date,
  COUNT(*) OVER (PARTITION BY fa.canonical_name) AS ids_in_facility,
  SUM(fa.doc_count) OVER (PARTITION BY fa.canonical_name) AS facility_total_docs,
  SUM(fa.total_rate_count) OVER (PARTITION BY fa.canonical_name) AS facility_total_rates,
  an.all_names_used
FROM facility_assignment fa
JOIN alternate_names an ON fa.canonical_name = an.canonical_name
ORDER BY fa.canonical_name, fa.rank_in_facility
""")

# Verify
stats = spark.sql("""
  SELECT COUNT(*) AS total_ids, COUNT(DISTINCT canonical_name) AS facilities,
         SUM(CASE WHEN ids_in_facility > 1 THEN 1 ELSE 0 END) AS multi_id_rows
  FROM dev_adb.raw.dim_provider_canonical
""").collect()[0]

print(f"  ✅ dim_provider_canonical: {stats['total_ids']} provider_ids → {stats['facilities']} facilities")
print(f"     {stats['multi_id_rows']} IDs consolidated from multi-ID facilities")
print(f"     Resolution: {stats['total_ids'] - stats['facilities']} duplicate IDs eliminated")

# Add table comment
spark.sql("""COMMENT ON TABLE dev_adb.raw.dim_provider_canonical IS
  'Canonical provider identity resolution. Maps every provider_id to a facility group with one canonical_name. Use primary_provider_id to deduplicate, or JOIN on provider_id to resolve any ID to its facility. Fixes the many-to-many problem: 456 IDs → 278 distinct facilities.'
""")
