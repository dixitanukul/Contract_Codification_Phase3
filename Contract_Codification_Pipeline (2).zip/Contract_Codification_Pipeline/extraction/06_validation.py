# Databricks notebook source
# DBTITLE 1,Validation Overview
# MAGIC %md
# MAGIC # 06 — Validation & Enrichment
# MAGIC **Validates extracted JSONs for Delta-readiness, enriches with medical codes and rate verification.**
# MAGIC 
# MAGIC | Function Group | Purpose |
# MAGIC |---------------|---------|
# MAGIC | Medical codes | Regex extraction of CPT, HCPCS, ICD, Revenue codes |
# MAGIC | Date verification | Confirms dates exist in source PDF text |
# MAGIC | Rate verification | Validates rate values against source text |
# MAGIC | Delta readiness | Checks V6 schema compliance (rate_numeric, full_clause_text, amendments_impact) |
# MAGIC | Coverage scoring | Computes v6_coverage_pct per document |
# MAGIC | Document classification | Bucket/subtype assignment |
# MAGIC 
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `json_extract/*.json` | `json_extract/*.json` (enriched in-place) |
# MAGIC | `checkpoints/step2_with_metadata_v2.parquet` | Pipeline quality report (stdout) |
# MAGIC 
# MAGIC **Run after:** `05_llm_extraction`  
# MAGIC **Run before:** `07_consolidation`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,Rebuild Gate - Skip if No New Files
# ═══════════════════════════════════════════════════════════════════════════════
# PRODUCTION GATE: Skip rebuild if no new files detected
#   Saves ~45 min of compute on no-op scheduled runs.
#   Override: set force_rebuild=true widget to force full rebuild.
#   On exit: job completes with SUCCESS status + descriptive message.
# ═══════════════════════════════════════════════════════════════════════════════
import time as _gate_time

_force = dbutils.widgets.get("force_rebuild") == "true"
_has_new = NEW_FILES_FOUND  # Set in Step 1

print("\n" + "═"*80)
print("  ▶ REBUILD GATE")
print("═"*80)
print(f"  New files detected: {_has_new}")
print(f"  Force rebuild:      {_force}")

if _has_new or _force:
    _reason = "new files detected" if _has_new else "force_rebuild=true"
    print(f"  ✅ Proceeding with full rebuild ({_reason})")
    print(f"  → Steps 4–12 will execute")
    print("═"*80)
else:
    print(f"  ℹ️  No new files and force_rebuild=false")
    print(f"  → Skipping Steps 4–12 (tables unchanged from last run)")
    print(f"  → Set force_rebuild=true to override")
    print("═"*80)
    dbutils.notebook.exit(json.dumps({
        "status": "SUCCESS",
        "reason": "no_new_files",
        "message": "No new PDFs detected since last run. Tables unchanged. Skipped rebuild.",
        "timestamp": _gate_time.strftime("%Y-%m-%d %H:%M:%S"),
        "files_in_registry": len(file_registry),
        "files_in_checkpoint": len(already_parsed),
    }))

# COMMAND ----------

# DBTITLE 1,Medical Code Extraction and Date Verification
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: Validation & Enrichment V6.2 (in-place on json_extract/*.json)
#   Validates Delta-readiness of V6 schema extractions:
#     - Medical codes (CPT, HCPCS, ICD, Revenue) via regex
#     - Date verification flags (hallucination detection) — IMPROVED: more format variants
#     - Rate verification flags (hallucination detection) — IMPROVED: OCR-aware fuzzy matching
#     - rate_numeric POST-PROCESSING — fills missing rate_numeric from rate strings
#     - full_clause_text presence check (Change B)
#     - amendments_impact presence check (Change C)
#     - Capitation rate verification
#     - Settlement amount verification
#     - Exhibit section count
#     - Content bucket + document_subtype (stub detection)
#     - V6 coverage scores per section — IMPROVED: doc-type-specific weighting
#   Writes a "validation" key into each JSON — non-destructive.
#   Checkpoint-aware: skips files already enriched with v6.2.
# FIXES APPLIED (May 2026 - Quality Improvements):
#   FIX 1: rate_numeric post-processor (63% → ~95% coverage)
#   FIX 2: OCR-aware rate verification (76% unverified → ~30%)
#   FIX 3: Expanded date format variants (16% unverified → ~5%)
#   FIX 4: Doc-type-specific coverage scoring (LOAs/CMs not penalized)
#   FIX 5: Stub file detection (routing sheets tagged, not scored)
# P1 FIXES (May 2026 - Gap Analysis Corrections):
#   P1-①: Space-after-comma OCR artifact in rate verification ($1, 062)
#   P1-②: check_delta_readiness() counts ALL rate fields (other_inpatient, therapy, stop_loss)
#   P1-③: Cover Memos/Settlements excluded from full_clause_text scoring
#   P1-④: Contract Routing Memorandum detection (mislabeled BaseAgmtRenew docs)
# ═══════════════════════════════════════════════════════════════════════════════
import os, json, re, time
from datetime import datetime, timezone

print("\n" + "═"*80)
print("  ▶ STEP 4: VALIDATION & ENRICHMENT (V6.2 Delta-Ready — P1 Fixes Applied)")
print("    Medical codes | Date verification (expanded) | Rate verification (OCR-aware)")
print("    rate_numeric post-processing | full_clause_text check | amendments_impact check")
print("    Doc-type-specific scoring | Stub file detection")
print("═"*80)

# ── Medical code extraction (regex — LLM consistently misses these) ──
def extract_medical_codes(text):
    """Extract CPT, HCPCS, ICD, and Revenue codes from raw text."""
    patterns = [
        (r'(?:CPT|CPT\s+Code)[:\s]*(\d{4,5}[A-Z]?)', 'CPT'),
        (r'(?:HCPCS|HCPCS\s+Code)[:\s]*([A-Z]\d{4})', 'HCPCS'),
        (r'(?:ICD[\-\s]*(?:10|9)[\-\s]*(?:CM|PCS)?)[:\s]*([A-Z]?\d{1,3}(?:\.\d{1,4})?)', 'ICD'),
        (r'(?:Revenue\s+Code|Rev\.?\s+Code)[:\s]*(\d{3,4})', 'Revenue'),
        (r'(?:^|\n|\s)(\d{5})(?=\s+\$|\s+\d+\.\d*\s*%)', 'CPT_implicit'),
        (r'(?:Revenue\s+Codes?|Rev\s+Codes?)\s+(\d{4}[\-\s,]*(?:\d{4}[\-\s,]*)*)', 'Revenue_range'),
    ]
    results, seen = [], set()
    for pat, code_type in patterns:
        for m in re.finditer(pat, text, re.IGNORECASE):
            code = m.group(1).strip()
            key = (code_type.split('_')[0], code)
            if key in seen:
                continue
            seen.add(key)
            results.append({'code': code, 'code_type': code_type.split('_')[0]})
    return results

# ── Date verification (hallucination detection) — IMPROVED with expanded variants ──
def verify_date_in_text(date_str, text):
    """Check if a date literal exists in raw text (catches LLM-fabricated dates).
    
    IMPROVED: Expanded format variants to reduce false-positive "unverified" flags.
    Handles: ordinal suffixes, month abbreviations with/without periods,
    slash vs dash separators, no-leading-zero day/month, full/abbrev months.
    """
    if not date_str or date_str in ('None', 'null', 'N/A', ''):
        return None
    if date_str in text:
        return True
    m = re.match(r'(\d{4})-(\d{1,2})-(\d{1,2})', str(date_str))
    if not m:
        return date_str in text
    y, mo, d = m.groups()
    month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June',
                   'July', 'August', 'September', 'October', 'November', 'December']
    month_abbrevs = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                     'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    # Build comprehensive variant list
    variants = [
        # Numeric formats with slashes and dashes
        f"{mo}/{d}/{y}", f"{int(mo)}/{int(d)}/{y}", f"{int(mo)}/{int(d)}/{y[2:]}",
        f"{mo}-{d}-{y}", f"{int(mo)}-{int(d)}-{y}", f"{int(mo)}-{int(d)}-{y[2:]}",
        f"{mo}.{d}.{y}", f"{int(mo)}.{int(d)}.{y}",
        # Zero-padded variants
        f"{mo.zfill(2)}/{d.zfill(2)}/{y}", f"{mo.zfill(2)}-{d.zfill(2)}-{y}",
        # Year-first (ISO-ish without full ISO match which was already checked)
        f"{y}/{mo}/{d}", f"{y}/{int(mo)}/{int(d)}",
    ]
    
    try:
        mi = int(mo)
        di = int(d)
        mn = month_names[mi]
        ma = month_abbrevs[mi]
        
        # Ordinal suffixes for day
        if di in (1, 21, 31):
            ordinal = f"{di}st"
        elif di in (2, 22):
            ordinal = f"{di}nd"
        elif di in (3, 23):
            ordinal = f"{di}rd"
        else:
            ordinal = f"{di}th"
        
        variants += [
            # Full month name variants
            f"{mn} {di}, {y}", f"{mn} {d}, {y}", f"{mn} {di} {y}",
            f"{mn} {d.zfill(2)}, {y}", f"{mn} {ordinal}, {y}",
            f"{di} {mn} {y}", f"{d} {mn} {y}", f"{di} {mn}, {y}",
            # Abbreviated month variants
            f"{ma} {di}, {y}", f"{ma} {d}, {y}", f"{ma} {di} {y}",
            f"{ma}. {di}, {y}", f"{ma}. {d}, {y}", f"{ma}. {di} {y}",
            f"{di} {ma} {y}", f"{d} {ma} {y}",
            f"{di} {ma}, {y}", f"{di} {ma}. {y}",
            # Lowercase variants
            f"{mn.lower()} {di}, {y}", f"{mn.lower()} {d}, {y}",
            f"{ma.lower()} {di}, {y}", f"{ma.lower()} {d}, {y}",
            f"{ma.lower()}. {di}, {y}",
            # UPPERCASE variants (OCR sometimes produces all-caps)
            f"{mn.upper()} {di}, {y}", f"{ma.upper()} {di}, {y}",
            f"{ma.upper()}. {di}, {y}",
            # Without comma
            f"{mn} {di} {y}", f"{ma} {di} {y}", f"{ma}. {di} {y}",
            # Two-digit year
            f"{mn} {di}, {y[2:]}", f"{ma} {di}, {y[2:]}",
            f"{int(mo)}/{int(d)}/{y[2:]}",
        ]
    except (ValueError, IndexError):
        pass
    
    return any(v in text for v in variants)

# ── Rate verification (hallucination detection) — IMPROVED: OCR-aware fuzzy matching ──

# COMMAND ----------

# DBTITLE 1,Rate Verification Functions
def verify_rate_in_text(rate_str, text):
    """Check if a rate amount exists in raw text (OCR-aware fuzzy matching).
    
    IMPROVED: Handles common OCR artifacts:
    - Comma vs period confusion (6,628 → 6.628)
    - Missing/extra dollar signs ($5,748 vs 5,748 vs 5748)
    - Percentage formats (88.9% vs 88.9 vs .889)
    - Decimal precision differences (5748 vs 5748.00 vs 5,748.00)
    - Whitespace in numbers (5 748 vs 5748)
    """
    if not rate_str or str(rate_str).strip() in ('', 'None', 'null', 'N/A', 'varies', 'n/a'):
        return True  # nothing to verify
    
    rate_s = str(rate_str).strip()
    
    # Direct match first
    if rate_s in text:
        return True
    
    # Extract all numeric values from the rate string
    nums = re.findall(r'[\d,]+(?:\.\d+)?', rate_s)
    if not nums:
        # Non-numeric rate (e.g., "varies by case", "N/A") — can't verify
        return True
    
    for n in nums:
        n_clean = n.replace(',', '')
        
        # Skip very short numbers (likely not meaningful rates)
        if len(n_clean) < 2 and '.' not in n_clean:
            continue
        
        # Check 1: Raw number in text
        if n_clean in text:
            return True
        
        # Check 2: With dollar sign
        if f'${n_clean}' in text or f'$ {n_clean}' in text:
            return True
        
        # Check 3: Formatted with commas
        try:
            num_val = float(n_clean)
            if num_val >= 1000:
                formatted = f"{int(num_val):,}" if num_val == int(num_val) else f"{num_val:,.2f}"
                if formatted in text or f'${formatted}' in text:
                    return True
            # Check integer form
            if num_val == int(num_val) and str(int(num_val)) in text:
                return True
            # Check with .00 suffix
            if f"{num_val:.2f}" in text:
                return True
        except ValueError:
            pass
        
        # Check 4: OCR comma→period variant (6628 → 6.628, 5748 → 5.748)
        if len(n_clean) >= 4 and '.' not in n_clean:
            # Try inserting a period where comma would be (every 3 digits from right)
            for pos in range(len(n_clean)-3, 0, -3):
                ocr_variant = n_clean[:pos] + '.' + n_clean[pos:]
                if ocr_variant in text:
                    return True
        
        # Check 5: OCR period→comma variant (5.748 → 5,748)
        if '.' in n_clean:
            comma_variant = n_clean.replace('.', ',')
            if comma_variant in text:
                return True
        
        # Check 6: Whitespace-separated (5 748, 5 748.00)
        if len(n_clean) >= 4 and '.' not in n_clean:
            for pos in range(len(n_clean)-3, 0, -3):
                spaced = n_clean[:pos] + ' ' + n_clean[pos:]
                if spaced in text:
                    return True
        
        # Check 7: Percentage variant (if rate looks like a percentage)
        if '%' in rate_s:
            pct_num = n_clean.rstrip('%')
            if pct_num in text or f"{pct_num}%" in text or f"{pct_num} %" in text:
                return True
        
        # Check 8: Space-after-comma OCR artifact ($1, 062 → $1,062)
        # OCR sometimes inserts space after comma in dollar amounts
        if ',' in n:
            # Original rate had comma — try with space after comma
            spaced_variant = n.replace(',', ', ')
            if spaced_variant in text or f'${spaced_variant}' in text:
                return True
        elif len(n_clean) >= 4 and '.' not in n_clean:
            # Rate extracted without comma (e.g., "1062") — try formatted with space
            try:
                formatted = f"{int(n_clean):,}"
                if ',' in formatted:
                    spaced_variant = formatted.replace(',', ', ')
                    if spaced_variant in text or f'${spaced_variant}' in text:
                        return True
            except ValueError:
                pass
    
    return False

# ── V6: Structured rate verification — IMPROVED with OCR-aware matching ──
def verify_structured_rates(ec, full_text):
    """Verify rates from V6 structured fields (inpatient_rates, outpatient_rates, capitation_table).
    Uses improved OCR-aware verify_rate_in_text()."""
    verified = unverified = 0
    
    # Inpatient per-diem rates
    ip = ec.get('inpatient_rates', {}) or {}
    for pdr in (ip.get('per_diem_rates') or []):
        if verify_rate_in_text(str(pdr.get('rate', '')), full_text):
            verified += 1
        else:
            unverified += 1
    # Inpatient case rates
    for cr in (ip.get('case_rates') or []):
        if verify_rate_in_text(str(cr.get('case_rate', '')), full_text):
            verified += 1
        else:
            unverified += 1
    # Other inpatient
    for oir in (ip.get('other_inpatient_rates') or []):
        if verify_rate_in_text(str(oir.get('rate', '')), full_text):
            verified += 1
        else:
            unverified += 1
    
    # Outpatient rates
    op = ec.get('outpatient_rates', {}) or {}
    for tier in (op.get('surgical_tiers') or []):
        if verify_rate_in_text(str(tier.get('base_rate', '')), full_text):
            verified += 1
        else:
            unverified += 1
    er = op.get('emergency_services', {}) or {}
    if er.get('cap_amount'):
        if verify_rate_in_text(str(er['cap_amount']), full_text):
            verified += 1
        else:
            unverified += 1
    # Therapy services
    for ts in (op.get('therapy_services') or []):
        if verify_rate_in_text(str(ts.get('per_visit_rate', '')), full_text):
            verified += 1
        else:
            unverified += 1
    
    # Capitation rates
    cap = ec.get('capitation_table', {}) or {}
    for cat_rate in (cap.get('rates_by_category') or []):
        if verify_rate_in_text(str(cat_rate.get('rate', '')), full_text):
            verified += 1
        else:
            unverified += 1
    for myr in (cap.get('multi_year_rates') or []):
        for yr_field in ('year_1_rate', 'year_2_rate', 'year_3_rate', 'year_4_rate'):
            val = myr.get(yr_field)
            if val:
                if verify_rate_in_text(str(val), full_text):
                    verified += 1
                else:
                    unverified += 1
    
    # Exception provisions
    exc = ec.get('exception_provisions', {}) or {}
    for exc_type in ('implants', 'exception_drugs'):
        exc_detail = exc.get(exc_type, {}) or {}
        if exc_detail.get('threshold_amount'):
            if verify_rate_in_text(str(exc_detail['threshold_amount']), full_text):
                verified += 1
            else:
                unverified += 1
    
    # Settlement amount
    st = ec.get('settlement_terms', {}) or {}
    if st.get('settlement_amount'):
        if verify_rate_in_text(str(st['settlement_amount']), full_text):
            verified += 1
        else:
            unverified += 1
    
    # Stop-loss
    sl = ec.get('stop_loss_reinsurance', {}) or {}
    if sl.get('per_diem_attachment_level'):
        if verify_rate_in_text(str(sl['per_diem_attachment_level']), full_text):
            verified += 1
        else:
            unverified += 1
    if sl.get('per_diem_stop_loss_rate'):
        if verify_rate_in_text(str(sl['per_diem_stop_loss_rate']), full_text):
            verified += 1
        else:
            unverified += 1
    
    return verified, unverified


# COMMAND ----------

# DBTITLE 1,Delta Readiness and Coverage Scoring
# ═══════════════════════════════════════════════════════════════════════════════
# NEW FIX: rate_numeric post-processor
# Parses numeric values from rate strings where LLM failed to populate rate_numeric
# Expected improvement: 63% → ~95% rate_numeric coverage
# ═══════════════════════════════════════════════════════════════════════════════
_RATE_NUMERIC_RE = re.compile(r'\$?\s*([\d,]+(?:\.\d{1,4})?)')
_PERCENTAGE_RE = re.compile(r'([\d.]+)\s*%')

def _parse_rate_to_numeric(rate_str):
    """Parse a rate string to a numeric float value.
    
    Handles:
    - "$5,748" → 5748.00
    - "$5,748.50" → 5748.50
    - "5748" → 5748.00
    - "88.9%" → 88.9 (returns as-is, percentage)
    - "37.22% of Monthly CMS Capitation" → 37.22
    - "varies" → None
    - "N/A" → None
    """
    if not rate_str or str(rate_str).strip() in ('', 'None', 'null', 'N/A', 'n/a', 'varies', 'TBD'):
        return None
    
    s = str(rate_str).strip()
    
    # Check for percentage first
    pct_match = _PERCENTAGE_RE.search(s)
    if pct_match:
        try:
            return round(float(pct_match.group(1)), 4)
        except ValueError:
            pass
    
    # Try dollar/numeric extraction
    m = _RATE_NUMERIC_RE.search(s)
    if m:
        num_str = m.group(1).replace(',', '')
        try:
            val = float(num_str)
            # Sanity check: rates should be > 0 and < 100M
            if 0 < val < 100_000_000:
                return round(val, 2)
        except ValueError:
            pass
    
    return None


def postprocess_rate_numeric(ec):
    """Fill missing rate_numeric fields by parsing from rate strings.
    Modifies extracted_content in-place. Returns count of fields filled."""
    if not ec or not isinstance(ec, dict):
        return 0
    
    filled = 0
    
    # Inpatient per-diem rates
    ip = ec.get('inpatient_rates', {}) or {}
    for pdr in (ip.get('per_diem_rates') or []):
        if isinstance(pdr, dict) and pdr.get('rate') and pdr.get('rate_numeric') is None:
            val = _parse_rate_to_numeric(pdr['rate'])
            if val is not None:
                pdr['rate_numeric'] = val
                filled += 1
    
    # Inpatient case rates
    for cr in (ip.get('case_rates') or []):
        if isinstance(cr, dict) and cr.get('case_rate') and cr.get('rate_numeric') is None:
            val = _parse_rate_to_numeric(cr['case_rate'])
            if val is not None:
                cr['rate_numeric'] = val
                filled += 1
        # Also check stop_loss_per_diem → stop_loss_numeric
        if isinstance(cr, dict) and cr.get('stop_loss_per_diem') and cr.get('stop_loss_numeric') is None:
            val = _parse_rate_to_numeric(cr['stop_loss_per_diem'])
            if val is not None:
                cr['stop_loss_numeric'] = val
                filled += 1
    
    # Other inpatient rates
    for oir in (ip.get('other_inpatient_rates') or []):
        if isinstance(oir, dict) and oir.get('rate') and oir.get('rate_numeric') is None:
            val = _parse_rate_to_numeric(oir['rate'])
            if val is not None:
                oir['rate_numeric'] = val
                filled += 1
    
    # Outpatient surgical tiers
    op = ec.get('outpatient_rates', {}) or {}
    for tier in (op.get('surgical_tiers') or []):
        if isinstance(tier, dict) and tier.get('base_rate') and tier.get('rate_numeric') is None:
            val = _parse_rate_to_numeric(tier['base_rate'])
            if val is not None:
                tier['rate_numeric'] = val
                filled += 1
    
    # Outpatient other rates
    for oor in (op.get('other_outpatient_rates') or []):
        if isinstance(oor, dict) and oor.get('rate') and oor.get('rate_numeric') is None:
            val = _parse_rate_to_numeric(oor['rate'])
            if val is not None:
                oor['rate_numeric'] = val
                filled += 1
    
    # Outpatient infusion therapy
    inf = op.get('infusion_therapy', {}) or {}
    if isinstance(inf, dict) and inf.get('per_visit_rate') and inf.get('rate_numeric') is None:
        val = _parse_rate_to_numeric(inf['per_visit_rate'])
        if val is not None:
            inf['rate_numeric'] = val
            filled += 1
    
    # Outpatient therapy services
    for ts in (op.get('therapy_services') or []):
        if isinstance(ts, dict) and ts.get('per_visit_rate') and ts.get('rate_numeric') is None:
            val = _parse_rate_to_numeric(ts['per_visit_rate'])
            if val is not None:
                ts['rate_numeric'] = val
                filled += 1
    
    # Outpatient ER cap_amount → cap_numeric
    er = op.get('emergency_services', {}) or {}
    if isinstance(er, dict) and er.get('cap_amount') and er.get('cap_numeric') is None:
        val = _parse_rate_to_numeric(er['cap_amount'])
        if val is not None:
            er['cap_numeric'] = val
            filled += 1
    
    # Outpatient radiology conversion_factor → conversion_factor_numeric
    rad = op.get('radiology_pathology', {}) or {}
    if isinstance(rad, dict) and rad.get('conversion_factor') and rad.get('conversion_factor_numeric') is None:
        val = _parse_rate_to_numeric(rad['conversion_factor'])
        if val is not None:
            rad['conversion_factor_numeric'] = val
            filled += 1
    
    # Capitation rates
    cap = ec.get('capitation_table', {}) or {}
    for cat_rate in (cap.get('rates_by_category') or []):
        if isinstance(cat_rate, dict) and cat_rate.get('rate') and cat_rate.get('rate_numeric') is None:
            val = _parse_rate_to_numeric(cat_rate['rate'])
            if val is not None:
                cat_rate['rate_numeric'] = val
                filled += 1
    # Multi-year capitation
    for myr in (cap.get('multi_year_rates') or []):
        if isinstance(myr, dict):
            for yr in range(1, 5):
                rate_key = f'year_{yr}_rate'
                num_key = f'year_{yr}_numeric'
                if myr.get(rate_key) and myr.get(num_key) is None:
                    val = _parse_rate_to_numeric(myr[rate_key])
                    if val is not None:
                        myr[num_key] = val
                        filled += 1
    # Supplemental payments
    for sp in (cap.get('supplemental_payments') or []):
        if isinstance(sp, dict) and sp.get('amount') and sp.get('amount_numeric') is None:
            val = _parse_rate_to_numeric(sp['amount'])
            if val is not None:
                sp['amount_numeric'] = val
                filled += 1
    
    # Stop-loss
    sl = ec.get('stop_loss_reinsurance', {}) or {}
    if isinstance(sl, dict):
        if sl.get('per_diem_attachment_level') and sl.get('per_diem_attachment_numeric') is None:
            val = _parse_rate_to_numeric(sl['per_diem_attachment_level'])
            if val is not None:
                sl['per_diem_attachment_numeric'] = val
                filled += 1
        if sl.get('per_diem_stop_loss_rate') and sl.get('per_diem_stop_loss_numeric') is None:
            val = _parse_rate_to_numeric(sl['per_diem_stop_loss_rate'])
            if val is not None:
                sl['per_diem_stop_loss_numeric'] = val
                filled += 1
    
    # Exception provisions
    exc = ec.get('exception_provisions', {}) or {}
    for exc_type in ('implants', 'exception_drugs'):
        exc_detail = exc.get(exc_type, {}) or {}
        if isinstance(exc_detail, dict) and exc_detail.get('threshold_amount') and exc_detail.get('threshold_numeric') is None:
            val = _parse_rate_to_numeric(exc_detail['threshold_amount'])
            if val is not None:
                exc_detail['threshold_numeric'] = val
                filled += 1
    
    # Settlement amount
    st = ec.get('settlement_terms', {}) or {}
    if isinstance(st, dict) and st.get('settlement_amount') and st.get('settlement_amount_numeric') is None:
        val = _parse_rate_to_numeric(st['settlement_amount'])
        if val is not None:
            st['settlement_amount_numeric'] = val
            filled += 1
    
    return filled


# ── V6: Delta-readiness checks ──
def check_delta_readiness(ec, doc_type):
    """Check V6 Delta-ready fields: rate_numeric, full_clause_text, amendments_impact."""
    dt = (doc_type or '').lower()
    
    # Change A: rate_numeric presence
    rates_with_numeric = rates_without_numeric = 0
    ip = ec.get('inpatient_rates', {}) or {}
    for pdr in (ip.get('per_diem_rates') or []):
        if isinstance(pdr, dict) and pdr.get('rate'):
            if pdr.get('rate_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    for cr in (ip.get('case_rates') or []):
        if isinstance(cr, dict) and cr.get('case_rate'):
            if cr.get('rate_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    op = ec.get('outpatient_rates', {}) or {}
    for tier in (op.get('surgical_tiers') or []):
        if isinstance(tier, dict) and tier.get('base_rate'):
            if tier.get('rate_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    cap = ec.get('capitation_table', {}) or {}
    for cat_rate in (cap.get('rates_by_category') or []):
        if isinstance(cat_rate, dict) and cat_rate.get('rate'):
            if cat_rate.get('rate_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    # FIX P1-②: Also count other_inpatient_rates, therapy_services, stop_loss
    for oir in (ip.get('other_inpatient_rates') or []):
        if isinstance(oir, dict) and oir.get('rate'):
            if oir.get('rate_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    for ts in (op.get('therapy_services') or []):
        if isinstance(ts, dict) and ts.get('per_visit_rate'):
            if ts.get('rate_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    for oor in (op.get('other_outpatient_rates') or []):
        if isinstance(oor, dict) and oor.get('rate'):
            if oor.get('rate_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    sl = ec.get('stop_loss_reinsurance', {}) or {}
    if isinstance(sl, dict):
        if sl.get('per_diem_attachment_level'):
            if sl.get('per_diem_attachment_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
        if sl.get('per_diem_stop_loss_rate'):
            if sl.get('per_diem_stop_loss_numeric') is not None:
                rates_with_numeric += 1
            else:
                rates_without_numeric += 1
    
    # Change B: full_clause_text presence
    # FIX P1-③: Cover Memos and Settlements never contain clause sections — exclude from scoring
    clause_sections = ['termination', 'compliance_and_regulatory', 'grievance_and_appeals',
                       'dispute_resolution', 'confidentiality_and_records', 'indemnification_insurance']
    clauses_with_text = clauses_without_text = 0
    if dt.endswith('cm') or 'covermemo' in dt or 'settlement' in dt:
        # CMs/Settlements don't have clause sections — 0/0 = N/A, not penalized
        pass
    else:
        for section in clause_sections:
            sec_data = ec.get(section, {}) or {}
            if isinstance(sec_data, dict):
                if sec_data.get('full_clause_text'):
                    clauses_with_text += 1
                else:
                    # Only count as "missing" if the section has other data
                    has_other = any(v for k, v in sec_data.items() if k != 'full_clause_text' and v)
                    if has_other:
                        clauses_without_text += 1
    
    # Change C: amendments_impact presence (for amendments)
    has_amendments_impact = False
    amendments_impact_quality = 'n/a'
    if 'amend' in dt or 'lra' in dt or 'addendum' in dt:
        ai = ec.get('amendments_impact', {}) or {}
        has_amendments_impact = bool(ai.get('exhibits_replaced') or ai.get('sections_modified') or ai.get('summary_of_changes'))
        if has_amendments_impact:
            amendments_impact_quality = 'good' if ai.get('prior_rates_superseded') is not None else 'partial'
        else:
            amendments_impact_quality = 'missing'
    
    return {
        'rates_with_numeric': rates_with_numeric,
        'rates_without_numeric': rates_without_numeric,
        'rate_numeric_pct': 100.0 if (rates_with_numeric + rates_without_numeric) == 0 else round(rates_with_numeric / (rates_with_numeric + rates_without_numeric) * 100, 1),
        'clauses_with_full_text': clauses_with_text,
        'clauses_without_full_text': clauses_without_text,
        'full_clause_text_pct': 100.0 if (clauses_with_text + clauses_without_text) == 0 else round(clauses_with_text / (clauses_with_text + clauses_without_text) * 100, 1),
        'has_amendments_impact': has_amendments_impact,
        'amendments_impact_quality': amendments_impact_quality,
    }

# ── V6: Section coverage score — IMPROVED: doc-type-specific weighting ──
def compute_v6_coverage(ec, doc_type, text_length=0):
    """Compute coverage percentage for V6 sections based on document type.
    
    IMPROVED: Doc-type-specific scoring so LOAs, Cover Memos, and Settlements
    aren't penalized for missing rate tables they'd never contain.
    Stub files (< 2K chars) get separate treatment.
    """
    dt = (doc_type or '').lower()
    scores = {}
    
    # Universal sections (always scored)
    scores['contract_overview'] = 1 if ec.get('contract_overview', {}).get('agreement_title') else 0
    scores['parties'] = 1 if ec.get('parties', {}).get('provider', {}).get('name') else 0
    scores['financial_terms'] = 1 if ec.get('financial_terms', {}).get('payment_type') else 0
    
    # Rate sections
    ip = ec.get('inpatient_rates', {}) or {}
    scores['inpatient_rates'] = 1 if (ip.get('per_diem_rates') or ip.get('case_rates')) else 0
    op = ec.get('outpatient_rates', {}) or {}
    scores['outpatient_rates'] = 1 if (op.get('surgical_tiers') or op.get('emergency_services', {}).get('rate_type')) else 0
    scores['stop_loss'] = 1 if ec.get('stop_loss_reinsurance', {}).get('has_stop_loss') else 0
    scores['exception_provisions'] = 1 if (ec.get('exception_provisions', {}).get('implants', {}).get('threshold_amount')) else 0
    
    # Capitation
    cap = ec.get('capitation_table', {}) or {}
    scores['capitation'] = 1 if cap.get('is_capitated') or cap.get('rates_by_category') else 0
    
    # HAC/Never Events
    scores['hac_never_events'] = 1 if ec.get('hac_never_events', {}).get('has_hac_policy') else 0
    
    # Cover memo
    cm = ec.get('cover_memo_metadata', {}) or {}
    scores['cover_memo'] = 1 if any(cm.get(k) for k in ('rate_percent_increase_yr1', 'model_contract_version', 'rate_exhibit_version')) else 0
    
    # Settlement
    st = ec.get('settlement_terms', {}) or {}
    scores['settlement'] = 1 if st.get('settlement_amount') else 0
    
    # Chargemaster
    ch = ec.get('chargemaster_provisions', {}) or {}
    scores['chargemaster'] = 1 if any(v is not None for v in ch.values()) else 0
    
    # V6 Delta-readiness bonus checks
    scores['full_clause_text'] = 1 if any(
        (ec.get(s, {}) or {}).get('full_clause_text')
        for s in ('termination', 'compliance_and_regulatory', 'dispute_resolution', 'confidentiality_and_records')
    ) else 0
    
    # V6: rate_numeric presence
    has_numeric = any(r.get('rate_numeric') for r in (ip.get('per_diem_rates') or []) if isinstance(r, dict))
    scores['rate_numeric'] = 1 if has_numeric else 0
    
    # ── DOC-TYPE-SPECIFIC SCORING ──
    # Only include relevant sections in the denominator based on document type
    if 'settlement' in dt:
        # Settlements: only score overview, parties, settlement_terms, clause_text
        relevant = ['contract_overview', 'parties', 'settlement', 'full_clause_text']
    elif dt.endswith('cm') or 'covermemo' in dt:
        # Cover Memos: overview, parties, cover_memo, chargemaster, financial_terms
        relevant = ['contract_overview', 'parties', 'cover_memo', 'chargemaster', 'financial_terms']
    elif 'letterofagmt' in dt or 'loa' in dt or 'mutualagmt' in dt or 'termagmt' in dt:
        # LOAs / Mutual / Term agreements: overview, parties, financial_terms, clause_text
        relevant = ['contract_overview', 'parties', 'financial_terms', 'full_clause_text']
    elif 'baseagmt' in dt:
        # Base agreements: everything except settlement and cover_memo
        relevant = [k for k in scores.keys() if k not in ('settlement', 'cover_memo')]
    elif 'amend' in dt or 'lra' in dt or 'addendum' in dt:
        # Amendments: overview, parties, financial, rates, capitation, clause_text, rate_numeric
        relevant = ['contract_overview', 'parties', 'financial_terms', 'inpatient_rates',
                    'outpatient_rates', 'capitation', 'full_clause_text', 'rate_numeric']
    else:
        # Unknown: score all sections
        relevant = list(scores.keys())
    
    # Compute weighted coverage using only relevant sections
    relevant_scores = {k: scores[k] for k in relevant if k in scores}
    coverage_pct = sum(relevant_scores.values()) / max(len(relevant_scores), 1) * 100
    
    return scores, coverage_pct

# ── Exhibit count ──
def count_exhibits(text):
    markers = set(re.findall(r'(?i)(?:EXHIBIT|ATTACHMENT|APPENDIX|ADDENDUM|SCHEDULE)\s+[A-Z0-9][A-Z0-9\-]*', text))
    return len(markers)

# ── Content bucket (V6 updated) ──
def classify_bucket(doc_type):
    dt = (doc_type or '').lower()
    if 'medicarestar' in dt or 'qualityprogram' in dt:
        return 'B4_Medicare_Quality_Program'
    if 'settlement' in dt:
        return 'B5_Settlement_Agreement'
    if 'letterofagmt' in dt or 'aco' in dt:
        return 'B6_LOA_ACO_Other'
    if dt.endswith('cm'):
        return 'B3_Cover_Memo'
    if 'baseagmt' in dt:
        return 'B1_Base_Agreement'
    if 'amend' in dt or 'lra' in dt or 'addendum' in dt:
        return 'B2_Amendment'
    return 'B7_Other'

# ── Document subtype detection (stub/routing sheet identification) ──
def classify_document_subtype(doc_type, text_length, full_text=''):
    """Identify stub files, routing sheets, and other thin documents.
    Returns subtype label for metadata tagging.
    FIX P1-④: Also detects Contract Routing Memoranda mislabeled as BaseAgmtRenew."""
    dt = (doc_type or '').lower()
    # FIX P1-④: Detect Contract Routing Memorandum from first line
    first_200 = (full_text[:200] if full_text else '').lower()
    if 'contract routing memorandum' in first_200 or 'routing memorandum' in first_200:
        return 'routing_memo'
    if text_length < 2000:
        # Very short files — likely routing sheets or cover pages
        if 'baseagmt' in dt:
            return 'routing_sheet'
        if 'mutualagmt' in dt or 'termagmt' in dt:
            return 'stub_agreement'
        return 'stub_document'
    elif text_length < 5000:
        if 'letterofagmt' in dt or 'loa' in dt:
            return 'brief_loa'
        if 'mutualagmt' in dt or 'termagmt' in dt:
            return 'brief_agreement'
    return None  # Normal document


# COMMAND ----------

# DBTITLE 1,Main Validation Loop - Process All JSONs
# ═══ MAIN PROCESSING LOOP ═══
t0 = time.time()
json_files = sorted([f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')])

enriched = skipped = errors = 0
rate_numeric_filled_total = 0
stats = []

print(f"  📄 Processing {len(json_files)} JSON files...")

for ji, jf in enumerate(json_files, 1):
    if ji % 50 == 0 or ji == len(json_files):
        print(f"     Progress: {ji}/{len(json_files)} files processed")
    jp = os.path.join(OUTPUT_DIR, jf)
    try:
        with open(jp) as f:
            doc = json.load(f)
    except Exception as e:
        errors += 1
        continue

    # Skip files already enriched with V6.1 (checkpoint-aware)
    if 'validation' in doc and doc['validation'].get('schema_version') == 'v6.2b':
        skipped += 1
        v = doc['validation']
        stats.append({'filename': doc.get('file_metadata', {}).get('source_filename', jf),
                      'content_bucket': v.get('content_bucket', ''),
                      'medical_code_count': v.get('medical_code_count', 0),
                      'exhibit_count': v.get('exhibit_count', 0),
                      'dates_verified': v.get('dates_verified', 0),
                      'dates_unverified': v.get('dates_unverified', 0),
                      'rates_verified': v.get('rates_verified', 0),
                      'rates_unverified': v.get('rates_unverified', 0),
                      'v6_coverage_pct': v.get('v6_coverage_pct', 0),
                      'rate_numeric_pct': v.get('delta_readiness', {}).get('rate_numeric_pct', 0),
                      'full_clause_text_pct': v.get('delta_readiness', {}).get('full_clause_text_pct', 0)})
        continue

    # Skip error files (no extracted_content)
    ec = doc.get('extracted_content')
    if not ec or not isinstance(ec, dict):
        skipped += 1
        continue

    fm = doc.get('file_metadata', {})
    full_text = doc.get('full_text', '') or ''
    doc_type = fm.get('document_type', '') or ''
    text_length = len(full_text)

    # ── 0. POST-PROCESS: Fill missing rate_numeric values ──
    n_filled = postprocess_rate_numeric(ec)
    rate_numeric_filled_total += n_filled

    # ── 1. Medical codes ──
    codes = extract_medical_codes(full_text)

    # ── 2. Date verification (expanded variants) ──
    co = ec.get('contract_overview', {}) or {}
    date_checks = {}
    dates_verified = dates_unverified = 0
    for dfield in ('effective_date', 'expiration_date', 'execution_date'):
        result = verify_date_in_text(co.get(dfield), full_text)
        date_checks[dfield] = result
        if result is True:
            dates_verified += 1
        elif result is False:
            dates_unverified += 1

    # ── 3. Rate verification (OCR-aware fuzzy matching) ──
    struct_verified, struct_unverified = verify_structured_rates(ec, full_text)
    
    # Also check legacy fee_schedule_rates if present
    ft = ec.get('financial_terms', {}) or {}
    fsr = ft.get('fee_schedule_rates', []) or []
    legacy_verified = legacy_unverified = 0
    for rate_entry in fsr:
        if verify_rate_in_text(str(rate_entry.get('rate', '')), full_text):
            legacy_verified += 1
        else:
            legacy_unverified += 1
    
    rates_verified = struct_verified + legacy_verified
    rates_unverified = struct_unverified + legacy_unverified

    # ── 4. Exhibit count ──
    n_exhibits = count_exhibits(full_text)

    # ── 5. Content bucket + document subtype ──
    bucket = classify_bucket(doc_type)
    doc_subtype = classify_document_subtype(doc_type, text_length, full_text)

    # ── 6. V6 coverage score (doc-type-specific) ──
    coverage_scores, coverage_pct = compute_v6_coverage(ec, doc_type, text_length)

    # ── 7. V6 Delta-readiness checks ──
    delta_readiness = check_delta_readiness(ec, doc_type)

    # ── Write validation key into JSON ──
    doc['validation'] = {
        'schema_version': 'v6.2b',
        'enriched_at': datetime.now(timezone.utc).isoformat(),
        'content_bucket': bucket,
        'document_subtype': doc_subtype,
        'medical_codes': codes,
        'medical_code_count': len(codes),
        'date_verification': date_checks,
        'dates_verified': dates_verified,
        'dates_unverified': dates_unverified,
        'rates_verified': rates_verified,
        'rates_unverified': rates_unverified,
        'rates_total': rates_verified + rates_unverified,
        'rate_numeric_fields_filled': n_filled,
        'exhibit_count': n_exhibits,
        'v6_coverage_scores': coverage_scores,
        'v6_coverage_pct': round(coverage_pct, 1),
        'delta_readiness': delta_readiness,
    }

    with open(jp, 'w', encoding='utf-8') as f:
        json.dump(doc, f, indent=2, ensure_ascii=False)
    enriched += 1

    stats.append({'filename': fm.get('source_filename', jf),
                  'content_bucket': bucket,
                  'medical_code_count': len(codes),
                  'exhibit_count': n_exhibits,
                  'dates_verified': dates_verified,
                  'dates_unverified': dates_unverified,
                  'rates_verified': rates_verified,
                  'rates_unverified': rates_unverified,
                  'v6_coverage_pct': coverage_pct,
                  'rate_numeric_pct': delta_readiness['rate_numeric_pct'],
                  'full_clause_text_pct': delta_readiness['full_clause_text_pct']})

elapsed = time.time() - t0
print(f"\n{'═'*70}")
print(f"✅ Step 4 complete in {elapsed:.1f}s (V6.2 Delta-Ready schema — P1 Fixes Applied)")
print(f"   {enriched} files enriched | {skipped} skipped (already done or no content) | {errors} errors")
print(f"   rate_numeric post-processor filled {rate_numeric_filled_total} missing values")
print(f"   Output: {OUTPUT_DIR} (in-place enrichment)")
print(f"{'═'*70}")

# Summary stats
import pandas as pd
if stats:
    sdf = pd.DataFrame(stats)
    print(f"\n  Medical codes found: {int(sdf['medical_code_count'].sum()):,} total across {(sdf['medical_code_count'] > 0).sum()} files")
    print(f"  Exhibits detected:  {int(sdf['exhibit_count'].sum()):,} total across {(sdf['exhibit_count'] > 0).sum()} files")
    print(f"  Date verification:  {int(sdf['dates_verified'].sum())} verified | {int(sdf['dates_unverified'].sum())} UNVERIFIED (possible hallucinations)")
    print(f"  Rate verification:  {int(sdf['rates_verified'].sum())} verified | {int(sdf['rates_unverified'].sum())} UNVERIFIED")
    print(f"  V6 coverage (mean): {sdf['v6_coverage_pct'].mean():.1f}%")
    print(f"\n  DELTA-READINESS (V6.2):")
    print(f"    rate_numeric present:     {sdf['rate_numeric_pct'].mean():.0f}% of rate rows (target: 100%)")
    print(f"    full_clause_text present: {sdf['full_clause_text_pct'].mean():.0f}% of clause sections (target: 100%)")
    print(f"    rate_numeric post-filled: {rate_numeric_filled_total} values across all files")
    print(f"\n  Bucket breakdown:")
    for bucket, grp in sdf.groupby('content_bucket'):
        print(f"    {bucket:<35s} {len(grp):>4d} files | {int(grp['medical_code_count'].sum()):>4d} codes | {int(grp['exhibit_count'].sum()):>4d} exhibits | {grp['v6_coverage_pct'].mean():.0f}% coverage | {grp['rate_numeric_pct'].mean():.0f}% numeric")

# COMMAND ----------

# DBTITLE 1,Pipeline Quality Report
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: Pipeline Validation Report (V6 Delta-Ready)
#   Reads json_extract/*.json, validates outputs, reports pipeline health.
#   V6: Reports on Delta-readiness (rate_numeric, full_clause_text, amendments_impact)
#   Exit codes: 0=clean, 1=partial failures, 2=critical (>50% failed)
# ═══════════════════════════════════════════════════════════════════════════════
import os, json
import pandas as pd
from datetime import datetime, timezone

print("\n" + "═"*80)
print("  ▶ STEP 5: PIPELINE VALIDATION REPORT (V6 Delta-Ready)")
print("═"*80)

json_files = sorted([f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')])

print(f"  🔍 Scanning {len(json_files)} JSON files for quality metrics...")
print("=" * 100)
print("  PIPELINE VALIDATION REPORT (V6 Delta-Ready Schema)")
print("=" * 100)

# Scan all JSON files for stats
stats = []
has_errors = []
for jf in json_files:
    jp = os.path.join(OUTPUT_DIR, jf)
    try:
        with open(jp) as f:
            doc = json.load(f)
    except Exception:
        has_errors.append(jf)
        continue

    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content')
    v = doc.get('validation', {})
    dr = v.get('delta_readiness', {})

    has_content = bool(ec and isinstance(ec, dict))
    has_err = bool(doc.get('extraction_error'))
    
    # Structured rate counts
    ip = (ec or {}).get('inpatient_rates', {}) or {}
    op = (ec or {}).get('outpatient_rates', {}) or {}
    cap = (ec or {}).get('capitation_table', {}) or {}
    hac = (ec or {}).get('hac_never_events', {}) or {}
    cm = (ec or {}).get('cover_memo_metadata', {}) or {}
    st = (ec or {}).get('settlement_terms', {}) or {}
    exc = (ec or {}).get('exception_provisions', {}) or {}
    sl = (ec or {}).get('stop_loss_reinsurance', {}) or {}
    chm = (ec or {}).get('chargemaster_provisions', {}) or {}
    rf = (ec or {}).get('regional_factors', []) or []
    ai = (ec or {}).get('amendments_impact', {}) or {}

    stats.append({
        'filename': fm.get('source_filename', jf),
        'content_bucket': v.get('content_bucket', ''),
        'has_content': has_content,
        'has_error': has_err,
        'text_length': fm.get('text_length', 0),
        'medical_codes': v.get('medical_code_count', 0),
        'exhibit_count': v.get('exhibit_count', 0),
        'dates_verified': v.get('dates_verified', 0),
        'dates_unverified': v.get('dates_unverified', 0),
        'rates_verified': v.get('rates_verified', 0),
        'rates_unverified': v.get('rates_unverified', 0),
        'v6_coverage_pct': v.get('v6_coverage_pct', 0),
        # Delta-readiness metrics
        'rate_numeric_pct': dr.get('rate_numeric_pct', 0),
        'full_clause_text_pct': dr.get('full_clause_text_pct', 0),
        'has_amendments_impact': dr.get('has_amendments_impact', False),
        'amendments_impact_quality': dr.get('amendments_impact_quality', 'n/a'),
        # Field presence
        'has_inpatient_per_diem': len(ip.get('per_diem_rates') or []) > 0,
        'has_inpatient_case_rates': len(ip.get('case_rates') or []) > 0,
        'has_outpatient_tiers': len(op.get('surgical_tiers') or []) > 0,
        'has_er_rates': bool(op.get('emergency_services', {}).get('rate_type')),
        'has_capitation': bool(cap.get('is_capitated') or cap.get('rates_by_category')),
        'has_multi_year_cap': len(cap.get('multi_year_rates') or []) > 0,
        'has_hac_policy': bool(hac.get('has_hac_policy')),
        'has_stop_loss': bool(sl.get('has_stop_loss')),
        'has_exceptions': bool(exc.get('implants', {}).get('threshold_amount')),
        'has_cover_memo': any(cm.get(k) for k in ('rate_percent_increase_yr1', 'model_contract_version', 'rate_exhibit_version')),
        'has_settlement': bool(st.get('settlement_amount')),
        'has_chargemaster': any(v is not None for v in chm.values()) if isinstance(chm, dict) else False,
        'has_regional_factors': len(rf) > 0,
        'has_full_clause_text': any(
            ((ec or {}).get(s, {}) or {}).get('full_clause_text')
            for s in ('termination', 'compliance_and_regulatory', 'dispute_resolution', 'confidentiality_and_records', 'indemnification_insurance')
        ),
        'n_per_diem_rates': len(ip.get('per_diem_rates') or []),
        'n_case_rates': len(ip.get('case_rates') or []),
        'n_surgical_tiers': len(op.get('surgical_tiers') or []),
        'n_cap_categories': len(cap.get('rates_by_category') or []),
        'n_hac_conditions': len(hac.get('hac_list') or []),
        'n_regional_factors': len(rf),
    })

sdf = pd.DataFrame(stats)
total = len(sdf)
ok = int(sdf['has_content'].sum())
failed = int(sdf['has_error'].sum())

print(f"\n  Files on disk:           {len(json_files)}")
print(f"  Successful extractions:  {ok}/{total} ({ok/total*100:.0f}%)")
print(f"  Failed extractions:      {failed}")
if has_errors:
    print(f"  Unreadable JSONs:        {len(has_errors)}")

# V6 Delta-Readiness Summary
print(f"\n  {'='*70}")
print(f"  V6 DELTA-READINESS ASSESSMENT")
print(f"  {'='*70}")
print(f"  {'Metric':<40s} {'Score':>10s} {'Target':>10s} {'Status':>8s}")
print(f"  {chr(9472)*70}")

rate_num_mean = sdf['rate_numeric_pct'].mean()
clause_mean = sdf['full_clause_text_pct'].mean()
amend_df = sdf[sdf['content_bucket'] == 'B2_Amendment']
amend_impact_pct = amend_df['has_amendments_impact'].mean() * 100 if len(amend_df) > 0 else 0

metrics = [
    ('Change A: rate_numeric on rate rows', f"{rate_num_mean:.0f}%", '100%', '✅' if rate_num_mean >= 90 else '⚠️' if rate_num_mean >= 50 else '❌'),
    ('Change B: full_clause_text present', f"{clause_mean:.0f}%", '100%', '✅' if clause_mean >= 90 else '⚠️' if clause_mean >= 50 else '❌'),
    ('Change C: amendments_impact (amendments)', f"{amend_impact_pct:.0f}%", '100%', '✅' if amend_impact_pct >= 90 else '⚠️' if amend_impact_pct >= 50 else '❌'),
]
for label, score, target, status in metrics:
    print(f"  {label:<40s} {score:>10s} {target:>10s} {status:>8s}")

# V6 Structured Field Coverage
print(f"\n  V6 STRUCTURED FIELD COVERAGE:")
print(f"  {'Field':<30s} {'Files With Data':>15s} {'% of Total':>10s} {'Avg Count':>10s}")
print(f"  {chr(9472)*70}")
v6_fields = [
    ('Inpatient Per-Diem Rates', 'has_inpatient_per_diem', 'n_per_diem_rates'),
    ('Inpatient Case Rates', 'has_inpatient_case_rates', 'n_case_rates'),
    ('Outpatient Surgical Tiers', 'has_outpatient_tiers', 'n_surgical_tiers'),
    ('ER/Urgent Care Rates', 'has_er_rates', None),
    ('Capitation Tables', 'has_capitation', 'n_cap_categories'),
    ('Multi-Year Cap Rates', 'has_multi_year_cap', None),
    ('HAC/Never Event Policy', 'has_hac_policy', 'n_hac_conditions'),
    ('Stop-Loss Provisions', 'has_stop_loss', None),
    ('Exception Provisions', 'has_exceptions', None),
    ('Cover Memo Metadata', 'has_cover_memo', None),
    ('Settlement Terms', 'has_settlement', None),
    ('Chargemaster Provisions', 'has_chargemaster', None),
    ('Regional Factors', 'has_regional_factors', 'n_regional_factors'),
    ('Full Clause Text (any)', 'has_full_clause_text', None),
]
for label, bool_col, count_col in v6_fields:
    n_with = int(sdf[bool_col].sum())
    pct = n_with / total * 100 if total > 0 else 0
    avg_ct = f"{sdf[count_col].mean():.1f}" if count_col else "-"
    print(f"  {label:<30s} {n_with:>15,} {pct:>9.1f}% {avg_ct:>10s}")

# Medical codes
print(f"\n  MEDICAL CODE EXTRACTION (regex):")
print(f"  {'Medical codes found':<25s} {int(sdf['medical_codes'].sum()):>10,} total across {(sdf['medical_codes'] > 0).sum()} files")
print(f"  {'Exhibit sections':<25s} {int(sdf['exhibit_count'].sum()):>10,} total across {(sdf['exhibit_count'] > 0).sum()} files")

# Hallucination detection
print(f"\n  HALLUCINATION DETECTION:")
total_dates_v = int(sdf['dates_verified'].sum())
total_dates_u = int(sdf['dates_unverified'].sum())
total_rates_v = int(sdf['rates_verified'].sum())
total_rates_u = int(sdf['rates_unverified'].sum())
if (total_dates_v + total_dates_u) > 0:
    print(f"  Dates:  {total_dates_v} verified | {total_dates_u} UNVERIFIED ({total_dates_u/(total_dates_v+total_dates_u)*100:.0f}% suspect)")
else:
    print(f"  Dates: no data")
if (total_rates_v + total_rates_u) > 0:
    print(f"  Rates:  {total_rates_v} verified | {total_rates_u} UNVERIFIED ({total_rates_u/(total_rates_v+total_rates_u)*100:.0f}% suspect)")
else:
    print(f"  Rates: no data")

# V6 Coverage Score Distribution
print(f"\n  V6 COVERAGE SCORE DISTRIBUTION:")
if sdf['v6_coverage_pct'].any():
    print(f"  Mean:   {sdf['v6_coverage_pct'].mean():.1f}%")
    print(f"  Median: {sdf['v6_coverage_pct'].median():.1f}%")
    print(f"  Min:    {sdf['v6_coverage_pct'].min():.1f}%")
    print(f"  Max:    {sdf['v6_coverage_pct'].max():.1f}%")
    # Score brackets
    brackets = [(90, 100, '≥ 90%'), (75, 90, '75-89%'), (50, 75, '50-74%'), (0, 50, '< 50%')]
    for low, high, label in brackets:
        n = int(((sdf['v6_coverage_pct'] >= low) & (sdf['v6_coverage_pct'] < high + (1 if high == 100 else 0))).sum())
        print(f"    {label:<10s}: {n:>5d} files")

# Bucket breakdown
if sdf['content_bucket'].any():
    print(f"\n  {'Bucket':<28s} {'Files':>5s} {'Codes':>6s} {'V6 Cov%':>8s} {'NumericPct':>10s} {'ClausesPct':>10s} {'InptRates':>10s} {'CapTbl':>6s}")
    print(f"  {chr(9472)*90}")
    for bucket, grp in sdf.groupby('content_bucket'):
        if not bucket:
            continue
        print(f"  {bucket:<28s} {len(grp):>5d} {int(grp['medical_codes'].sum()):>6,} "
              f"{grp['v6_coverage_pct'].mean():>7.0f}% "
              f"{grp['rate_numeric_pct'].mean():>9.0f}% "
              f"{grp['full_clause_text_pct'].mean():>9.0f}% "
              f"{int(grp['has_inpatient_per_diem'].sum()):>10d} {int(grp['has_capitation'].sum()):>6d}")

# Quality flags
print(f"\n  QUALITY FLAGS:")
if failed > 0:
    print(f"  ⚠ {failed} files with extraction errors")
    err_files = sdf[sdf['has_error']]['filename'].head(5).tolist()
    for fn in err_files:
        print(f"      {fn}")
else:
    print(f"  ✅ All {total} files extracted successfully")

no_content_large = sdf[(~sdf['has_content']) & (sdf['text_length'] > 5000)]
if len(no_content_large) > 0:
    print(f"  ⚠ {len(no_content_large)} large files (>5K chars) missing extracted_content")

if total_dates_u > 5:
    print(f"  ⚠ {total_dates_u} unverified dates — review for hallucinations")
if total_rates_u > 20:
    print(f"  ⚠ {total_rates_u} unverified rates — review for hallucinations")

# Delta-readiness warnings
if rate_num_mean < 90:
    print(f"  ⚠ Only {rate_num_mean:.0f}% of rate rows have rate_numeric — Delta flattening will have gaps")
if clause_mean < 90:
    print(f"  ⚠ Only {clause_mean:.0f}% of clause sections have full_clause_text — some content requires PDF reading")
if amend_impact_pct < 90 and len(amend_df) > 0:
    print(f"  ⚠ Only {amend_impact_pct:.0f}% of amendments have amendments_impact — merge step may have gaps")

# Base agreements without inpatient rates (potential extraction gaps)
base_no_rates = sdf[(sdf['content_bucket'] == 'B1_Base_Agreement') & (~sdf['has_inpatient_per_diem']) & (sdf['has_content'])]
if len(base_no_rates) > 0:
    print(f"  ⚠ {len(base_no_rates)} base agreements without inpatient rate extraction (may need re-extraction)")

# Exit code
exit_code = 0 if failed == 0 else (2 if failed / total > 0.5 else 1)
print(f"\n  EXIT CODE: {exit_code} ({'clean' if exit_code == 0 else 'partial' if exit_code == 1 else 'CRITICAL'})")
print("=" * 100)
