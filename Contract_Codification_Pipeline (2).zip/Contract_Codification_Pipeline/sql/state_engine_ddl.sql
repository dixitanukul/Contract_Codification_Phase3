-- ═══════════════════════════════════════════════════════════════════════════════
-- CONTRACT STATE ENGINE v2 — Delta Table DDL
-- 
-- Purpose: Create all v2 tables for the amendment-aware state engine
-- Schema:  dev_adb.raw (alongside existing v1 tables — non-destructive)
-- 
-- Run order: Execute this ONCE to create empty tables.
--            Then run the state engine pipeline to populate them.
-- 
-- Dependencies: None (creates tables from scratch)
-- Rollback:    DROP TABLE dev_adb.raw.tbl_v2_*
-- ═══════════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 1: Contract Registry
-- The primary entity — one row per legal agreement
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_contract_registry (
    -- Identity
    contract_id             STRING NOT NULL COMMENT 'Deterministic hash: sha256(provider_id|base_agreement_doc)',
    provider_id             STRING NOT NULL COMMENT 'Provider ID from dim_provider_canonical',
    provider_name           STRING NOT NULL COMMENT 'Canonical provider name',
    
    -- Classification
    agreement_type          STRING COMMENT 'fee_for_service | capitation | settlement | mixed',
    payment_model           STRING COMMENT 'per_diem | case_rate | percentage | pmpm | mixed',
    network_scope           STRING COMMENT 'commercial | medicare | medi_cal | all',
    
    -- Lifecycle
    status                  STRING NOT NULL COMMENT 'ACTIVE | TERMINATED | EXPIRED | SUPERSEDED',
    effective_from          DATE COMMENT 'Original contract start date',
    effective_to            DATE COMMENT 'NULL if active; populated on termination/expiry',
    auto_renewal            BOOLEAN COMMENT 'Whether contract auto-renews',
    term_years              FLOAT COMMENT 'Contract term length in years',
    
    -- Lineage
    base_agreement_doc      STRING NOT NULL COMMENT 'source_filename of originating base agreement',
    total_amendments        INT DEFAULT 0 COMMENT 'Count of linked amendments',
    latest_amendment_date   DATE COMMENT 'Effective date of most recent amendment',
    latest_amendment_doc    STRING COMMENT 'source_filename of most recent amendment',
    
    -- Audit
    state_computed_at       TIMESTAMP NOT NULL COMMENT 'When this row was last computed/refreshed',
    state_version           INT NOT NULL DEFAULT 1 COMMENT 'Monotonically increasing computation version',
    computation_rule        STRING COMMENT 'Which algorithm/rule produced this state classification'
)
USING DELTA
COMMENT 'Contract-level entity registry. One row per legal agreement. Provider may have multiple contracts.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 2: Amendment Registry
-- Links amendments to contracts with scope classification
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_amendment_registry (
    -- Identity
    amendment_id            STRING NOT NULL COMMENT 'Deterministic hash: sha256(contract_id|source_filename)',
    contract_id             STRING NOT NULL COMMENT 'FK to tbl_v2_contract_registry',
    
    -- Document
    source_filename         STRING NOT NULL COMMENT 'PDF filename this amendment was extracted from',
    document_type           STRING COMMENT 'amendment | cover_memo | addendum | restated',
    amendment_order         INT NOT NULL COMMENT 'Chronological sequence within contract (1-based)',
    
    -- Scope Classification (the key innovation over v1)
    scope_type              STRING NOT NULL COMMENT 'FULL_REPLACEMENT | EXHIBIT_SPECIFIC | RATE_SPECIFIC | SECTION_SPECIFIC | TERM_EXTENSION | ADDENDUM',
    exhibits_modified       STRING COMMENT 'JSON array of exhibit names modified: ["Exhibit B", "Exhibit D-1"]',
    sections_modified       STRING COMMENT 'JSON array of sections modified: ["Section 4.2", "Article VII"]',
    rate_categories_modified STRING COMMENT 'JSON array of rate categories affected: ["inpatient_per_diem"]',
    
    -- Temporal
    effective_date          DATE COMMENT 'When amendment changes take effect (business date)',
    execution_date          DATE COMMENT 'When amendment was signed (may differ from effective)',
    
    -- Content
    summary_of_changes      STRING COMMENT 'LLM-generated summary of what changed',
    amendments_impact_raw   STRING COMMENT 'Full JSON from LLM extraction (amendments_impact field)',
    
    -- Confidence
    scope_confidence        FLOAT COMMENT '0-1: confidence in scope classification',
    scope_source            STRING COMMENT 'explicit_text | inferred_from_content | inferred_from_categories | default_full',
    
    -- Audit
    created_at              TIMESTAMP NOT NULL COMMENT 'When this record was created',
    classification_rule     STRING COMMENT 'Which algorithm/rule classified this amendment scope'
)
USING DELTA
COMMENT 'Amendment registry with scope classification. Links each amendment to its contract and declares what it modifies.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 3: Rate Facts (Bitemporal)
-- Immutable rate records with dual-timeline tracking
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_rate_facts_bitemporal (
    -- Identity
    rate_fact_id            STRING NOT NULL COMMENT 'Stable identity across corrections: hash(contract+source+category+service+value)',
    rate_version_id         STRING NOT NULL COMMENT 'Unique per version of this fact (UUID)',
    contract_id             STRING NOT NULL COMMENT 'FK to tbl_v2_contract_registry',
    amendment_id            STRING COMMENT 'FK to tbl_v2_amendment_registry (NULL for base agreement rates)',
    
    -- Rate Content (immutable — exactly as extracted)
    rate_category           STRING COMMENT 'Rate type: inpatient_per_diem, outpatient_surgical, capitation, etc.',
    service_category        STRING COMMENT 'Service description: Medical/Surgical, ICU/CCU, etc.',
    rate_text               STRING COMMENT 'Original rate text as extracted',
    rate_numeric            FLOAT COMMENT 'Numeric rate value (parsed from text)',
    rate_type_detail        STRING COMMENT 'Sub-type: pmpm, pct_of_charges, case_rate, etc.',
    formula                 STRING COMMENT 'Rate formula if applicable',
    revenue_codes           STRING COMMENT 'Associated revenue codes',
    program                 STRING COMMENT 'Program: Commercial, Medicare, Medi-Cal, etc.',
    network                 STRING COMMENT 'Network designation',
    source_filename         STRING NOT NULL COMMENT 'PDF document this rate was extracted from',
    exhibit_reference       STRING COMMENT 'Which exhibit this rate appeared in (e.g., Exhibit B)',
    page_number             INT COMMENT 'Page number in source document',
    
    -- Valid Time (business reality)
    valid_from              DATE NOT NULL COMMENT 'When this rate took/takes effect (contract effective date)',
    valid_to                DATE COMMENT 'When this rate was superseded (NULL = still in effect)',
    
    -- Transaction Time (system knowledge)
    tx_from                 TIMESTAMP NOT NULL COMMENT 'When the system first recorded this version',
    tx_to                   TIMESTAMP COMMENT 'When this version was retracted/corrected (NULL = current belief)',
    
    -- Supersession (populated by state engine)
    is_current              BOOLEAN COMMENT 'Computed: tx_to IS NULL AND valid_to IS NULL',
    superseded_by_fact_id   STRING COMMENT 'FK to the rate_fact that replaced this one',
    superseded_by_amendment STRING COMMENT 'FK to the amendment that caused supersession',
    supersession_type       STRING COMMENT 'EXPLICIT | EXHIBIT_REPLACE | RATE_PAIR_EXACT | RATE_PAIR_FUZZY | FULL_REPLACEMENT | V1_HEURISTIC',
    supersession_confidence FLOAT COMMENT '0-1 confidence in the supersession decision',
    
    -- Audit
    extracted_at            TIMESTAMP COMMENT 'When this rate was extracted from PDF',
    state_computed_at       TIMESTAMP COMMENT 'When supersession was last computed for this fact'
)
USING DELTA
COMMENT 'Bitemporal rate facts. Immutable extraction records with valid_time (business) and tx_time (system knowledge).'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 4: Clause Facts (Bitemporal)
-- Contract terms, definitions, and clauses with temporal tracking
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_clause_facts_bitemporal (
    -- Identity
    clause_fact_id          STRING NOT NULL COMMENT 'Stable identity: hash(contract+section_ref+topic+type)',
    clause_version_id       STRING NOT NULL COMMENT 'Unique per version (UUID)',
    contract_id             STRING NOT NULL COMMENT 'FK to tbl_v2_contract_registry',
    amendment_id            STRING COMMENT 'FK to tbl_v2_amendment_registry',
    
    -- Content
    content_type            STRING COMMENT 'clause | definition | code | party | section',
    topic                   STRING COMMENT 'Subject/topic classification',
    section_reference       STRING COMMENT 'Section 4.2, Article VII, Exhibit A, etc.',
    title                   STRING COMMENT 'Clause title/heading',
    content_text            STRING COMMENT 'Full text of the clause',
    source_filename         STRING NOT NULL COMMENT 'Source document',
    page_number             INT COMMENT 'Page number in source',
    
    -- Valid Time
    valid_from              DATE NOT NULL COMMENT 'When this clause took effect',
    valid_to                DATE COMMENT 'When this clause was superseded (NULL = current)',
    
    -- Transaction Time
    tx_from                 TIMESTAMP NOT NULL COMMENT 'When recorded by system',
    tx_to                   TIMESTAMP COMMENT 'When retracted (NULL = current belief)',
    
    -- Supersession
    is_current              BOOLEAN COMMENT 'tx_to IS NULL AND valid_to IS NULL',
    superseded_by_clause_id STRING COMMENT 'FK to replacing clause',
    superseded_by_amendment STRING COMMENT 'FK to amendment that replaced this',
    supersession_type       STRING COMMENT 'CLAUSE_IDENTITY_MATCH | CLAUSE_SIMILARITY_MATCH | EXHIBIT_REPLACE | FULL_REPLACEMENT',
    
    -- Semantic Identity (for matching across amendments)
    clause_identity_hash    STRING COMMENT 'hash(topic + section_ref + normalized_title) — stable across versions',
    
    -- Audit
    extracted_at            TIMESTAMP,
    state_computed_at       TIMESTAMP
)
USING DELTA
COMMENT 'Bitemporal clause/term facts with semantic identity for cross-amendment matching.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 5: Supersession Decisions (Audit Trail)
-- Every supersession decision logged with evidence and confidence
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_supersession_decisions (
    -- Identity
    decision_id             STRING NOT NULL COMMENT 'Unique decision ID (UUID)',
    contract_id             STRING NOT NULL COMMENT 'FK to contract_registry',
    amendment_id            STRING NOT NULL COMMENT 'FK to amendment_registry — which amendment triggered this',
    
    -- What was superseded
    superseded_fact_id      STRING COMMENT 'Rate or clause fact that was superseded',
    superseded_fact_type    STRING COMMENT 'rate | clause',
    
    -- What superseded it
    superseding_fact_id     STRING COMMENT 'New rate/clause fact (NULL if just retired without replacement)',
    
    -- Decision metadata
    supersession_type       STRING NOT NULL COMMENT 'Algorithm output type',
    confidence              FLOAT NOT NULL COMMENT '0-1 confidence score',
    evidence                STRING COMMENT 'What text/logic justified this decision',
    algorithm_pass          INT COMMENT 'Which pass produced this: 1=document, 2=exhibit, 3=rate-line, 4=clause',
    
    -- Review
    needs_review            BOOLEAN DEFAULT FALSE COMMENT 'Flagged for human review',
    conflict_notes          STRING COMMENT 'Notes about conflicting decisions',
    reviewed_by             STRING COMMENT 'Who reviewed (NULL if unreviewed)',
    reviewed_at             TIMESTAMP COMMENT 'When reviewed',
    review_override         STRING COMMENT 'NULL | CONFIRMED | REJECTED | MODIFIED',
    
    -- Audit
    computed_at             TIMESTAMP NOT NULL COMMENT 'When this decision was computed',
    computation_version     INT NOT NULL COMMENT 'Which state engine run produced this'
)
USING DELTA
COMMENT 'Audit trail for all supersession decisions. Every claim about current-state traces back to this table.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 6: Amendment Graph Edges
-- Explicit relationships between amendments and what they modify
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_amendment_graph_edges (
    edge_id                 STRING NOT NULL COMMENT 'Unique edge ID',
    edge_type               STRING NOT NULL COMMENT 'AMENDS | MODIFIES_EXHIBIT | SUPERSEDES_RATE | SUPERSEDES_CLAUSE | INTRODUCES | EXTENDS_TERM',
    from_node_id            STRING NOT NULL COMMENT 'Source node (amendment, rate, or clause fact ID)',
    to_node_id              STRING NOT NULL COMMENT 'Target node',
    contract_id             STRING NOT NULL COMMENT 'All edges belong to a contract',
    
    -- Edge attributes
    confidence              FLOAT COMMENT '0-1 confidence in this relationship',
    evidence_source         STRING COMMENT 'What established this edge',
    effective_date          DATE COMMENT 'When this relationship takes effect',
    
    -- Audit
    created_at              TIMESTAMP COMMENT 'When edge was created',
    created_by_rule         STRING COMMENT 'Which algorithm created this edge'
)
USING DELTA
COMMENT 'Amendment graph edges representing relationships between amendments, rates, and clauses.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 7: Computation Audit Log
-- Tracks every state engine run
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_computation_audit (
    run_id                  STRING NOT NULL COMMENT 'Unique computation run ID',
    started_at              TIMESTAMP NOT NULL,
    completed_at            TIMESTAMP,
    mode                    STRING COMMENT 'full | incremental | validate_only',
    
    -- Results
    contracts_processed     INT,
    amendments_classified   INT,
    supersession_decisions  INT,
    rates_marked_current    INT,
    rates_marked_superseded INT,
    
    -- Validation
    invariants_passed       BOOLEAN,
    invariant_failures      STRING COMMENT 'JSON array of failed invariant names',
    
    -- V1 Comparison
    v1_agreement_pct        FLOAT COMMENT 'Percent of rates that agree with v1',
    v2_only_count           INT COMMENT 'Rates in v2 but not v1 (expected: partial amendment preservation)',
    v1_only_count           INT COMMENT 'Rates in v1 but not v2 (expected: ~0)',
    
    -- Performance
    duration_seconds        FLOAT,
    error_message           STRING
)
USING DELTA
COMMENT 'Audit log tracking every state engine computation run with results and validation outcomes.';

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 8: Current-State Snapshot (Materialized)
-- Pre-computed for fast queries — rebuilt after every state engine run
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_v2_rates_current_snapshot (
    rate_fact_id            STRING NOT NULL,
    contract_id             STRING NOT NULL,
    provider_id             STRING NOT NULL,
    provider_name           STRING NOT NULL,
    rate_category           STRING,
    service_category        STRING,
    rate_text               STRING,
    rate_numeric            FLOAT,
    rate_type_detail        STRING,
    formula                 STRING,
    revenue_codes           STRING,
    program                 STRING,
    network                 STRING,
    source_filename         STRING,
    effective_date          DATE COMMENT 'When this rate became effective',
    supersession_confidence FLOAT COMMENT 'How confident we are this is truly current',
    agreement_type          STRING,
    contract_status         STRING,
    snapshot_generated_at   TIMESTAMP COMMENT 'When this snapshot was last rebuilt'
)
USING DELTA
COMMENT 'Materialized current-state snapshot. Rebuilt after each state engine run. Primary query target for intelligence.'
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true'
);

-- ═══════════════════════════════════════════════════════════════════════════════
-- OPTIMIZATION: Z-ORDER for common access patterns
-- ═══════════════════════════════════════════════════════════════════════════════

-- Run after initial data load:
-- OPTIMIZE dev_adb.raw.tbl_v2_rate_facts_bitemporal ZORDER BY (contract_id, valid_from, tx_from);
-- OPTIMIZE dev_adb.raw.tbl_v2_supersession_decisions ZORDER BY (contract_id, amendment_id);
-- OPTIMIZE dev_adb.raw.tbl_v2_rates_current_snapshot ZORDER BY (provider_id, rate_category);

-- ═══════════════════════════════════════════════════════════════════════════════
-- BACKWARD-COMPATIBLE VIEWS (created AFTER data is populated)
-- These allow existing intelligence notebooks to work unchanged
-- ═══════════════════════════════════════════════════════════════════════════════

-- NOTE: Uncomment these after Stage 5 (state materialization) is complete:
--
-- CREATE OR REPLACE VIEW dev_adb.raw.tbl_genie_rates_current_v2 AS
-- SELECT
--     provider_name, provider_id,
--     rate_category, service_category,
--     rate_text, rate_numeric, rate_type_detail,
--     effective_date AS effective_date_parsed,
--     formula,
--     CAST(NULL AS STRING) AS notes,
--     revenue_codes, program, network,
--     program AS program_normalized,
--     source_filename
-- FROM dev_adb.raw.tbl_v2_rates_current_snapshot;
