-- ═══════════════════════════════════════════════════════════════════════════════
-- REIMBURSEMENT MODEL V2 — Table DDL (Part 1 of 5)
-- 
-- Creates 9 tables in dev_adb.raw for computable reimbursement logic.
-- Run order: Execute this FIRST. Tables are empty after creation.
-- Dependencies: None (creates tables from scratch)
-- ═══════════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 1: Rate Rules (Master)
-- Atomic unit of reimbursement logic — one row per contractual rate provision
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.tbl_reimb_rate_rules
--   ZORDER BY (provider_id, rate_domain, service_line);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_reimb_rate_rules (
    -- Identity
    rule_id                 STRING NOT NULL COMMENT 'Unique rule identifier (UUID)',
    contract_id             STRING NOT NULL COMMENT 'FK to tbl_v2_contract_registry or logical contract grouping',
    provider_id             STRING NOT NULL COMMENT 'Provider ID from dim_provider_canonical',
    provider_name           STRING NOT NULL COMMENT 'Canonical provider name',

    -- Classification
    rate_domain             STRING NOT NULL COMMENT 'INPATIENT | OUTPATIENT | CAPITATION | PROFESSIONAL',
    service_line            STRING NOT NULL COMMENT 'FK to dim_service_line_taxonomy.service_line_code',
    service_category_raw    STRING COMMENT 'Original LLM-extracted service category text',

    -- Formula (structured, computable)
    formula_type            STRING NOT NULL COMMENT 'FIXED | PER_DIEM | PERCENTAGE | DRG_WEIGHTED | CONVERSION_FACTOR | TIERED | LESSER_OF | GREATER_OF | COMPOUND | PERCENTAGE_PLUS_CAP | ESCALATED',
    formula_json            STRING NOT NULL COMMENT 'Full expression tree as JSON (see REIMBURSEMENT_MODEL_V2.md §4)',

    -- Simplified numeric (backward compatible)
    rate_numeric            FLOAT COMMENT 'Best single-number representation for backward compat',
    rate_text               STRING COMMENT 'Original rate text as extracted from PDF',
    rate_unit               STRING COMMENT 'Unit: day | case | visit | member_month | procedure',

    -- Applicability
    program                 STRING COMMENT 'Commercial | Medicare | Medi-Cal | All',
    network                 STRING COMMENT 'HMO | PPO | All Networks',
    revenue_codes           STRING COMMENT 'Comma-separated applicable revenue codes',
    procedure_codes         STRING COMMENT 'CPT/HCPCS codes if applicable',
    drg_codes               STRING COMMENT 'DRG codes if DRG-weighted formula',

    -- Provenance
    source_filename         STRING NOT NULL COMMENT 'PDF filename this rate was extracted from',
    exhibit_reference       STRING COMMENT 'Which exhibit in the contract (e.g., Exhibit B)',
    effective_date          DATE COMMENT 'When this rate takes effect',

    -- Modifier flags (FKs to modifier tables)
    has_stop_loss           BOOLEAN DEFAULT FALSE COMMENT 'TRUE if linked stop-loss exists in tbl_reimb_stop_loss',
    has_carve_outs          BOOLEAN DEFAULT FALSE COMMENT 'TRUE if linked carve-outs exist in tbl_reimb_carve_outs',
    has_escalator           BOOLEAN DEFAULT FALSE COMMENT 'TRUE if linked escalator exists in tbl_reimb_escalators',
    has_conditions          BOOLEAN DEFAULT FALSE COMMENT 'TRUE if linked conditions exist in tbl_reimb_conditions',

    -- Audit
    extracted_at            TIMESTAMP COMMENT 'When this rate was extracted from PDF by LLM',
    confidence_score        FLOAT COMMENT 'LLM extraction confidence 0.0-1.0'
)
USING DELTA
COMMENT 'Master rate rules table. One row per contractual rate provision with computable formula_json expression trees.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 2: Formula Components (Expression Tree Nodes)
-- Decomposed formula elements for recursive evaluation
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.tbl_reimb_formula_components
--   ZORDER BY (rule_id, parent_component_id);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_reimb_formula_components (
    -- Identity
    component_id            STRING NOT NULL COMMENT 'Unique component identifier (UUID)',
    rule_id                 STRING NOT NULL COMMENT 'FK to tbl_reimb_rate_rules.rule_id',
    parent_component_id     STRING COMMENT 'NULL for root node; FK to parent component for tree recursion',

    -- Component type
    component_type          STRING NOT NULL COMMENT 'BASE_RATE | MULTIPLIER | CAP | FLOOR | OPERAND',
    operator                STRING COMMENT 'LESSER_OF | GREATER_OF | PLUS | TIMES | MIN | MAX',

    -- Value (one populated depending on component_type)
    fixed_amount            FLOAT COMMENT 'Dollar amount for FIXED or BASE_RATE components',
    percentage              FLOAT COMMENT 'Percentage value 0-100 for PERCENTAGE components',
    percentage_of           STRING COMMENT 'BILLED_CHARGES | MEDICARE_RATE | FEE_SCHEDULE | CONTRACTED_RATE',
    multiplier              FLOAT COMMENT 'Multiplication factor (DRG weight, geographic factor)',
    reference_base          STRING COMMENT 'What this multiplies: DRG_BASE_RATE | RVU | CPI_INDEX',

    -- Bounds
    cap_amount              FLOAT COMMENT 'Maximum payable amount (ceiling)',
    floor_amount            FLOAT COMMENT 'Minimum payable amount (floor)',

    -- Position
    sequence_order          INT DEFAULT 0 COMMENT 'Order within sibling operands (for LESSER_OF, COMPOUND)',

    -- Description
    description             STRING COMMENT 'Human-readable description of this formula component'
)
USING DELTA
COMMENT 'Expression tree nodes for rate formulas. Enables recursive evaluation of compound reimbursement logic.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 3: Stop-Loss (Multi-Tier Financial Protections)
-- Multiple stop-loss provisions per provider/contract
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.tbl_reimb_stop_loss
--   ZORDER BY (provider_id, stop_loss_type);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_reimb_stop_loss (
    -- Identity
    stop_loss_id            STRING NOT NULL COMMENT 'Unique stop-loss identifier (UUID)',
    rule_id                 STRING NOT NULL COMMENT 'FK to tbl_reimb_rate_rules (which base rate this protects)',
    contract_id             STRING NOT NULL COMMENT 'FK to contract registry',
    provider_id             STRING NOT NULL COMMENT 'Provider ID for direct lookups',

    -- Stop-loss type
    stop_loss_type          STRING NOT NULL COMMENT 'PER_DIEM | CASE_RATE | AGGREGATE | CORRIDOR',

    -- Thresholds
    attachment_level        FLOAT COMMENT 'Dollar amount where stop-loss kicks in',
    attachment_unit         STRING COMMENT 'TOTAL_CHARGES | TOTAL_DAYS | TOTAL_COST',

    -- Reimbursement above threshold
    reimburse_formula_type  STRING COMMENT 'FIXED_PER_DIEM | PERCENTAGE | CHARGES_LESS_THRESHOLD',
    reimburse_rate          FLOAT COMMENT 'Per-diem rate or fixed amount above threshold',
    reimburse_percentage    FLOAT COMMENT 'Percentage reimbursed above threshold (e.g., 80)',

    -- Aggregate provisions
    aggregate_cap           FLOAT COMMENT 'Annual aggregate stop-loss cap (max total payout)',
    corridor_amount         FLOAT COMMENT 'Corridor gap between attachment and coverage start',

    -- Applicability
    applies_to_services     STRING COMMENT 'Which service lines this stop-loss covers (comma-sep)',
    revenue_codes           STRING COMMENT 'Revenue codes that trigger stop-loss evaluation',

    -- Provenance
    source_filename         STRING NOT NULL COMMENT 'PDF filename this was extracted from',
    exhibit_reference       STRING COMMENT 'Exhibit reference in source contract',
    effective_date          DATE COMMENT 'When this stop-loss provision takes effect'
)
USING DELTA
COMMENT 'Multi-tier stop-loss provisions. Replaces single-threshold-per-facility model with typed, multi-level protections.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 4: Carve-Outs (Exception Provisions)
-- Items reimbursed outside the base rate (implants, drugs, devices)
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.tbl_reimb_carve_outs
--   ZORDER BY (provider_id, carve_out_type);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_reimb_carve_outs (
    -- Identity
    carve_out_id            STRING NOT NULL COMMENT 'Unique carve-out identifier (UUID)',
    contract_id             STRING NOT NULL COMMENT 'FK to contract registry',
    provider_id             STRING NOT NULL COMMENT 'Provider ID for direct lookups',

    -- What is carved out
    carve_out_type          STRING NOT NULL COMMENT 'IMPLANT | DRUG | DEVICE | PROCEDURE | SUPPLY',
    description             STRING COMMENT 'Human-readable description of the carve-out provision',

    -- Trigger condition
    threshold_amount        FLOAT COMMENT 'Dollar threshold to trigger carve-out (e.g., implant > $10K)',
    threshold_type          STRING COMMENT 'PER_ITEM | PER_CASE | PER_DAY',

    -- Reimbursement for carved-out items
    reimburse_formula_type  STRING NOT NULL COMMENT 'COST_PLUS | PERCENTAGE | FIXED | INVOICE',
    reimburse_percentage    FLOAT COMMENT 'E.g., cost + 10% stored as 110.0',
    reimburse_fixed         FLOAT COMMENT 'Fixed dollar amount if formula_type = FIXED',
    reimburse_of            STRING COMMENT 'Base for percentage: INVOICE_COST | AWP | WAC | CHARGES',

    -- Relationship to base rate
    base_rule_id            STRING COMMENT 'FK to tbl_reimb_rate_rules — which rate this carves out FROM',
    relationship            STRING COMMENT 'ADDITIONAL_TO | INSTEAD_OF | ABOVE_THRESHOLD',

    -- Code linkage
    revenue_codes           STRING COMMENT 'Revenue codes triggering this carve-out',
    procedure_codes         STRING COMMENT 'CPT/HCPCS procedure codes',
    ndc_codes               STRING COMMENT 'NDC drug codes for pharmacy carve-outs',

    -- Provenance
    source_filename         STRING NOT NULL COMMENT 'PDF filename this was extracted from',
    effective_date          DATE COMMENT 'When this carve-out provision takes effect'
)
USING DELTA
COMMENT 'Carve-out provisions for items reimbursed outside the base rate (implants, drugs, devices, supplies).'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 5: Escalators (Rate Progression Over Time)
-- Annual increases: fixed %, CPI-linked, step schedules, or formulas
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.tbl_reimb_escalators
--   ZORDER BY (rule_id, escalator_type);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_reimb_escalators (
    -- Identity
    escalator_id            STRING NOT NULL COMMENT 'Unique escalator identifier (UUID)',
    rule_id                 STRING NOT NULL COMMENT 'FK to tbl_reimb_rate_rules being escalated',
    contract_id             STRING NOT NULL COMMENT 'FK to contract registry',

    -- Escalation type
    escalator_type          STRING NOT NULL COMMENT 'FIXED_PERCENTAGE | CPI_LINKED | STEP_SCHEDULE | FORMULA',

    -- For FIXED_PERCENTAGE
    annual_increase_pct     FLOAT COMMENT 'Annual increase percentage (e.g., 3.0 for 3%)',

    -- For CPI_LINKED
    cpi_index               STRING COMMENT 'Which CPI index (e.g., CPI-U Medical Care)',
    cpi_floor               FLOAT COMMENT 'Minimum increase even if CPI is lower',
    cpi_cap                 FLOAT COMMENT 'Maximum increase even if CPI is higher',

    -- For STEP_SCHEDULE (explicit year-by-year rates)
    year_1_rate             FLOAT COMMENT 'Year 1 PMPM or per-diem rate',
    year_1_effective        DATE COMMENT 'Year 1 effective date',
    year_2_rate             FLOAT COMMENT 'Year 2 rate',
    year_2_effective        DATE COMMENT 'Year 2 effective date',
    year_3_rate             FLOAT COMMENT 'Year 3 rate',
    year_3_effective        DATE COMMENT 'Year 3 effective date',
    year_4_rate             FLOAT COMMENT 'Year 4 rate',
    year_4_effective        DATE COMMENT 'Year 4 effective date',

    -- Temporal
    base_year_date          DATE COMMENT 'Start date for escalation calculation',
    escalation_frequency    STRING COMMENT 'ANNUAL | SEMI_ANNUAL | QUARTERLY',

    -- Provenance
    source_filename         STRING NOT NULL COMMENT 'PDF filename this was extracted from',
    effective_date          DATE COMMENT 'When the escalator provision takes effect'
)
USING DELTA
COMMENT 'Rate escalator provisions linking multi-year rate progressions to base rules.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 6: Conditions (Applicability Rules)
-- When a rate rule applies — LOS triggers, volume thresholds, authorization reqs
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.tbl_reimb_conditions
--   ZORDER BY (rule_id, condition_type);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_reimb_conditions (
    -- Identity
    condition_id            STRING NOT NULL COMMENT 'Unique condition identifier (UUID)',
    rule_id                 STRING NOT NULL COMMENT 'FK to tbl_reimb_rate_rules',

    -- Condition type
    condition_type          STRING NOT NULL COMMENT 'LOS | DIAGNOSIS | VOLUME | TIMING | SERVICE | AUTHORIZATION',

    -- Condition expression
    field                   STRING NOT NULL COMMENT 'Scenario field tested: length_of_stay | total_charges | drg_code | admit_date',
    operator                STRING NOT NULL COMMENT 'GT | GTE | LT | LTE | EQ | IN | BETWEEN | NOT_IN',
    value                   STRING NOT NULL COMMENT 'Threshold value or comma-separated list',
    value_numeric           FLOAT COMMENT 'Numeric representation of value (for numeric comparisons)',
    value_unit              STRING COMMENT 'DAYS | DOLLARS | VISITS | PROCEDURES',

    -- When condition fails (alternative rule)
    else_rule_id            STRING COMMENT 'FK to tbl_reimb_rate_rules — rule that applies if THIS fails',
    else_description        STRING COMMENT 'Human-readable description of the alternative',

    -- Logic grouping
    condition_group         INT DEFAULT 0 COMMENT 'Group number: same group = AND logic between conditions',
    group_operator          STRING DEFAULT 'AND' COMMENT 'AND | OR — logic BETWEEN groups'
)
USING DELTA
COMMENT 'Applicability conditions for rate rules. AND within groups, OR between groups. Enables conditional rate selection.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 7: Lesser-Of (Comparison Logic)
-- Payment = minimum of N comparators (contracted rate, charges, Medicare, etc.)
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.tbl_reimb_lesser_of
--   ZORDER BY (rule_id);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_reimb_lesser_of (
    -- Identity
    lesser_of_id            STRING NOT NULL COMMENT 'Unique lesser-of identifier (UUID)',
    rule_id                 STRING NOT NULL COMMENT 'FK to tbl_reimb_rate_rules',
    contract_id             STRING NOT NULL COMMENT 'FK to contract registry',

    -- Comparators (payment = MIN of populated comparators)
    comparator_1_type       STRING NOT NULL COMMENT 'CONTRACTED_RATE | BILLED_CHARGES | MEDICARE_RATE | FEE_SCHEDULE',
    comparator_1_value      FLOAT COMMENT 'Static value if known; NULL if dynamic (actual charges)',
    comparator_2_type       STRING NOT NULL COMMENT 'Second comparator type',
    comparator_2_value      FLOAT COMMENT 'Second comparator static value',
    comparator_3_type       STRING COMMENT 'Optional third comparator type',
    comparator_3_value      FLOAT COMMENT 'Optional third comparator static value',

    -- Context
    medicare_version        STRING COMMENT 'Which Medicare fee schedule version (e.g., 2024 OPPS)',
    applies_to_services     STRING COMMENT 'Service lines this lesser-of applies to',

    -- Provenance
    source_filename         STRING NOT NULL COMMENT 'PDF filename this was extracted from',
    effective_date          DATE COMMENT 'When this lesser-of provision takes effect'
)
USING DELTA
COMMENT 'Lesser-of comparison provisions. Replaces boolean lesser_of_language flag with structured multi-comparator logic.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 8: Service Line Taxonomy (Hierarchical Classification)
-- Replaces hardcoded 25-entry CASE WHEN in 13_build_serving.py
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.dim_service_line_taxonomy
--   ZORDER BY (domain, level, parent_id);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.dim_service_line_taxonomy (
    -- Identity
    service_line_id         INT NOT NULL COMMENT 'Unique taxonomy node ID (stable, non-sequential)',
    service_line_code       STRING NOT NULL COMMENT 'Machine-friendly code: IP_ACUTE_MEDSURG, OP_SURG_TIER1',

    -- Hierarchy
    level                   INT NOT NULL COMMENT '0=Domain, 1=Service Group, 2=Service Line, 3=Subtype',
    domain                  STRING NOT NULL COMMENT 'INPATIENT | OUTPATIENT | PROFESSIONAL | CAPITATION',
    parent_id               INT COMMENT 'FK to parent service_line_id (NULL for Level 0 roots)',

    -- Names
    display_name            STRING NOT NULL COMMENT 'Human-friendly display name: Medical/Surgical/Peds',
    short_name              STRING COMMENT 'Abbreviated name for dashboards: Med/Surg',

    -- Matching (replaces CASE WHEN)
    match_patterns          STRING NOT NULL COMMENT 'JSON array of ILIKE patterns: ["%Medical/Surgical%", "%Med/Surg%"]',
    match_priority          INT DEFAULT 0 COMMENT 'Higher = match first when patterns overlap',

    -- Standard code linkage
    cms_category            STRING COMMENT 'CMS service category code',
    drg_range               STRING COMMENT 'DRG range: 001-099 (Nervous System)',
    apc_range               STRING COMMENT 'APC range for outpatient procedures',
    revenue_code_range      STRING COMMENT 'Revenue code range: 0200-0219',

    -- Analytics
    sort_order              INT NOT NULL COMMENT 'Display sort order within parent',
    is_active               BOOLEAN DEFAULT TRUE COMMENT 'FALSE to soft-delete without removing',
    comparable_group        STRING COMMENT 'Benchmarking group: which lines are comparable'
)
USING DELTA
COMMENT 'Hierarchical service line taxonomy. 4-level tree (Domain > Group > Line > Subtype) replacing hardcoded CASE WHEN.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);

-- ─────────────────────────────────────────────────────────────────────────────
-- TABLE 9: Service Line Patterns (Match Rules)
-- Complex pattern matching with exclusions and provider-specific overrides
-- Z-ORDER recommendation: OPTIMIZE dev_adb.raw.dim_service_line_patterns
--   ZORDER BY (service_line_id, priority);
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dev_adb.raw.dim_service_line_patterns (
    -- Identity
    pattern_id              INT NOT NULL COMMENT 'Unique pattern identifier',
    service_line_id         INT NOT NULL COMMENT 'FK to dim_service_line_taxonomy.service_line_id',

    -- Pattern specification
    pattern_type            STRING NOT NULL COMMENT 'ILIKE | REGEX | EXACT | STARTS_WITH',
    pattern_value           STRING NOT NULL COMMENT 'The actual pattern to match against service_category',

    -- Exclusion (match this BUT NOT that)
    exclude_pattern         STRING COMMENT 'If service_category ALSO matches this, skip this rule',

    -- Priority
    priority                INT DEFAULT 0 COMMENT 'Higher wins on conflict between overlapping patterns',

    -- Context scoping
    applies_to_domain       STRING COMMENT 'Only apply within this domain (NULL = all domains)',
    applies_to_provider     STRING COMMENT 'Provider-specific override pattern (NULL = all providers)'
)
USING DELTA
COMMENT 'Pattern matching rules for service line classification. Enables table-driven matching with exclusions and scoping.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);
